<?php
  \Magento\Framework\Component\ComponentRegistrar::register(
      \Magento\Framework\Component\ComponentRegistrar::MODULE,
      'SendGrid_EmailDeliverySimplified',
      __DIR__
  );
