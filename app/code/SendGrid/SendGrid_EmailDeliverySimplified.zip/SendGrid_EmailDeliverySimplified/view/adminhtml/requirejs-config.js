var config = {
  map: {
    '*': {
      'sendgrid_jquery': 'SendGrid_EmailDeliverySimplified/js/sendgrid_jquery',
      'sendgrid': 'SendGrid_EmailDeliverySimplified/js/sendgrid',
      'sendgrid_statistics': 'SendGrid_EmailDeliverySimplified/js/sendgrid_statistics',
      'sendgrid_chart': 'SendGrid_EmailDeliverySimplified/js/sendgrid_chart'
    }
  }
};