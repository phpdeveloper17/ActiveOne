<?php
namespace Unilab\Inquiry\Model\ResourceModel\Inquiry;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	// protected $_eventPrefix = 'unilab_benefits_employeebenefits_collection';
	// protected $_eventObject = 'employeebenefits_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init(
			'Unilab\Inquiry\Model\Inquiry',
			'Unilab\Inquiry\Model\ResourceModel\Inquiry');
	}

}
