<?php

namespace Unilab\Inquiry\Model;

/**
 *
 */
class Inquiry extends \Magento\Framework\Model\AbstractModel
{
    const CACHE_TAG = 'unilab_inquiry';

    protected $_cacheTag = 'unilab_inquiry';

    protected $_eventPrefix = 'unilab_inquiry';

    public function _construct()
    {
        $this->_init('Unilab\Inquiry\Model\ResourceModel\Inquiry');
    }

    public function getInquiryId()
    {
        return $this->getData('inquiry_id');
    }

    public function setInquiryId($data)
    {
        $this->setData('inquiry_id', $data);
    }

    public function getStoreId()
    {
        return $this->getData('store_id');
    }

    public function setStoreId($data)
    {
        return $this->setData('store_id', $data);
    }

    public function getCustomerId()
    {
        return $this->getData('customer_id');
    }

    public function setCustomerId($data)
    {
        return $this->setData('customer_id', $data);
    }

    public function getDepartment()
    {
        return $this->getData('department');
    }

    public function setDepartment($data)
    {
        return $this->setData('department', $data);
    }

    public function getDepartmentEmail()
    {
        return $this->getData('department_email');
    }

    public function setDepartmentEmail($data)
    {
        return $this->setData('department_email', $data);
    }

    public function getConcern()
    {
        return $this->getData('concern');
    }

    public function setConcern($data)
    {
        return $this->setData('concern', $data);
    }

    public function getEmailAddress()
    {
        return $this->getData('email_address');
    }

    public function setEmailAddress($data)
    {
        return $this->setData('email_address', $data);
    }

    public function getName()
    {
        return $this->getData('name');
    }

    public function setName($data)
    {
        return $this->setData('name', $data);
    }

    public function getIsRead()
    {
        return $this->getData('is_read');
    }

    public function setIsRead($data)
    {
        return $this->setData('is_read', $data);
    }

    public function getCreatedTime()
    {
        return $this->getData('created_time');
    }

    public function setCreatedTime($data)
    {
        return $this->setData('created_time', $data);
    }
}
