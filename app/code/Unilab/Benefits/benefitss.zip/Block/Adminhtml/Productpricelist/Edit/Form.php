<?php

namespace Unilab\Benefits\Block\Adminhtml\Productpricelist\Edit;

use Magento\Backend\Block\Widget\Form\Generic;

class Form extends Generic
{
   /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @param \Magento\Backend\Block\Template\Context $context,
     * @param \Magento\Framework\Registry $registry,
     * @param \Magento\Framework\Data\FormFactory $formFactory,
     * @param \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        array $data = []
    ) {
        // $this->_cityFactory = $cityFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }
    protected function _prepareForm()
    {

        $websitelist = array();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
     

        $model = $this->_coreRegistry->registry('productpricelist_data');
        $numValueFormatter = [
            'qty_from'          => number_format($model->getQty_from(),2),
            'qty_to'            => number_format($model->getQty_to(),2),
            'unit_price'        => number_format($model->getUnit_price(),2),
            'discount_in_amount'=> number_format($model->getDiscount_in_amount(),2),
            'discount_in_percent'=> number_format($model->getDiscount_in_percent(),2),
        ];
        $model->addData($numValueFormatter);
        
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form',
                            'enctype' => 'multipart/form-data',
                            'action' => $this->getData('action'),
                            'method' => 'post'
                        ]
            ]
        );

        $form->setHtmlIdPrefix('productpricelist_');
        if ($model->getId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Product Price List'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add New Product Price List'), 'class' => 'fieldset-wide']
            );
        }

        $fieldset->addField(
            'pricelist_id',
            'text',
            [
                'name'      => 'pricelist_id',
                'label'     => __('Price List'),
                'id'        => 'pricelist_id',
                'title'     => __('Price List'),
                'style'     =>'width:70%',
                'required'  => true,
            ]
        );
        $fieldset->addField(
            'product_sku',
            'text',
            [
                'name'      => 'product_sku',
                'label'     => __('SKU'),
                'id'        => 'product_sku',
                'title'     => __('SKU'),
                'style'     =>'width:70%',
                'required'  => true,
            ]
        );
        $fieldset->addField(
            'product_name',
            'textarea',
            [
                'name'      => 'product_name',
                'label'     => __('Product Name'),
                'id'        => 'product_name',
                'title'     => __('Product Name'),
                'style'     =>'width:70%;height:200px',
                'class'     => 'required-entry',
                'required'  => true,
            ]
        );
        $fieldset->addField(
            'qty_from',
            'text',
            [
                'name'      => 'qty_from',
                'label'     => __('Qty From'),
                'id'        => 'qty_from',
                'title'     => __('Qty From'),
                'style'     =>'width:70%',
                'required'  => true,
            ]
        );
        $fieldset->addField(
            'qty_to',
            'text',
            [
                'name'      => 'qty_to',
                'label'     => __('Qty To'),
                'id'        => 'qty_to',
                'title'     => __('Qty To'),
                'style'     =>'width:70%',
                'required'  => true,
            ]
        );
        $fieldset->addField(
            'unit_price',
            'text',
            [
                'name'      => 'unit_price',
                'label'     => __('Unit Price'),
                'id'        => 'unit_price',
                'title'     => __('Unit Price'),
                'style'     =>'width:70%',
                'required'  => true,
            ]
        );
        $fieldset->addField(
            'discount_in_amount',
            'text',
            [
                'name'      => 'discount_in_amount',
                'label'     => __('Discount in Amount'),
                'id'        => 'discount_in_amount',
                'title'     => __('Discount in Amount'),
                'style'     =>'width:70%',
                'required'  => true,
            ]
        );
        $fieldset->addField(
            'discount_in_percent',
            'text',
            [
                'name'      => 'discount_in_percent',
                'label'     => __('Discount in Percent'),
                'id'        => 'discount_in_percent',
                'title'     => __('Discount in Percent'),
                'style'     =>'width:70%',
                'required'  => true,
            ]
        );
        $fieldset->addField(
            'from_date',
            'date',
            [
                'name'      => 'from_date',
                'label'     => __('From Date'),
                'id'        => 'from_date',
                'title'     => __('From Date'),
                'style'     =>'width:70%',
                'date_format' => 'MM/dd/yyyy',
                'required'  => false,
            ]
        );
        $fieldset->addField(
            'to_date',
            'date',
            [
                'name'      => 'to_date',
                'label'     => __('To Date'),
                'id'        => 'to_date',
                'title'     => __('To Date'),
                'style'     =>'width:70%',
                'date_format' => 'MM/dd/yyyy',
                'required'  => false,
            ]
        );

        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }
}

