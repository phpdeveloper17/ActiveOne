<?php
/**
 * @category  Unilab
 * @package   Unilab_Benefits
 * @author    Kristian Claridad
 */
namespace Unilab\Benefits\Controller\Adminhtml\PurchaseCapController;


class SubmitImport extends \Magento\Backend\App\Action
{
    const TABLE_NAME_VALUE      = 'wspi_purchasecap';
    /**
     * @var \Unilab\Grid\Model\GridFactory
     */
    var $gridFactory;
    protected $resourceConnection;
    protected $userSession;
    protected $messageManager;
    protected $remoteAddress;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Unilab\Grid\Model\GridFactory $gridFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Unilab\Benefits\Model\ProductpricelistFactory $gridFactory,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Backend\Model\Auth\Session $userSession,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress
    ) {
        parent::__construct($context);
        $this->gridFactory = $gridFactory;
        $this->resourceConnection = $resourceConnection;
        $this->userSession = $userSession;
        $this->messageManager = $messageManager;
        $this->remoteAddress = $remoteAddress;
    }

    /**
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $fullpath 	= $_FILES['csv_file']['tmp_name'];
		$filename 	= $_FILES['csv_file']['name'];
		$size 		= $_FILES['csv_file']['size'];
		$ext 		= pathinfo($filename, PATHINFO_EXTENSION);
		
		if(strtolower($ext) != 'csv'){
            $this->messageManager->addErrorMessage($filename.' - is not a CSV format.');
            
            $this->_redirect('unilab_benefits/purchasecapcontroller/import');
        }

		$csv 		= array_map("str_getcsv", file($fullpath));
		$head		= array_shift($csv);	

		$dataArr 			= array();		
		$dataArr['csv'] 	= $csv;
		$dataArr['head'] 	= $head;
	
		$SaveData = $this->_processData($dataArr);
		
		try{
            
            if(count($SaveData) == 0): 
		
                $this->messageManager->addError(__("Please check your filename / Data entry : $filename"));
                 
            else:
            
                $this->messageManager->addSuccess(__("Data has been saved."));
                 
            endif;
             
            $this->userSession->setresData($SaveData);

			$this->_redirect("unilab_benefits/purchasecapcontroller/importresult");

		}catch(\Exception $e){
			
            $this->messageManager->addError($e->getMessage());
				
		}	
		
		
		
        
    }

    protected function _getConnection()
    {
		$connection = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
		
        return $connection;
    }

    public function _processData($dataArr)
    {	
		$csv  = $dataArr['csv'];
		$head = $dataArr['head'];
        $data = "";
		//*** Convert header from space to _ ***///
		
		foreach ($head as $key => $value):
		
			  if(strtolower($value) == 'limit'):		  
				$value = 'pcap_limit';			
			  endif;
			  
			  $key 			= strtolower(str_replace(' ', '_', $key));		  
			  $head[$key] 	= strtolower(str_replace(' ', '_', $value));			  
			  
			  if($head[$key] == 'updated_date'):		
				$data .= $head[$key].' TIMESTAMP ';
			  else:		  
				$data .= $head[$key]." VARCHAR(255), ";		  
			  endif;
			  
			  $fieldName[] = $head[$key];
			  
		endforeach;			
			
		$csvResult 		 = array_map("array_combine", array_fill(0, count($csv), $head), $csv);
		

		//**** Create Table using Model ***///
		
		// $data 			 		= $data. "id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY ";		
		// $tblData 			   	= array();		
		// $tblData['tablename']  	= self::TABLE_NAME_VALUE;
		// $tblData['head'] 	   	= $data;		
		// $DataResponse			= Mage::getModel('admincontroller/tablecreate')->addData($tblData)->CreateTable(); 
		
		//**** Create Table using Model - End ***///	
		
		
		//**** Save file in Temp. Table ***///		
		
		$fieldName 		 = implode(",", $fieldName);		
		$saveTempProduct = $this->_saveTemp($csvResult, $fieldName);		
		
		//**** Save file in Temp. Table - End ***///	

		return $saveTempProduct;
	
	}
	
	
	protected function _saveTemp($csvResult, $fieldName)
	{
	

		$count 			= 0;
		$getData 		= array();
		$resData		= array();
		$tablename 		= self::TABLE_NAME_VALUE;	

		
		foreach($csvResult as $_key=>$_value):
		
			$fieldValue 					= null;
			$getData  						= null;
			$getData['pcapid']				= null;
			$getData['pcapname']			= null;
			$getData['pcaplimit']			= 0;
			$getData['extlimit']			= 0;
			$getData['refreshperiod']		= 0;
			$getData['refreshstartdate']	= 0;
			$getData['refreshresetdate']	= 0;		
			$getData['transactiontype'] 	= 0;
			$getData['tendertype'] 			= 0;

			
			foreach($_value as $key=>$value):
			
				if ($key == 'pcapid'):
					$getData['pcapid'] = $value;
					$keyCode = $getData['pcapid'];
				elseif ($key == 'pcapname'):
					$getData['pcapname'] = $value;
				elseif ($key == 'transactiontype'):
					$getData['transactiontype'] = $value;
				endif;
				
				$fieldValue[] = "'".$value."'";	
				
			endforeach;
					
			if(!empty($keyCode)):
			
				if($this->_isChecker($keyCode) == false):
					
					//$getData['tax_type'] 		= $this->_gettaxclass($tax_type);
					
					// $fieldValue = implode(",", $fieldValue);	
					// $sql 		= "INSERT INTO $tablename ($fieldName) VALUES ($fieldValue)";	
					// $this->_getConnection()->query($sql);
					
					$this->_saveData($getData);
					
					$count++;
					
					$resData[] = array("pcapname"=>$getData['pcapname'],"pcapid"=>"$keyCode","status"=>1);
					
				else:
				
					$resData[] = array("pcapname"=>$getData['pcapname'],"pcapid"=>"$keyCode","status"=>0);
					
				endif;
			
			endif;
			
		endforeach;	
		
		return $resData;

	}
	
	protected function _gettaxclass($tax_type)
	{	
		$unilabTypeSql 		= "SELECT class_id FROM tax_class WHERE class_name LIKE '$tax_type'";						
		$unilabResult 	= $this->_getConnection()->fetchRow($unilabTypeSql);	
		
		return $unilabResult['class_id'];		
	}	
	

	
	protected function _isChecker($keyCode)
	{
	
		$sql 				= "SELECT * FROM rra_emp_purchasecap WHERE purchase_cap_id LIKE '$keyCode'";						
		$AccIdresult 		= $this->_getConnection()->fetchAll($sql);					
		$total_rows 		= count($AccIdresult);	

		if($total_rows == 0):
			$response = false;
		else:
			$response = true;		
		endif;
		
		return $response;
		
	}
	
	protected function _isgetcompanyID($keyCode)
	{
	
		$sql 				= "SELECT customer_group_id FROM customer_group WHERE company_code='$keyCode'";						
		$AccIdresult 		= $this->_getConnection()->fetchRow($sql);					

		return $AccIdresult['customer_group_id'];
		
	}	
	
	
	protected function _getrefreshperiod($keyCode)
	{	
		$unilabTypeSql 		= "SELECT option_id FROM eav_attribute_option_value WHERE value LIKE '$keyCode'";						
		$unilabResult 	= $this->_getConnection()->fetchRow($unilabTypeSql);	
		
		return $unilabResult['option_id'];		
	}	
	
	protected function _isgetTransactionID($keyCode)
	{
	
		$sql 				= "SELECT id FROM rra_transaction_type WHERE transaction_name LIKE '%$keyCode%'";						
		$AccIdresult 		= $this->_getConnection()->fetchRow($sql);					

		return $AccIdresult['id'];
		
	}		
	
	
	protected function _saveData($getData)
	{
	

		$transactionID 		= $this->_isgetTransactionID($getData['transactiontype']);
				
		try {
		
			$this->_getConnection()->beginTransaction();	
			
			$refreshstartdate = strtotime($getData['refreshstartdate']);
			$refreshresetdate = strtotime($getData['refreshresetdate']);
			
			//*** Insert data to rra_emp_purchasecap Purchase Cap
			$fields 						= array();
			$fields['purchase_cap_id']		= $getData['pcapid'];
			$fields['purchase_cap_des']		= $getData['pcapname'];
			//$fields['purchase_cap_limit']	= $getData['pcaplimit'];
			//$fields['extension_amount']		= $getData['extlimit'];
			$fields['tnx_id']				= $transactionID;
			//$fields['start_date']			= date('Y-m-d',$refreshstartdate);
			//$fields['end_date']				= date('Y-m-d',$refreshresetdate);
			$fields['created_time']			= date("Y-m-d H:i:s");
			$fields['update_time']			= date("Y-m-d H:i:s");
			$this->_getConnection()->insert('rra_emp_purchasecap', $fields);
			$this->_getConnection()->commit();				
		
			
			}catch(\Exception $e){

			    $this->messageManager->addError(__($e->getMessage()));
				// Mage::log($e->getMessage(), null, 'purchasecap.log');
			}	
				
					
	}
    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return true;
    }

}
