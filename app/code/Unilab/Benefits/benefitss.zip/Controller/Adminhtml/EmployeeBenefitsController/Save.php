<?php

/**
 * Grid Admin Cagegory Map Record Save Controller.
 * @category  Unilab
 * @package   Unilab_Grid
 * @author    Unilab
 * @copyright Copyright (c) 2010-2016 Unilab Software Private Limited (https://Unilab.com)
 * @license   https://store.Unilab.com/license.html
 */
namespace Unilab\Benefits\Controller\Adminhtml\EmployeeBenefitsController;

use Magento\Framework\Controller\ResultFactory;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Unilab\Grid\Model\GridFactory
     */
    var $gridFactory;
    protected $resourceConnection;
    protected $coreRegistry;
    protected $backendSession;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Unilab\Grid\Model\GridFactory $gridFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Unilab\Benefits\Model\EmployeeBenefitFactory $gridFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Backend\Model\Session $backendSession,
        ResultFactory $resultFactory
    ) {
        parent::__construct($context);
        $this->gridFactory = $gridFactory;
        $this->resourceConnection = $resourceConnection;
        $this->coreRegistry = $coreRegistry;
        $this->resultFactory = $resultFactory;
        $this->backendSession = $backendSession;
    }

    /**
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('unilab_benefits/EmployeeBenefitsController/create');
            return;
        }
        try {
            // var_dump($data);
            $rowData = $this->gridFactory->create();
            $rowData->setData($data);
            $save = true;

            if (isset($data['id'])) {
                //edit
                $rowData->setId($data['id']);
            }
            else {
                //create
                $rowData->setCreatedTime(date('Y-m-d H:i:s'));
            }

            $rowData->setUpdateTime(date('Y-m-d H:i:s'));

            $connection = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
            $emp_id = $data['emp_id'];
            $selectEntity = $connection->select()->from('customer_entity_varchar', array('*'))->where('value=?',$emp_id); 
                
            $rowEntity = $connection->fetchRow($selectEntity);
            
            if(empty($rowEntity['entity_id'])):
                $save = false;
            endif;

            if($save){
                $rowData->save();
                $this->messageManager->addSuccess(__('Benefit has been successfully saved.'));
                $this->_redirect('unilab_benefits/EmployeeBenefitsController');
            }else{
                $this->coreRegistry->register('row_data', $rowData);
                $this->messageManager->addError(__("Employee ID $emp_id does not exist."));
                $this->backendSession->setData('create_benefit', $data);

                $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                $resultRedirect->setPath('*/*/create', ['params' => $data]);
                
                return $resultRedirect;
            }
            
            
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
            $this->_redirect('unilab_benefits/EmployeeBenefitsController');
        }
        
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Unilab_Benefits::save');
    }
}
