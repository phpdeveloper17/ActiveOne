<?php
/**
 * Movshipping Logger php.
 * @category  Unilab
 * @package   Unilab_Movshipping
 * @author    Ron Mark Peroso Rudas   
 */
namespace Unilab\Benefits\Logger;

class Logger extends \Monolog\Logger
{

}
