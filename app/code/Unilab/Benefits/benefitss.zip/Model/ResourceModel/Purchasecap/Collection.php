<?php
namespace Unilab\Benefits\Model\ResourceModel\Purchasecap;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	// protected $_eventPrefix = 'unilab_benefits_Purchasecaps_collection';
	// protected $_eventObject = 'Purchasecaps_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	public function __construct(
		\Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\DB\Adapter\AdapterInterface $connection = null,
        \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null
	) 
	{
		$this->_init(
			'Unilab\Benefits\Model\Purchasecap', 
			'Unilab\Benefits\Model\ResourceModel\Purchasecap');
		parent::__construct(
            $entityFactory, $logger, $fetchStrategy, $eventManager, $connection,
            $resource
        );
        $this->storeManager = $storeManager;
	}

	protected function _construct()
	{
		
	}

	public function _initSelect() 
	{
		parent::_initSelect();

		$this->getSelect()->columns('(SELECT group_concat(transaction_name) FROM rra_transaction_type WHERE FIND_IN_SET(rra_transaction_type.id, main_table.tnx_id)) AS transaction_name');

	}

}