<?php

namespace Unilab\Benefits\Model\ResourceModel\EmployeeBenefit;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * Define model & resource model
     */
    const YOUR_TABLE = 'rra_emp_benefits';

    protected $_idFieldName = 'id'; //this field id used to delete [id]=> of maintable[wspi_pricelist]

    public function __construct(
        \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\DB\Adapter\AdapterInterface $connection = null,
        \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null
    ) {
        $this->_init(
            'Unilab\Benefits\Model\EmployeeBenefit',
            'Unilab\Benefits\Model\ResourceModel\EmployeeBenefit'
        );
        parent::__construct(
            $entityFactory, $logger, $fetchStrategy, $eventManager, $connection,
            $resource
        );
        $this->storeManager = $storeManager;
        
    }
    protected function _initSelect()
    {
        parent::_initSelect();
        $this->getSelect()->joinLeft(
            ['secondTable' => $this->getTable('customer_entity')],
            ' main_table.entity_id = secondTable.entity_id',
            ['employee_name' => "CONCAT(secondTable.firstname, ' ', secondTable.lastname)"]
        );
        $this->addFilterToMap(
            'employee_name',
            new \Zend_Db_Expr("CONCAT(secondTable.firstname, ' ', secondTable.lastname)")
        );
    }
}
?>