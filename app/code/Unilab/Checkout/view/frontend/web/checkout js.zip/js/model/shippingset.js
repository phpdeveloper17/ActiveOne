define([
    'ko'
], function (ko) {
    'use strict';

    return ko.observable();
});