<?php

namespace Unilab\Catalog\Block\Product\View;

class Description {
    
}