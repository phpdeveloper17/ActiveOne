<?php
namespace Unilab\Webservice\Helper;

class Events extends \Magento\Framework\App\Helper\AbstractHelper {

	
	const CREATE_CUSTOMER 				= 'CreateCustomer';//.3
	const UPDATE_CUSTOMER 				= 'UpdateCustomer';//.4
	const CREATE_CUSTOMER_ADDRESS 		= 'CreateCustomerAddress';//.
	const UPDATE_CUSTOMER_ADDRESS 		= 'UpdateCustomerAddress';//.
	const CREATE_EMPLOYEE 				= 'CreateEmployee';//.
	const UPDATE_EMPLOYEE 				= 'UpdateEmployee';//.
	const CREATE_EMPLOYEE_BENEFIT 		= 'CreateEmployeeBenefit';//.
	const UPDATE_EMPLOYEE_BENEFIT 		= 'UpdateEmployeeBenefit';//.
	const CREATE_PRICELIST 				= 'CreatePricelist';//.
	const UPDATE_PRICELIST 				= 'UpdatePricelist';//.
	const PROCESS_ORDER 				= 'ProcessOrder';//.
	const COMPLETE_ORDER 				= 'CompleteOrder';//.
	const CANCEL_ORDER					= 'CancelOrder';//.
	const CREATE_PRODUCT 				= 'CreateProduct';//.1
	const UPDATE_PRODUCT 				= 'UpdateProduct';//.2
	const CREATE_PRODUCT_PRICE_LIST 	= 'CreateProductPriceList';//.13
	const UPDATE_PRODUCT_PRICE_LIST 	= 'UpdateProductPriceList';//.14
	const UPDATE_PRODUCT_STATUS 		= 'UpdateProductStatus';//.

	/**
	 * TEST EVENTS
	 */

	const TEST_BENEFITS 				= 'TestBenefits';
	const TEST_EMPLOYEE 				= 'TestEmployee';
	const TEST_CUSTOMER_GROUP			= 'TestCustomerGroup';
	const TEST_PRICELIST 				= 'TestPricelist';
	const TEST_PRODUCT					= 'TestProduct';

}
