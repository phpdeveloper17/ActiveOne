<?php

namespace Unilab\Webservice\Helper;

class Log {

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        $this->_connection = $resourceConnection;
    }


    protected function _getConnection()
    {
        return $this->_connection->getConnection('core_write');
    }

    public function createlogs($id,$from,$cmdEvent,$status,$message,$type){
		$connection = $this->_getConnection();
		$currentdate = date("Y-m-d H:i:s");  
		$data = array(
					'transaction_id' 	=>  $id,
					'cmdEvent'			=>	$cmdEvent,
					'data_from'			=>	$from,
					'status' 			=>  $status,
					'logs'				=>  $message,
					'date'				=>	$currentdate,
					'type'				=> 	$type
		);
		$connection->insert('unilab_logs_netsuite', $data);

	}
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
}