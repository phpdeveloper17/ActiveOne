<?php
namespace Unilab\Webservice\Ui\Component\Listing\Token\Column;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\App\ResourceConnection;

class StoreName extends Column{

    protected $connection;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        array $components = [],
        ResourceConnection $resource,
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->_resource = $resource;
        $this->_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    }

    public function prepareDataSource(array $dataSource)
    {
       
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$items) {
                $storename = $this->getStoreName($items['store']);
                $items['store'] = $storename['name'];
            }
        }
        return $dataSource;
    }
    public function getStoreName($store_id)
    {
        $connectdb = $this->_resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        $fields = array('store_id', 'name');
        $sql = $connectdb->select()
                  ->from('store',$fields)
                  ->where('store_id = ?', $store_id);
        $data = $connectdb->fetchRow($sql);
        return $data;
    }
    
}