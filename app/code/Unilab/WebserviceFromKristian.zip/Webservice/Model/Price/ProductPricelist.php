<?php
namespace Unilab\Webservice\Model\Price;

class ProductPricelist{
    protected $resourceConnection;
    private $logger;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
		\Unilab\Webservice\Model\Validate\Category $Category,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Group $Group

    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_category = $Category;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_group = $Group;
        $this->_getConnection   = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

    }
    public function execute(){
    }
    public function create()
	{
		// validate SKU
		$product_id = $this->_objectManager->create('Magento\Catalog\Model\Product')->getIdBySku($_POST['product_sku']);
		if(!$product_id){
			$response['success'] 		= false;
			$response['Errhandler'] 	= "SKU does not exist";
		}else{	
			try{
				$this->_getConnection->beginTransaction();	
				//*** Insert data to rra_pricelistproduct
				$fields 							= array();
				$fields['pricelist_id']				= $_POST['pricelist_id'];
				$fields['product_sku']				= $_POST['product_sku'];
				$fields['product_name']				= $_POST['product_name'];
				$fields['unit_price']				= $_POST['unit_price'];
				$fields['qty_from']					= $_POST['qty_from'];
				$fields['qty_to']					= $_POST['qty_to'];
				$fields['discount_in_amount']		= $_POST['discount_in_amount'];
				$fields['discount_in_percent']		= $_POST['discount_in_percent'];
				$fields['from_date']				= $_POST['from_date'];
				$fields['to_date']					= $_POST['to_date'];
				$this->_getConnection->insert('rra_pricelistproduct', $fields);

				$lastInsertId = $this->_getConnection->lastInsertId();
				$this->_getConnection->commit();				

				$response['success'] 	= true;
				$response['id'] 		= $lastInsertId;
				$response['MsgHndler'] 	= "Product Price List was successfully added!";

			}catch(\Exception $e){
				
				$response['success'] 	= false;
				$response['Errhandler'] = $e->getMessage();
			}	
		}
		return $response;
	}
    public function update()
	{
		$this->_getConnection->beginTransaction();
		$productpricelist 	= $this->_objectManager->create('Unilab\Benefits\Model\Productpricelist')->getCollection();
		$productpricelist	->addFieldToFilter('id',$_POST['id']);
			
		$productpricelistData			= $productpricelist->getData();	
		$productpricelistcount 			= count($productpricelistData);

		$product_id = $this->_objectManager->create('Magento\Catalog\Model\Product')->getIdBySku($_POST['product_sku']);
		if($productpricelistcount == null)
		{
			$response['success'] 		= false;
			$response['Errhandler'] 	= "Product Price List does not exist";
		}
		elseif(!$product_id){
			$response['success'] 		= false;
			$response['Errhandler'] 	= "SKU does not exist";
			
		}
		else{
			try{
				$fields 							= array();
				$fields['pricelist_id']				= $_POST['pricelist_id'];
				$fields['product_sku']				= $_POST['product_sku'];
				$fields['product_name']				= $_POST['product_name'];
				$fields['unit_price']				= $_POST['unit_price'];
				$fields['qty_from']					= $_POST['qty_from'];
				$fields['qty_to']					= $_POST['qty_to'];
				$fields['discount_in_amount']		= $_POST['discount_in_amount'];
				$fields['discount_in_percent']		= $_POST['discount_in_percent'];
				$fields['from_date']				= $_POST['from_date'];
				$fields['to_date']					= $_POST['to_date'];

				$where = array($this->_getConnection->quoteInto('id=?',$_POST['id']));
				$this->_getConnection->update('rra_pricelistproduct', $fields, $where);
				$this->_getConnection->commit();	
			
				$response['success'] 	= true;
				$response['MsgHndler'] = "Product Price List was successfully updated!";
				// $response['productpricelistdetails'] = $fields;
			}catch(\Exception $e){
				$response['success'] 	= false;
				$response['Errhandler'] = $e->getMessage();
			}	
		}
		return $response;
    }
    public function delete()
	{
		$this->_getConnection->beginTransaction();
		$productpricelist 	= $this->_objectManager->create('Unilab\Benefits\Model\Productpricelist')->getCollection();
		$productpricelist	->addFieldToFilter('id',$_POST['id']);
		$productpricelistData			= $productpricelist->getData();	
		$productpricelistcount 			= count($productpricelistData);

		if($productpricelistcount == null)
		{
			$response['success'] 		= false;
			$response['Errhandler'] 	= "Product Price List does not exist";
		}else{
			try{
				$fields 				= array();
				$where 					= array($this->_getConnection->quoteInto('id=?',$_POST['id']));

				$this->_getConnection->delete('rra_pricelistproduct', $where);
				$this->_getConnection->commit();	
			
				$response['success'] 	= true;
				$response['MsgHndler'] = "Product Price List successfully deleted!";
			}catch(\Exception $e){
				
				$response['success'] 	= false;
				$response['Errhandler'] = $e->getMessage();
			}	
		}
		return $response;
    }
    public function showdata()
	{
		$this->_getConnection->beginTransaction();
		$productpricelist 	= $this->_objectManager->create('Unilab\Benefits\Model\Productpricelist')->getCollection();
		$productpricelist	->addFieldToFilter('id',$_POST['id']);
		$response	= $productpricelist->getData();	
		return $response;

	}
}
?>