<?php
namespace Unilab\Webservice\Model\Price;

class Pricelevel{
    protected $resourceConnection;
    private $logger;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
		\Unilab\Webservice\Model\Validate\Category $Category,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Group $Group

    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_category = $Category;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_group = $Group;
        $this->_getConnection   = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

    }
    public function execute(){
    }
    public function create()
    {
        $this->_getConnection->beginTransaction();
		$pricelevelcollection 	= $this->_objectManager->create('Unilab\Benefits\Model\Pricelevel')->getCollection();
		$pricelevelcollection	->addFieldToFilter('price_level_id',$_POST['price_level_id']);
		$pricelevelData			= $pricelevelcollection->getData();
		$pricelevelcount 		= count($pricelevelData);

		if($pricelevelData != null)
		{
		$response['success'] 	= false;
		$response['ErrHndler'] 	= "Price Level already exists";	

		}else{
			try{
				
				//*** Insert data to rra_pricelevelmaster
				$fields 					= array();
				$fields['price_level_id']	= $_POST['price_level_id'];
				$fields['price_name']		= $_POST['price_name'];
				$fields['is_active']		= $_POST['is_active'];
				$fields['created_time']		= date("Y-m-d H:i:s");
				$fields['update_time']		= date("Y-m-d H:i:s");
				$this->_getConnection->insert('rra_pricelevelmaster', $fields);
				
					if($fields['is_active'] == 1){
						$active = "Yes";
					}else{
						$active = "No";
					}

				$lastInsertId = $this->_getConnection->lastInsertId();
				$this->_getConnection->commit();	

				$newpricelevels['id']					=	$lastInsertId;
				$newpricelevels['price_level_id']		=	$fields['price_level_id'];
				$newpricelevels['price_name']			=	$fields['price_name'];
				$newpricelevels['is_active']			=	$active;
				$newpricelevels['created_time']			=	date("Y-m-d H:i:s");
				$newpricelevels['update_time']			=	date("Y-m-d H:i:s");

				$response['success'] 	= true;
				$response['id'] 	= $lastInsertId;
				$response['MsgHndler'] = "Price Level was successfully added!";
 				// $response['pricelevelDetails'] = $newpricelevels;
								  
			}catch(\Exception $e){
				
				$response['success'] 	= false;
				$response['Errhandler'] = $e->getMessage();
			}
		}	

		return $response;
    }
    public function update()
	{
		$this->_getConnection->beginTransaction();
		$pricelevelcollection 	= $this->_objectManager->create('Unilab\Benefits\Model\Pricelevel')->getCollection();
		$pricelevelcollection	->addFieldToFilter('id',$_POST['id']);

		$pricelevelData			= $pricelevelcollection->getData();	
		$pricelevelcount 		= count($pricelevelData);
		
		if($pricelevelcount == null)
		{
			$response['success'] 		= false;
			$response['Errhandler'] 	= "Price Level does not exist";	

		}else{

			try{
				
				$fields 					= array();
				$fields['price_level_id']	= $_POST['price_level_id'];
				$fields['price_name']		= $_POST['price_name'];
				$fields['is_active']		= $_POST['is_active'];
				$fields['update_time']		= date("Y-m-d H:i:s");
				$where = array($this->_getConnection->quoteInto('id=?',$_POST['id']));
				$this->_getConnection->update('rra_pricelevelmaster', $fields, $where);
				$this->_getConnection->commit();	
			
					if($fields['is_active'] == 1){
								$active = "Yes";
						}else{
							$active = "No";
						}

				$response['success'] 	= true;
				$response['MsgHndler'] = "Pricelevel successfully updated!";
				// $response['updatedpricelevelDetails'] = $fields;

			}catch(Exception $e){
				$response['success'] 	= false;
				$response['Errhandler'] = $e->getMessage();
			}	
        }
        
	    return $response;
    }
    public function delete()
	{
		$this->_getConnection->beginTransaction();
		$pricelevelcollection 	= $this->_objectManager->create('Unilab\Benefits\Model\Pricelevel')->getCollection();
		$pricelevelcollection	->addFieldToFilter('id',$_POST['id']);

		$pricelevelData			= $pricelevelcollection->getData();	
		$pricelevelcount 		= count($pricelevelData);
		
		if($pricelevelcount == null)
		{
			$response['success'] 		= false;
			$response['Errhandler'] 	= "Price Level does not exist";		
				
		}else{
			try{

				$where = array($this->_getConnection->quoteInto('id=?',$_POST['id']));
				$this->_getConnection->delete('rra_pricelevelmaster', $where);
				$this->_getConnection->commit();	
			
				$response['success'] 	= true;
				$response['MsgHndler'] = "Pricelevel successfully deleted!";
			}catch(\Exception $e){
				$response['success'] 	= false;
				$response['Errhandler'] = $e->getMessage();
			}
		}
		return $response;
    }
    public function showdata()
	{

		$this->_getConnection->beginTransaction();
		$pricelevelcollection 	= $this->_objectManager->create('Unilab\Benefits\Model\Pricelevel')->getCollection();
		$pricelevelcollection	->addFieldToFilter('id',$_POST['id']);
		$response				= $pricelevelcollection->getData();	
		return $response;
	}
}
?>