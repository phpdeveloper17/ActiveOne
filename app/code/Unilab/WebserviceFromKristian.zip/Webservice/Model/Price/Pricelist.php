<?php
namespace Unilab\Webservice\Model\Price;

class Pricelist{
    protected $resourceConnection;
    private $logger;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
		\Unilab\Webservice\Model\Validate\Category $Category,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Group $Group

    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_category = $Category;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_group = $Group;
        $this->_getConnection   = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

    }
    public function execute(){
    }
    public function create(){
		
		$resData				= array();
		$getDataskus  			= $this->_getskulist();
		$price_level_id  		= $this->_isprice_level_id();
		$company_id  			= $this->_iscompany_id();		

		$discountEnable 		= 0;
		$discountEnableAmount 	= 0;
		$sub_simple_action 		= null;	
		$from_date 				= strtotime($_POST['from_date']);
		$to_date 				= strtotime($_POST['to_date']);	
		$sku 					= null;
		if(empty($company_id)):
			$company_id = 0;
		endif;
        if(!isset($_POST['limit_days'])){
        $_POST['limit_days'] = "everyday";
        }
		try {
			foreach ($getDataskus as $value) {
				if(!empty($value['product_sku'])):
					$sku .= $value['product_sku'].",";
				endif;
			}

			$price_id 			= $_POST['price_id'];
			$description 		= $_POST['price_id'];
			$websiteId 			= 1; 
			$customerGroupId 	= $company_id; 
			$actionType 		= 'by_percent';
			$discountEnable 	= 0;
			$discount			= 0;

			if($this->_issku($price_level_id, $price_id, $sku) == false):

				$catalogPriceRule = $this->_objectManager->create('Magento\CatalogRule\Model\Rule');
				$catalogPriceRule->setName($price_id)
								 ->setDescription($description)
								 ->setIsActive($_POST['is_active'])
								 ->setWebsiteIds(array($websiteId))
								 ->setCustomerGroupIds(array($customerGroupId))
								 ->setFromDate(date('Y-m-d',$from_date))
								 ->setToDate(date('Y-m-d',$to_date))
								 ->setSortOrder('')
								 ->setfrom_qty($_POST['from_qty'])
								 ->setto_qty($_POST['to_qty'])
								 ->setprice_level_id($price_level_id)
								 ->setlimit_days(strtolower($_POST['limit_days']))
								 ->setlimit_time_from($_POST['limit_time_from'])
								 ->setlimit_time_to($_POST['limit_time_to'])
								 ->setSimpleAction($actionType)
								 ->setStopRulesProcessing(0)
								 ->setDiscountAmount($discount)
								 ->setprod_sku(md5($sku));
							
                $skuCondition = $this->_objectManager->create('Magento\CatalogRule\Model\Rule\Condition\Product')
                                ->setType('Magento\CatalogRule\Model\Rule\Condition\Product')
								->setAttribute('sku')
								->setOperator('()')
								->setValue(substr($sku, 0, -1));
									//*** Set for is one of ***//									
									//->setOperator('()')
									
				$catalogPriceRule->getConditions()->addCondition($skuCondition);

				$catalogPriceRule->save();

				//$catalogPriceRule->applyAll();	

				// Mage::app()->removeCache('catalog_rules_dirty');
                
                $coreSession = $this->_objectManager->get('\Magento\Framework\Session\SessionManagerInterface');
				$coreSession->setStatussave(0);

				$response['success'] 	= true;
				$response['id'] 		= $catalogPriceRule->getId();				
				$response['MsgHndler'] 	= "Price List was successfully added!";						

			else:
                $coreSession = $this->_objectManager->get('\Magento\Framework\Session\SessionManagerInterface');
				$coreSession->setStatussave(0);
				$response['success'] 	= false;
				$response['Errhandler'] = "Price List Already Exists!";	
			endif;
		}catch(Exception $e){
			$response['success'] 	= false;
			$response['Errhandler'] = $e->getMessage();		
		}
		return $response;
	}
	protected function _getskulist(){
		$pricelist_id	= $_POST['price_id'];
		$SKUs			= null;
		$sql 			= "SELECT * FROM rra_pricelistproduct WHERE pricelist_id LIKE '$pricelist_id'";						
		$AccIdresult 	= $this->_getConnection->fetchAll($sql);	
		return $AccIdresult;
							}	
	
	protected function _isprice_level_id()
	{
		$price_level_id = $_POST['price_level_id'];
		$sql 			= "SELECT id FROM rra_pricelevelmaster WHERE price_level_id LIKE '$price_level_id'";						
		$AccIdresult 	= $this->_getConnection->fetchRow($sql);					
		return $AccIdresult['id'];
	}	
	
	protected function _iscompany_id()
	{
		$company_code = $_POST['company_code'];
		try{
			$sql 		 = "SELECT customer_group_id FROM customer_group WHERE company_code LIKE '$company_code'";						
			$AccIdresult = $this->_getConnection->fetchRow($sql);					
		}catch (\Exception $e){
            file_put_contents($increment_id.'./Addpricelist.log', print_r($e->getMessage(),1).PHP_EOL,FILE_APPEND);
		}
		return $AccIdresult['customer_group_id'];
		
	}		
	
	protected function _issku($price_level_id, $price_id, $sku)
	{
		$sku 			= md5($sku);
		$sql 			= "SELECT rule_id FROM catalogrule WHERE price_level_id LIKE '$price_level_id' AND  name LIKE '$price_id' AND prod_sku='$sku'";								
		$AccIdresult 	= $this->_getConnection->fetchRow($sql);					
		if(empty($AccIdresult['rule_id'])):
			$response = false;
		else:
			$response = true;		
		endif;
		return $response;
    }
    public function delete()
	{
		
        $this->_getConnection->beginTransaction();
        $catalogPriceRule = $this->_objectManager->create('Magento\CatalogRule\Model\Rule');	
		$catalogruleID		= $catalogPriceRule->load($_POST['id']);
		$response['Name'] 	= $catalogruleID->getName();
		try{
			if($catalogruleID->getId()){
				$where 					= array($this->_getConnection->quoteInto('rule_id=?',$_POST['id']));
				$this->_getConnection->delete('catalogrule', $where);
				$this->_getConnection->commit();	
				$response['success'] 	= true;
				$response['MsgHndler'] 	= "Price List was successfully deleted!";
			}else{
				$response['success'] 	= false;
				$response['Errhandler'] = "Price List Not Exists!";
			}
		}catch(\Exception $e){
			
			$response['success'] 	= false;
			$response['Errhandler'] = $e->getMessage();
		}	

		return $response;
    }
    public function update()
	{
		
		$this->_getConnection->beginTransaction();	
        $catalogPriceRule = $this->_objectManager->create('Magento\CatalogRule\Model\Rule');	
        $catalogruleID		= $catalogPriceRule->load($_POST['id']);
		$response['Name'] 	= $catalogPriceRule->getName();
		$price_level_id  		= $this->_isprice_level_id();
		$company_id  			= $this->_iscompany_id();		
		$from_date 				= strtotime($_POST['from_date']);
		$to_date 				= strtotime($_POST['to_date']);	
		if(empty($company_id)):
			$company_id = 0;
		endif;

		$name 				= $_POST['price_id'];
		$description 		= $_POST['price_id'];
		$customerGroupId 	= $company_id; 	
		try{
			
			if($catalogruleID->getId()){
									
				$fields 					= array();
				$fields['description']		= $_POST['price_id'];
				$fields['name']				= $_POST['price_id'];
				$fields['is_active']		= $_POST['is_active'];
				$fields['from_date']		= date('Y-m-d',$from_date);
				$fields['to_date']			= date('Y-m-d',$to_date);
				$fields['from_qty']			= $_POST['from_qty'];
				$fields['to_qty']			= $_POST['to_qty'];
				$fields['price_level_id']	= $price_level_id;
				$fields['limit_days']		= strtolower($_POST['limited_days']);
				$fields['limit_time_from']	= $_POST['limit_time_from'];
				$fields['limit_time_to']	= $_POST['limit_time_to'];
				$where = array($this->_getConnection->quoteInto('rule_id=?',$_POST['id']));
				$this->_getConnection->update('catalogrule', $fields, $where);
				$this->_getConnection->commit();	

				$fields 						= array();
				$fields['customer_group_id']	= $customerGroupId ;
				$where = array($this->_getConnection->quoteInto('rule_id=?',$catalogPriceRule->getId()));
				$this->_getConnection->update('catalogrule_customer_group', $fields, $where);
				$this->_getConnection->commit();	
				
				$response['success'] 	= true;
				$response['Name'] 		= $catalogPriceRule->getName();
				$response['MsgHndler'] 	= "Price List was successfully updated!";
			}else{
				$response['success'] 	= false;
				$response['Errhandler'] = "Price List Not Exists!";
			}
		}catch(Exception $e){
			$response['success'] 	= false;
			$response['Errhandler'] = $e->getMessage();
		}	
		return $response;
    }
    public function showdata()
	{	

		// $response	= $this->_objectManager->create('Magento\CatalogRule\Model\Rule')->load($_POST['id']);
		// return $response;


		 try{

		$response 	= $this->_objectManager->get('Magento\CatalogRule\Model\Rule')->load($_POST['id']);

				}
		catch(Exception $e){
			
				$response['success'] 	= false;
				$response['ErrHndler'] = $e->getMessage();
				}	
				return $response;
	}
}
?>