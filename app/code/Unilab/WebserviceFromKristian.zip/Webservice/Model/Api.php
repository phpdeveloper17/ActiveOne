<?php

/**
 * Copyright 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Unilab\Webservice\Model;

// use Unilab\Webservice\Api\AonewebserviceInterface;
use Magento\Framework\App\RequestInterface;

/**
 * Defines the implementaiton class of the calculator service contract.
 */
class Api
{
    protected $_resource;
    public function __construct(
            \Magento\Framework\App\ResourceConnection $resource,
            \Unilab\Webservice\Model\TokenFactory $tokenFactory,
			RequestInterface $request,
			\Magento\Framework\Json\Helper\Data $jsonHelper
			

        ) {
            $this->_resource 		= $resource;
            $this->_tokenFactory 	= $tokenFactory;
			$this->request 			= $request;
			$this->jsonHelper		= $jsonHelper;
        }
    // public function execute(){

    //     // $data['token'] = 'NTI2YmFiNGQ5ODMxMDdjOThjYzBiYjY2M2UxNWE1NGM6bG9jYWxob3N0';
        
    //     // $isTokenValid  = $this->validateToken($data['token']);

    //     // if($isTokenValid['token_result'] >= 1){

    //     //     $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/isTokenValid.log');
    //     //     $logger = new \Zend\Log\Logger();
    //     //     $logger->addWriter($writer);
    //     //     $logger->info(json_encode($isTokenValid));

    //     // }

	// }
	public function testToken(){

        $data['token'] = 'NTI2YmFiNGQ5ODMxMDdjOThjYzBiYjY2M2UxNWE1NGM6bG9jYWxob3N0';
        $post['cmdEvent'] = "CreateProduct";
		$post['product_name'] = "Alaxan";
		$post['token'] = 'NTI2YmFiNGQ5ODMxMDdjOThjYzBiYjY2M2UxNWE1NGM6bG9jYWxob3N0'; print_r($post);
		//$postData = $this->jsonHelper->jsonDecode($post, True);

		$_tokenFactory = $this->_tokenFactory->create()->getCollection();
		$_tokenFactory->addFieldToFilter('token','NTI2YmFiNGQ5ODMxMDdjOThjYzBiYjY2M2UxNWE1NGM6bG9jYWxob3N0')->load();
		print_r($_tokenFactory->getData());
    }

    public function validateToken(){
		$post			= $this->request->getContent();
		// $post = $this->request->getPostValue();
		// echo "<pre>";
		// 	print_r($post);
		// echo "</pre>";
		if(empty($post)){
			$response['ErrHndler'] 	= "Function Not Exist!";
			$response['success'] 	= false;
			
		}else{
			$postData 			= $this->jsonHelper->jsonDecode($post);

			$_tokenFactory  = $this->_tokenFactory->create()->getCollection();
			$_tokenFactory  ->addFieldToFilter('token',$postData['token'])
							->load();
			if(!empty(@$_tokenFactory->getData()[0]['id']) && (@$_tokenFactory->getData()[0]['is_active']== true)){

				$response['MsgHndler'] 	= $_tokenFactory->getData()[0]['token'];
				$response['success'] 	= true;
				
			}elseif(@$_tokenFactory->getData()[0]['is_active']== false && !empty(@$_tokenFactory->getData()[0]['id'])){
				
				$response['ErrHndler'] 	= "This token was inactive. Please contact support.";
				$response['success'] 	= false;			
			}
			else{
				
				$response['AppDate'] = Date("Y-m-d H:i:s");

				$response['ErrHndler'] 	= "Invalid Token, Host name or API is currently disabled. Please contact support.";
				$response['success'] 	= false;
			}

		}
							
		if($response['success'] == false){				
			echo $this->jsonHelper->jsonEncode($response);		
			exit();
		}

		return $response;

	}
}