<?php
namespace Unilab\Webservice\Model;
class Logs extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'unilab_webservice_logs';

	protected $_cacheTag = 'unilab_webservice_logs';

	protected $_eventPrefix = 'unilab_webservice_logs';

	protected function _construct()
	{
		$this->_init('Unilab\Webservice\Model\ResourceModel\Logs');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}


	// public function getTokenId()
    // {
    //     return $this->getData('id');
    // }
    // public function setTokenId($tokenid)
    // {
    //     return $this->setData('id', $tokenid);
	// }

	// public function getHostName()
    // {
    //     return $this->getData('host_name');
    // }
    // public function setHostName($host_name)
    // {
    //     return $this->setData('host_name', $host_name);
	// }
	
	// public function getReturnUrl()
    // {
    //     return $this->getData('return_url');
    // }
    // public function setReturnUrl($return_url)
    // {
    //     return $this->setData('return_url', $return_url);
	// }
	
	// public function getToken()
    // {
    //     return $this->getData('token');
    // }
    // public function setToken($token)
    // {
    //     return $this->setData('token', $token);
	// }

	// public function getIsActive()
    // {
    //     return $this->getData('is_actie');
    // }
    // public function setIsActive($IsActive)
    // {
    //     return $this->setData('is_actie', $IsActive);
	// }

	// public function getDateCreated()
    // {
    //     return $this->getData('date_created');
    // }
    // public function setDateCreated($date_created)
    // {
    //     return $this->setData('date_created', $date_created);
	// }

	// public function getDateUpdated()
    // {
    //     return $this->getData('date_updated');
    // }
    // public function setDateUpdated($date_updated)
    // {
    //     return $this->setData('date_updated', $date_updated);
	// }
	

}