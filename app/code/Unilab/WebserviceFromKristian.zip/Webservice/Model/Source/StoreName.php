<?php

namespace Unilab\Webservice\Model\Source;

use Magento\Framework\App\ResourceConnection;
class StoreName implements \Magento\Framework\Option\ArrayInterface{

    protected $connection;
    protected $_resource;

    public function __construct(
        ResourceConnection $resource
    ) {
        $this->_resource = $resource;
    }
    public function getAllOptions()
    {
		$connection = $this->getConnection();
		$connection->beginTransaction();
		//Search agree terms from customer_entity_varchar
		$selectPricelevel 	=	$connection->select()->from('store', array('*')); 
		$priceLV 			=	$connection->fetchAll($selectPricelevel);
		$priceLevel[] = array();
		foreach($priceLV as $val):
			$priceLevel[] = array('value'=> $val['name'],'label'=> __($val['name']));
		endforeach;
        $connection->commit();
		return $priceLevel;
    }
	
	public function toOptionArray()
    {
        return $this->getAllOptions();

    }
    
    protected function getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->_resource->getConnection('core_write');
        }
        return $this->connection;
    }
}
