<?php
namespace Unilab\Webservice\Model\Company\Address;

class CompAddress{
    protected $resourceConnection;
    private $logger;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
		\Unilab\Webservice\Model\Validate\Category $Category,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Group $Group

    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_category = $Category;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_group = $Group;
        $this->_getConnection   = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

    }
    public function execute(){
    }
    public function Addcompanyaddress()
    {
        $companiescollection 	= $this->_objectManager->get('Unilab\Webservice\Model\Companies')->getCollection();
		$companiescollection	->addFieldToFilter('company_code',$_POST['company_code']);
        $companyData 			= $companiescollection->getData();	
        
        try{
            
            if(!empty($companyData[0]['customer_group_id'])){
                
                $this->_getConnection->beginTransaction();

               $fields 						= array();
               $fields['company_id']			= $companyData[0]['customer_group_id'];
               $fields['contact_person']		= $_POST['contact_person'];
               $fields['contact_number']		= $_POST['contact_number'];
               $fields['branch_address']		= $_POST['branch_address'];
               $fields['branch_province']		= $_POST['branch_province'];
               $fields['ship_code']		= $_POST['ship_code'];
               $fields['branch_city']			= $_POST['branch_city'];
               $fields['branch_postcode']		= $_POST['branch_postcode'];
               $fields['shipping_address']		= $_POST['shipping_address'];
               $fields['billing_address']		= $_POST['billing_address'];
               $fields['created_time']			= date("Y-m-d H:i:s");
               $fields['update_time']			= date("Y-m-d H:i:s");
               $this->_getConnection->insert('rra_company_branches', $fields);

               $lastInsertId = $this->_getConnection->lastInsertId();
               $this->_getConnection->commit();

               $response['id']				= $lastInsertId;
               $response['success'] 		= true;
               $response['MsgHndler'] 		= "Company Address was successfully added!";
               
            }else{
               $response['success'] 		= false;
               $response['MsgHndler'] 		= $_POST['company_id']. "- Company ID Not Exist!";				 
            }

           }catch(\Exception $e){
               $response['success'] 	= false;
               $response['ErrHndler'] 	= $e->getMessage();
           }	
       
           
       return $response;

   }
   public function Updatecompanyaddress()
	 {

            $this->_getConnection->beginTransaction();
			$companiesAddcollection = $this->_objectManager->create('Unilab\Benefits\Model\CompanyBranch')->getCollection();
			$companiesAddcollection	->addFieldToFilter('id',$_POST['id']);
			$companyDataAdd			= $companiesAddcollection->getData();	

			if(!$companyDataAdd)
			{
				$response['success'] 	= false;
				$response['ErrHndler'] 	= "Company Address does not exist!";			
			}else{

				 try{

					$fields 						= array();
					$fields['contact_person']		= $_POST['contact_person'];
					$fields['contact_number']		= $_POST['contact_number'];
					$fields['branch_address']		= $_POST['branch_address'];
					$fields['branch_province']		= $_POST['branch_province'];
					$fields['ship_code']			= $_POST['ship_code'];
					$fields['branch_city']			= $_POST['branch_city'];
					$fields['branch_postcode']		= $_POST['branch_postcode'];
					$fields['shipping_address']		= $_POST['shipping_address'];
					$fields['billing_address']		= $_POST['billing_address'];
					$fields['update_time']			= date("Y-m-d H:i:s");
					$where = array($this->_getConnection->quoteInto('id=?',$_POST['id']));
					$this->_getConnection->update('rra_company_branches', $fields, $where);
					$this->_getConnection->commit();	

					$response['success'] 	= true;
					$response['MsgHndler'] = "Company Address successfully updated!";
					// $response['CompanyAddressDetails'] = $fields;
				}catch(\Exception $e){
				$response['success'] 	= false;
				$response['ErrHndler'] = $e->getMessage();
				}	
			}

		return $response;
	}
    public function Deletecompanyaddress()
	 {
	 	$this->_getConnection->beginTransaction();
        $companiesAddcollection = $this->_objectManager->create('Unilab\Benefits\Model\CompanyBranch')->getCollection();
        $companiesAddcollection	->addFieldToFilter('id',$_POST['id']);	

		print_r($companiesAddcollection->getData());
		
		if(!$companiesAddcollection)
		{
			$response['ErrHndler'] 	= "Company Address does not exists!";
			$response['success'] 	= false;

		}else{
			try{
				
				$where = array($this->_getConnection->quoteInto('id=?',$_POST['id']));
				$this->_getConnection->delete('rra_company_branches', $where);
				$this->_getConnection->commit();	
				$response['success'] 	= true;
				$response['MsgHndler'] 	= "Company Address was successfully deleted!";
			}catch(\Exception $e){
				$response['success'] 	= false;
				$response['ErrHndler'] = $e->getMessage();
			}
		}
		
		return $response;		
		
     }
     public function showdata(){
		$this->_getConnection->beginTransaction();
        $companiesAddcollection = $this->_objectManager->create('Unilab\Benefits\Model\CompanyBranch')->getCollection();
        $companiesAddcollection	->addFieldToFilter('id',$_POST['id']);	
		$response	= $companiesAddcollection->getData();	
		
		return $response;

	}
}
?>