<?php
namespace Unilab\Webservice\Model\Company;

class Company{
    protected $resourceConnection;
    private $logger;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
		\Unilab\Webservice\Model\Validate\Category $Category,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Group $Group

    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_category = $Category;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_group = $Group;


    }
    public function execute(){
        $this->_customerGroup = $this->_group->create();

    }

	public function showdata() {

		// $this->_getConnection()->beginTransaction();
			
		$companiescollection 	= $this->_objectManager->get('Unilab\Webservice\Model\Companies')->getCollection();
		$companiescollection	->addFieldToFilter('company_code',$_POST['company_code']);
		$response				= $companiescollection->getData();		
		return $response;

    }
    public function Addcompany()
	 {		 
		 
		 try{
			 
			$this->_group->setData(
				 array('customer_group_code' => $_POST['customer_group_code'],
				 'company_code' => $_POST['company_code'],
				 'tax_class_id' => $_POST['tax_class_id'],
				 'is_active' => $_POST['is_active'],
				 'credit_status' => $_POST['credit_status'],
				 'company_terms' => $_POST['company_terms'],
				 'company_tin' => $_POST['company_tin'],
				 'contact_person' => $_POST['contact_person'],
				 'contact_number' => $_POST['contact_number']
				 ))
				 ->save(); 	
			
				if($_POST['is_active'] == 1){
					$_POST['is_active'] = "Yes";
				}else{
					$_POST['is_active'] = "No";
				}
				if($_POST['credit_status'] == 0){
					$_POST['credit_status'] = "Clear";
				}else{
					$_POST['credit_status'] = "Hold";
				}
				
				$companiescollection 	= $this->_group->getCollection();
				$companiescollection	->addFieldToFilter('company_code',$_POST['company_code']);
				$companyData			= $companiescollection->getData();	
			
				foreach($companyData as $_key => $_value){
						
					foreach($_value as $key => $value){
						if($key == 'customer_group_id'){
							$response['id'] = $value;
						}
					}
				}
				
			  $response['success'] 	= true;
			  $response['MsgHndler'] = "Company was successfully added!";
			  

			}catch(\Exception $e){
				
				$response['success'] 	= false;
				$response['ErrHndler'] = $e->getMessage();
			}	
		
			
		return $response;

	}
    public function Updatecompany()
	 {
            $this->_getConnection   = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
      
    
		 	$this->_getConnection->beginTransaction();
		 		
			$companiescollection 	=  $this->_objectManager->get('Unilab\Webservice\Model\Companies')->getCollection();
			$companiescollection	->addFieldToFilter('company_code',$_POST['old_company_code']);
			$companyData			= $companiescollection->getData();	

			if(!$companyData)
			{
				$response['ErrHndler'] 	= "Company does not exist";
				$response['success'] 	= false;
				
			}else{

				 try{

					$fields 						= array();
					$fields['customer_group_code']	= $_POST['customer_group_code'];
					$fields['company_code']			= $_POST['company_code'];
					$fields['tax_class_id']			= $_POST['tax_class_id'];
					$fields['is_active']			= $_POST['is_active'];
					$fields['credit_status']		= $_POST['credit_status'];
					$fields['company_terms']		= $_POST['company_terms'];
					$fields['company_tin']			= $_POST['company_tin'];
					$fields['contact_person']		= $_POST['contact_person'];
					$fields['contact_number']		= $_POST['contact_number'];
					
					if($_POST['id']){
									
						$where = array($this->_getConnection->quoteInto('customer_group_id=?',$_POST['id']));
						$this->_getConnection->update('customer_group', $fields, $where);
						$this->_getConnection->commit();	

					}else{

									
						$where = array($this->_getConnection->quoteInto('company_code=?',$_POST['old_company_code']));
						$this->_getConnection->update('customer_group', $fields, $where);
						$this->_getConnection->commit();	

					}


					$response['success'] 		= true;
					$response['MsgHndler'] 		= "Company was successfully updated!";
					// $response['CompanyDetails'] = $fields;	


				}catch(Exception $e){
			
				$response['success'] 	= false;
				$response['ErrHndler'] = $e->getMessage();
				}	
		
			}

			
		return $response;

    }
    
    public function Deletecompany()
	 {
        $this->_getConnection   = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

	 	$this->_getConnection->beginTransaction();

	 	$companiescollection 	= $this->_group->getCollection();
		$companiescollection	->addFieldToFilter('company_code',$_POST['company_code']);
		$companyData			= $companiescollection->getData();	

		if(!$companyData)
		{
			$response['success'] 	= false;
			$response['ErrHndler'] 	= "Company does not exist";
					
		}else{
			try{
				
				$where = array($this->_getConnection->quoteInto('company_code=?',$_POST['company_code']));
				$this->_getConnection->delete('customer_group', $where);
				$this->_getConnection->commit();	
			
				$response['success'] 	= true;
				$response['MsgHndler'] = "Company successfully deleted!";

			}catch(Exception $e){
				
				$response['success'] 	= false;
				$response['ErrHndler'] = $e->getMessage();
			}
		}
		
		return $response;
	 }


}
?>