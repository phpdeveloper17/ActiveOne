<?php
namespace Unilab\Webservice\Model\Netsuite;

class Category{
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    private $logger;
    protected $directoryList;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Catalog\Model\Product $product,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Model\Category $Category
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_category = $Category;
        $this->_product = $product;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;


    }

 public function create($post)
    {
            
        try{
            if($post['storeid'] !='' AND  $post['categoryid'] !='' AND $post['name'] !=''){
                $this->_storeManager->setCurrentStore($post['storeid']);
                $parentId = $this->_storeManager->getStore("default")->getRootCategoryId();

                $category = $this->_category;
                $category->setName($post['name'])
                        ->setUrlKey($post['name'])
                        ->setIsActive(1)
                        ->setDisplayMode('PRODUCTS')
                        ->setStoreId($post['storeid']);

                $parentCategory = $category->load($parentId);
                $category->setPath($parentCategory->getPath());
               
                $category->save();

                $this->_storeManager->setCurrentStore(1);

                $response['ErrHndler'] = "Data was successfully saved.";
				$response['success']  = true;
            }else{
                $response['ErrHndler'] = 'Required fields should not be null!';
			    $response['success'] = false;
            }
        }catch(\Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }
        return $response;
    }
  
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
}
?>