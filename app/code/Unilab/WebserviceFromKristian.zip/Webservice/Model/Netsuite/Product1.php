<?php
namespace Unilab\Webservice\Model\Netsuite;

class Product{
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    private $logger;
    protected $directoryList;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Catalog\Model\Product $product,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Magento\Catalog\Model\Product\Gallery\ReadHandler $galleryReadHandle
        // \Magento

    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_product = $product;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->directoryList = $directoryList;
        $this->_galleryReadHandle = $galleryReadHandle;


    }
 //Create Product Webservice

 public function create($post)
    {
        if (!is_dir('media/catalog/product/webservice/')) 
        {
            mkdir('media/catalog/product/webservice', 0777, true); 	
        }

        $currentdate = date("Y-m-d H:i:s");
            
        try{
            if($post['token'] !='' AND  $post['cmdEvent'] !='' AND $post['websiteid'] !='' AND $post['storeid'] != '' AND $post['sku'] != '' AND $post['name'] != '' AND $post['status'] != '' AND $post['visibility'] != '' 	AND  $post['unit_price'] != '' AND $post['unilab_moq'] != '' AND $post['price'] != '' AND $post['tax_class_id'] != '')
			{
                $productValSku = $this->_product->getIdBySku($post['sku']);

                if($productValSku){

                        $product = $this->_product->load($productValSku);
                        $response['success'] 	= false;
                        $response['Errhandler'] = "SKU Already Exist! ID: ".  $product->getId(). " Name: ". $product->getName();
                        $this->createlogs($post['sku'],"Magento",$post['cmdEvent'],$response['success'],json_encode($response['Errhandler']));
                        // $this->createVarlogs('createProductexist.log',$response['Errhandler']);
                        // $this->createVarlogs('createProductexist.log',$post);
                        return $response;
                }
                $oldStore = $this->_storeManager->getStore();
                $this->_storeManager->setCurrentStore($oldStore);

                $catIds 		= explode(',',$post['category']);

                $storeids 		= array();
                $storeids 		= explode(',',$post['storeid']);
                $websiteid 		= array();
                $imageslist = array();
                if($post['images'] != ""){
                    $imageslist 	= explode(',',$post['images']);
                }
                foreach ($storeids as $key => $value) 
				{
					$q 				= "SELECT website_id FROM  store where store_id = $value";
					$getwebsiteid 	= $this->_getConnection()->fetchAll($q);
					$websiteid[]	= $getwebsiteid[0]['website_id'];
                }
                $websiteIds 	= implode(",",$websiteid);
				$name			= sha1($post['name'])."_".$post['sku'];
                $imagename		= str_replace(" ","_",$name);
                
                $path = array();
                if ($post['image_base'] != "") 
				{
				$path['image_base']	= $post['image_base'];
				}
				if ($post['image_thumbnail'] != "") 
				{
				$path['image_thumbnail'] = $post['image_thumbnail'];
				}
				if ($post['image_small'] != "") 
				{
				$path['image_small'] = $post['image_small'];
                }
                $p=0;

				foreach($path as $key => $value)
				{
					$completeSaveLoc 	= $_SERVER['DOCUMENT_ROOT'].'/media/catalog/product/webservice/'.$imagename.$p. '.jpg';
					$SaveLoc 			= "/webservice/".$imagename.$p. ".jpg";
					
					file_put_contents($completeSaveLoc, file_get_contents($value));

					if ($key == 'image_small')
					{
						$imagelocsmall = $completeSaveLoc;
					}
					if ($key == 'image_thumbnail')
					{
						$imagelocthumbnail = $completeSaveLoc;
					}
					if ($key == 'image_base')
					{
						$imagelocbase = $completeSaveLoc;
					}
					$p++;
                }
                if($post['status'] == 0 ){
					$status = 2;
				}else
				{
					$status = $post['status'];
                }
                $product = $this->_product;
                $product->setWebsiteIds($websiteid) 
						->setAttributeSetId(9) //9 OTC-NOSIZE
						->setTypeId('simple')
						->setSku($post['sku'])
						->setName($post['name'])
						->setGenericName($post['generic_name'])	
						->setDescription($post['description']) 
						->setShortDescription($post['short_description'])
						->setWeight($post['weight'])
						->setStatus($status)
						->setVisibility($post['visibility'])
						->setRitemedScDiscount($post['sc_discount'])
						// ->setUnilabAntibiotic($post['antibiotic'])
						->setUnilabRx($post['unilab_rx'])
						->setUnilabType($post['unilab_type'])
						->setUnilabBenefit($post['unilab_benefit'])
						->setUnilabSegment($post['unilab_segment'])
						->setUnilabDivision($post['unilab_division'])
						->setUnilabGroup($post['unilab_group'])
						->setUnilabFormat($post['unilab_format'])
						// ->setUnilabDirections($post['unilab_direction'])
						// ->setUnilabIngredients($post['unilab_ingredients'])
						// ->setUnilabBrand($post['unilab_brand'])
						->setUnilabSize($post['unilab_size'])
						->setUnilabSort($post['sort_order'])
						->setUnilabUnitPrice($post['unit_price'])
						->setUnilabMoq($post['unilab_moq'])
						->setPrice($post['price'])
						->setTaxClassId($post['tax_class_id'])
						->setStockData(array(
							'use_config_manage_stock' => 0,
							'manage_stock'=>$post['manage_stock'],
							'min_sale_qty'=>1, 
							'is_in_stock' =>$post['is_in_stock'],
							'qty' =>$post['qty']
							))
						->setCategoryIds($catIds)
                        ->setUom($post['uom']);
                if ($post['image_base'] != "")
                {
                    $product->addImageToMediaGallery($imagelocbase, 'image', false,false);
                }
                if ($post['image_thumbnail'] != "")
                {
                    $product->addImageToMediaGallery($imagelocthumbnail,'thumbnail', false,false);
                }
                if ($post['image_small'] != "") 
                {
                    $product->addImageToMediaGallery($imagelocsmall,'small_image', false,false);
                }

                $i = $p;
            
				if($post['images'] != "")
				{
					foreach($imageslist as $key => $value)
					{
						if ($value)
						{
							$completeSaveLoc 	= $_SERVER['DOCUMENT_ROOT'].'/media/catalog/product/webservice/'.$imagename.$p. '.jpg';
							$SaveLoc 			= "/webservice/".$imagename.$i. ".jpg";//'/c/h/'.$imagename.$p.'.png';

							file_put_contents($completeSaveLoc, file_get_contents($value));
							$product->addImageToMediaGallery($completeSaveLoc, '', false,false);
						}
					}
					
					$i++;
                }
                if($product->save()){

					$product_newid    = $this->_product->getIdBySku($post['sku']);
					$productNew       = $this->_product->load($product_newid);  
					
					$prodid		      = $productNew->getId();	

					$response['ErrHndler'] = "Data was successfully saved.";
					$response['sku']  = $post['sku'];
					$response['success']  = true;


				}else{

					$response['ErrHndler'] = "An error occured while saving";
					$response['sku']  = $post['sku'];
					$response['success']  = false;
                }
               
			}else{
				$response['ErrHndler'] = 'Required fields should not be null!';
				$response['success'] = false;
			}

        }catch(Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }
        $this->createlogs($post['sku'],"Magento",$post['cmdEvent'],$response['success'],json_encode($response['ErrHndler']));

        return $response;
    }
    public function update($post){
     
        $currentdate = date("Y-m-d H:i:s");
        try{
            if($post['token'] !='' AND  $post['cmdEvent'] !='' AND $post['sku'] != '' AND $post['name'] != '' AND $post['description'] != '' AND $post['short_description'] != '' AND $post['status'] != '' AND $post['visibility'] != '' AND $post['sc_discount'] != '' AND $post['antibiotic'] != '' AND $post['unilab_rx'] != '' AND $post['unilab_type'] != '' AND $post['unilab_format'] != '' AND $post['unilab_benefit'] != '' AND  $post['unit_price'] != '' AND $post['unilab_moq'] != '' AND $post['price'] != '' AND $post['tax_class_id'] != '')
			{
                $oldStore = $this->_storeManager->getStore();
                $this->_storeManager->setCurrentStore($oldStore);
                
                $catIds 		= explode(',',$post['category']);
				
				$storeids 		= array();
				$storeids 		= explode(',',$post['storeid']);
                $websiteid 		= array();
                $imageslist = array();
				if($post['images'] != ""){
					$imageslist 	= explode(',',$post['images']);
                }
                foreach ($storeids as $key => $value) 
				{
					$q 				= "SELECT website_id FROM  `store` where store_id = $value";
					$getwebsiteid 	= $this->_getConnection()->fetchAll($q);
					$websiteid[]	= $getwebsiteid[0]['website_id'];
                }
                $websiteIds = implode(",",$websiteid);
                $productsku = $this->_product->getIdBySku($post['sku']);

                if($productsku)
				{
					$name			= sha1($post['name'])."_".$post['sku'];
					$imagename		= str_replace(" ","_",$name);
                    $path = array();
					if ($post['image_base'] != "")
					{
						$path['image_base']	= $post['image_base'];
					}	
					if ($post['image_thumbnail'] != "")
					{
						$path['image_thumbnail'] = $post['image_thumbnail'];
					}	
					if ($post['image_small'] != "") 
					{
						$path['image_small'] = $post['image_small'];
					}	
					$p=0;
					foreach($path as $key => $value)
					{
						$completeSaveLoc 	= $_SERVER['DOCUMENT_ROOT'].'/media/catalog/product/webservice/'.$imagename.$p. '.jpg';
						$SaveLoc= "/webservice/".$imagename.$p. ".jpg";//'/c/h/'.$imagename.$p.'.png';
						file_put_contents($completeSaveLoc, file_get_contents($value));
				
						if ($key == 'image_small')
						{
							$imagelocsmall = $completeSaveLoc;
						}
						if ($key == 'image_thumbnail')
						{
							$imagelocthumbnail = $completeSaveLoc;
						}
						if ($key == 'image_base')
						{
							$imagelocbase = $completeSaveLoc;
						}
						$p++;
					} 
                    $product = $this->_product;
					$product->load($productsku);
				
					/**
					 * BEGIN REMOVE EXISTING MEDIA GALLERY
					 */
                    $attributes = $this->_galleryReadHandle->execute($product);
                    
					if (isset($attributes['media_gallery'])) 
					{
						$gallery 		= $attributes['media_gallery'];
						//Get the images
						$galleryData 	= $product->getMediaGallery ();
						foreach ( $galleryData ['images'] as $image ) 
						{
							//If image exists
							if ($gallery->getBackend()->getImage ($product, $image ['file'])['file'] == $product->getImage() and $post['image_base'] !="")
							{
								$gallery->getBackend()->removeImage( $product, $image ['file'] );
							}
                            if ($gallery->getBackend()->getImage($product, $image ['file'])['file'] ==  $product->getThumbnail() and $post['image_thumbnail'] !="")
							{
								$gallery->getBackend()->removeImage ($product, $image ['file']);
							}
							if ($gallery->getBackend()->getImage($product, $image ['file'])['file'] == $product->getSmallImage() and $post['image_small'] !="")
							{
								$gallery->getBackend()->removeImage ($product, $image ['file']);
							}
							if ($gallery->getBackend()->getImage( $product, $image ['file'] )['file'] != $product->getSmallImage() and $gallery->getBackend ()->getImage( $product, $image ['file'] )['file'] != $product->getThumbnail() and $gallery->getBackend ()->getImage( $product, $image ['file'])['file'] != $product->getThumbnail() and $post['images'] !="")
							{
								$gallery->getBackend()->removeImage ($product, $image ['file']);
							}
						}
						$product->save ();
					}
										/**
					 * END REMOVE EXISTING MEDIA GALLERY
					 */
					if($post['status'] == 0 ){
						$status = 2;
					}else
					{
						$status = $post['status'];
					}	
											
					$product->setWebsiteIds($websiteid) 
                        ->setName($post['name'])
                        ->setGenericName($post['generic_name'])	
                        ->setDescription($post['description']) 
                        ->setShortDescription($post['short_description'])
                        ->setWeight($post['weight'])
                        ->setStatus($status)
                        ->setVisibility($post['visibility'])
                        ->setRitemedScDiscount($post['sc_discount'])
                        ->setUnilabAntibiotic($post['antibiotic'])	
                        ->setUnilabRx($post['unilab_rx'])
                        ->setUnilabType($post['unilab_type'])
                        ->setUnilabBenefit($post['unilab_benefit'])
                        ->setUnilabSegment($post['unilab_segment'])
                        ->setUnilabDivision($post['unilab_division'])		
                        ->setUnilabGroup($post['unilab_group'])
                        ->setUnilabFormat($post['unilab_format'])
                        // ->setUnilabDirections($post['unilab_direction'])
                        // ->setUnilabIngredients($post['unilab_ingredients'])
                        // ->setUnilabBrand($post['unilab_brand'])
                        ->setUnilabSize($post['unilab_size'])
                        ->setUnilabSort($post['sort_order'])				
                        ->setUnilabUnitPrice($post['unit_price'])
                        ->setUnilabMoq($post['unilab_moq'])
                        ->setPrice($post['price'])
                        ->setTaxClassId($post['tax_class_id'])
                        ->setStockData(array(
                                    'use_config_manage_stock' => 0,
                                    'manage_stock'=>$post['manage_stock'],
                                    'min_sale_qty'=>1, 
                                    'is_in_stock' =>$post['is_in_stock'], 
                                    'qty' =>$post['qty']
                                    ))
                        ->setCategoryIds($catIds)
                        ->setUom($post['uom']); 
                        
                        if ($post['image_base'] != "") 
                        {
                            $product->addImageToMediaGallery($imagelocbase, 'image', false,false);
                        }
                        if ($post['image_thumbnail'] != "")
                        {
                            $product->addImageToMediaGallery($imagelocthumbnail, 'thumbnail', false,false);
                        }
                        if ($post['image_small'] != "") 
                        {
                            $product->addImageToMediaGallery($imagelocsmall, 'small_image', false,false);
                        }
        
                        $i=$p;
                        foreach($imageslist as $key => $value)
                        {
                            $completeSaveLoc 	= $_SERVER['DOCUMENT_ROOT'].'/media/catalog/product/webservice/'.$imagename.$p. '.jpg';
                            $SaveLoc 			= "/webservice/".$imagename.$i. ".jpg"; 
                            file_put_contents($completeSaveLoc, file_get_contents($value));
                            $product->addImageToMediaGallery($completeSaveLoc, '', false,false);
                            $i++;
                        } 
                        $product->save();
            
                        $product_newid    = $this->_product->getIdBySku($post['sku']);
                        $productNew       = $this->_product->load($product_newid); 
                        $prodid		      = $productNew->getId();	

                        $response['ErrHndler'] 	= "Data was successfully updated.";
                        $response['sku']  	 	= $post['sku'];
                        $response['success']  	= true;
				}else{
						$response['ErrHndler']  = "Product does not exists!.";
						$response['sku'] 	  = $post['sku'];
						$response['success']  = true;
				}
            }else{
                $response['ErrHndler'] = 'Required fields should not be null! '.implode(',',$missing_fields);		
				$response['success'] = false;
            }
        }catch(Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }
        $this->createlogs($post['sku'],"Magento",$post['cmdEvent'],$response['success'],json_encode($response['ErrHndler']));

        return $response;
    }
    public function updateproductprice($post){
        $currentdate = date("Y-m-d H:i:s");
		
		try{
            if($post['token'] !='' AND  $post['cmdEvent'] !='' AND $post['sku'] != '' AND $post['unit_price'] != '' AND $post['unilab_moq'] != '' AND $post['price'] != '')
            {
                $oldStore = $this->_storeManager->getStore();
                $this->_storeManager->setCurrentStore($oldStore);

                $productsku = $this->_product->getIdBySku($post['sku']);
                if($productsku){
                    $product = $this->_product;
                    $product->load($productsku);
                    $product->setUnilabUnitPrice($post['unit_price'])
                            ->setUnilabMoq($post['unilab_moq'])
                            ->setPrice($post['price']);
                    $product->save();

                    $response['ErrHndler']  = "Data was successfully updated.";
					$response['sku'] 	  = $post['sku'];
					$response['success']  = true;
                }else{
                    $response['ErrHndler']  = "Product does not exists!.";
                    $response['sku'] 	  = $post['sku'];
                    $response['success']  = true;
                }
            }else{
				$response['ErrHndler'] = 'Required field(s) should not be null!';		
				$response['success'] = false;
			}
        }catch(Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }
        $this->createlogs($post['sku'],"Magento",$post['cmdEvent'],$response['success'],json_encode($response['ErrHndler']));

        return $response;
    }
    public function updateproductstatus($post){
        $currentdate = date("Y-m-d H:i:s");    
			
		try{
            if($_POST['token'] !='' AND  $_POST['cmdEvent'] !='' AND $_POST['sku'] != '' AND $_POST['status'] != '')
			{
                if($_POST['status'] == 0 ){
					$status = 2;
				}else
				{
					$status = $_POST['status'];
                }
                $oldStore = $this->_storeManager->getStore();
                $this->_storeManager->setCurrentStore($oldStore);
                $productsku = $this->_product->getIdBySku($post['sku']);

                if($productsku){

                    $product = $this->_product;
                    $product->load($productsku);
                    $product->setStatus($status);
                    $product->save();
                    
                    $response['ErrHndler']  = "Data was successfully updated.";
					$response['sku'] 	  = $post['sku'];
					$response['success']  = true;
                }else{
                    $response['ErrHndler']  = "Product does not exists!.";
                    $response['sku'] 	  = $post['sku'];
                    $response['success']  = true;
                }
            }else{
				$response['ErrHndler'] = 'Required field(s) should not be null!';		
				$response['success'] = false;
			}
        }catch(Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }
        $this->createlogs($post['sku'],"Magento",$post['cmdEvent'],$response['success'],json_encode($response['ErrHndler']));
        return $response;
    }
    protected function _getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->resourceConnection->getConnection('core_write');
        }
        return $this->connection;
    }
    public function createlogs($id,$from,$cmdEvent,$status,$message){
		$connection = $this->_getConnection();
		$currentdate = date("Y-m-d H:i:s");  
		$data = array(
					'transaction_id' 	=>  $id,
					'cmdEvent'			=>	$cmdEvent,
					'data_from'			=>	$from,
					'status' 			=>  $status,
					'logs'				=>  $message,
					'date'				=>	$currentdate,
					'type'				=> 	'receive'
		);
		$connection->insert('unilab_logs_netsuite', $data);

	}
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
}
?>