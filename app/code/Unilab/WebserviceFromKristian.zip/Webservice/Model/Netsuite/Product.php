<?php

namespace Unilab\Webservice\Model\Netsuite;
use Magento\Framework\App\Filesystem\DirectoryList;
class Product {
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    private $logger;
    protected $directoryList;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Catalog\Model\Product $product,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Magento\Catalog\Model\Product\Gallery\ReadHandler $galleryReadHandle,
        \Magento\Catalog\Model\Product\Gallery\Processor $imageProcessor,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Indexer\Model\IndexerFactory $indexerFactory
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_product = $product;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->directoryList = $directoryList;
        $this->_galleryReadHandle = $galleryReadHandle;
        $this->_filesystem = $filesystem;
        $this->imageProcessor = $imageProcessor;
        $this->indexerFactory = $indexerFactory;
    }
    
    public function create($post)
    {
        $currentdate = date("Y-m-d H:i:s");

        $mediapath = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
        $mediapath = str_replace('/','\\',$mediapath);
        if (!is_dir('pub/media/catalog/product/webservice/')) 
        {
            mkdir('pub/media/catalog/product/webservice', 0777, true); 	
        }
      
        try {
            
            if(
                $post['name'] != "" AND
                $post['product_type'] != "" AND
                $post['generic_name'] != "" AND
                $post['description'] != "" AND
                $post['short_description'] != "" AND
                $post['sku'] != "" AND 
                $post['weight'] != "" AND
                $post['status'] != "" AND
                $post['visibility'] != "" AND
                $post['unilab_rx'] != "" AND
                //$post['division'] != "" AND
                $post['unilab_format'] != "" AND
                $post['unilab_benefit'] != "" AND
                $post['unilab_segment'] != "" AND
                // $post['size'] != "" AND
                $post['base_image'] != "" AND
                $post['small_image'] != "" AND
                $post['thumbnail_image'] != "" AND
                $post['website_id'] != "" AND
                $post['webstore_id'] != "" AND
                // $post['category1'] != "" AND -> $post['category_ids'];
                // $post['category2'] != "" AND
                // $post['category3'] != "" AND
                // $post['category4'] != "" AND
                // $post['category5'] != "" AND
                $post['unit_of_measure'] != "" AND
                $post['unit_price'] != "" AND
                $post['moq'] != "" AND
                $post['price'] != "" AND
                $post['tax_class'] != ""
            ) {
                if(
                    is_string($post['category_ids']) && 
                    is_string($post['unilab_benefit']) &&
                    is_string($post['unilab_format']) &&
                    is_integer($post['unilab_type'])
                ){
                    
                $productValSku = $this->_product->getIdBySku($post['sku']);

                if($productValSku){

                    $product = $this->_product->load($productValSku);
                    $response['code'] 	= false;
                    $response['description'] = "SKU Already Exist! ID: ".  $product->getId(). " Name: ". $product->getName();
                    $this->createlogs($post['sku'],"Magento",$post['cmdEvent'],$response['code'],json_encode($response['description']));
                    // $this->createVarlogs('createProductexist.log',$response['description']);
                    // $this->createVarlogs('createProductexist.log',$post);
                    return $response;
                }
                $oldStore = $this->_storeManager->getStore();
                $this->_storeManager->setCurrentStore($oldStore);

                $catIds 		= explode(',',$post['category_ids']);
                $storeids 		= array();
                $storeids 		= explode(',',$post['webstore_id']);
                $websiteid 		= array();
                $imageslist = array();
                if($post['images'] != ""){
                    $imageslist 	= explode(',',$post['images']);
                }
                foreach ($storeids as $key => $value) 
				{
					$q 				= "SELECT website_id FROM  store where store_id = $value";
					$getwebsiteid 	= $this->_getConnection()->fetchAll($q);
					$websiteid[]	= $getwebsiteid[0]['website_id'];
                }
                $websiteIds 	= implode(",",$websiteid);
				$name			= sha1($post['name'])."_".$post['sku'];
                $imagename		= str_replace(" ","_",$name);
                
                $path = array();
                if ($post['base_image'] != "") 
				{
				$path['base_image']	= $post['base_image'];
				}
				if ($post['thumbnail_image'] != "") 
				{
				$path['thumbnail_image'] = $post['thumbnail_image'];
				}
				if ($post['small_image'] != "") 
				{
				$path['small_image'] = $post['small_image'];
                }
                $p=0;

				foreach($path as $key => $value)
				{
                    $completeSaveLoc 	= $mediapath.'catalog\product\webservice\\'.$imagename.$p. '.jpg';
					$SaveLoc 			= "/webservice/".$imagename.$p. ".jpg";
					
					file_put_contents($completeSaveLoc, file_get_contents($value));

					if ($key == 'small_image')
					{
						$imagelocsmall = $completeSaveLoc;
					}
					if ($key == 'thumbnail_image')
					{
						$imagelocthumbnail = $completeSaveLoc;
					}
					if ($key == 'base_image')
					{
						$imagelocbase = $completeSaveLoc;
					}
					$p++;
                }
                if($post['status'] == 0 ){
					$status = 2;
				}else
				{
					$status = $post['status'];
                }
                $product = $this->_product;
                $product->setWebsiteIds($websiteid) 
                        ->setNetsuiteId($post['netsuite_id'])
						->setAttributeSetId(39) //9 OTC-NOSIZE
						->setTypeId('simple')
						->setSku($post['sku'])
						->setName($post['name'])
						->setGenericName($post['generic_name'])	
						->setDescription($post['description']) 
						->setShortDescription($post['short_description'])
						->setWeight($post['weight'])
						->setStatus($status)
						->setVisibility($post['visibility'])
						->setRitemedScDiscount($post['sc_discount'])
						// ->setUnilabAntibiotic($post['antibiotic'])
						->setUnilabRx($post['unilab_rx'])
						->setUnilabType($post['unilab_type'])
						->setUnilabBenefit($post['unilab_benefit'])
						->setUnilabSegment($post['unilab_segment'])
						// ->setUnilabDivision($post['unilab_division'])
						// ->setUnilabGroup($post['unilab_group'])
						->setUnilabFormat($post['unilab_format'])
						// ->setUnilabDirections($post['unilab_direction'])
						// ->setUnilabIngredients($post['unilab_ingredients'])
						// ->setUnilabBrand($post['unilab_brand'])
						->setUnilabSize($post['unilab_size'])
						->setUnilabSort($post['sort_order'])
						->setUnilabUnitPrice($post['unit_price'])
						->setUnilabMoq($post['moq'])
						->setPrice($post['price'])
						->setTaxClassId($post['tax_class'])
						->setStockData(array(
							'use_config_manage_stock' => 0,
							'manage_stock'=>$post['manage_stock'],
							'min_sale_qty'=>1, 
							'is_in_stock' =>$post['is_in_stock'],
							'qty' =>$post['qty']
							))
						->setCategoryIds($catIds)
                        ->setUom($post['uom']);
                if ($post['base_image'] != "")
                {
                    $product->addImageToMediaGallery($imagelocbase, 'image', false,false);
                }
                if ($post['thumbnail_image'] != "")
                {
                    $product->addImageToMediaGallery($imagelocthumbnail,'thumbnail', false,false);
                }
                if ($post['small_image'] != "") 
                {
                    $product->addImageToMediaGallery($imagelocsmall,'small_image', false,false);
                }

                $i = $p;
            
				if($post['images'] != "")
				{
					foreach($imageslist as $key => $value)
					{
						if ($value)
						{
                            $completeSaveLoc 	= $mediapath.'catalog\product\webservice\\'.$imagename.$p. '.jpg';
							$SaveLoc 			= "/webservice/".$imagename.$i. ".jpg";//'/c/h/'.$imagename.$p.'.png';

							file_put_contents($completeSaveLoc, file_get_contents($value));
							$product->addImageToMediaGallery($completeSaveLoc, '', false,false);
						}
					}
					
					$i++;
                }
                if($product->save()){

                        $product_newid    = $this->_product->getIdBySku($post['sku']);
                        $productNew       = $this->_product->load($product_newid);  
                        
                        $prodid		      = $productNew->getId();	

                        $response['code'] = "1";
                        $response['sku']  = $post['sku'];
                        $response['description']  = "Success";
                        $response['id'] = $product->getId();


                    }else{

                        $response['description'] = "Timeout";
                        $response['sku']  = $post['sku'];
                        $response['code']  = "0,F";
                    }
                }
                else {
                    $response['code'] = "0,L";
                    $response['description'] = "Invalid item attributes";
                }

            } else {
                $response['code'] =  "0,E";
                $response['description'] = "Required fields should not be null";

            }
            
        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->createlogs($post['sku'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']));
        $this->indexerFunctionProg();
        return $response;
    }

    public function update($post)
    {
        $currentdate = date("Y-m-d H:i:s");
        $mediapath = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
        $mediapath = str_replace('/','\\',$mediapath);
        
        try {
            
            $product_id = $this->_product->getIdBySku($post['sku']);

            if($product_id) {

                if(
                    $post['name'] != "" AND
                    $post['product_type'] != "" AND
                    $post['generic_name'] != "" AND
                    $post['description'] != "" AND
                    $post['short_description'] != "" AND
                    $post['sku'] != "" AND 
                    $post['weight'] != "" AND
                    $post['status'] != "" AND
                    $post['visibility'] != "" AND
                    $post['unilab_rx'] != "" AND
                    //$post['division'] != "" AND
                    $post['unilab_format'] != "" AND
                    $post['unilab_benefit'] != "" AND
                    $post['unilab_segment'] != "" AND
                    // $post['size'] != "" AND
                    $post['base_image'] != "" AND
                    $post['small_image'] != "" AND
                    $post['thumbnail_image'] != "" AND
                    $post['website_id'] != "" AND
                    $post['webstore_id'] != "" AND
                    // $post['category1'] != "" AND -> $post['category_ids'];
                    // $post['category2'] != "" AND
                    // $post['category3'] != "" AND
                    // $post['category4'] != "" AND
                    // $post['category5'] != "" AND
                    $post['unit_of_measure'] != "" AND
                    $post['unit_price'] != "" AND
                    $post['moq'] != "" AND
                    $post['price'] != "" AND
                    $post['tax_class'] != ""
                ) {
    
                    if(
                        is_string($post['category_ids']) && 
                        is_string($post['unilab_benefit']) &&
                        is_string($post['unilab_format']) &&
                        is_integer($post['unilab_type'])
                    ){
                        //Update logic here

                        $oldStore = $this->_storeManager->getStore();
                        $this->_storeManager->setCurrentStore($oldStore);
                        
                        $catIds 		= explode(',',$post['category_ids']);
				
                        $storeids 		= array();
                        $storeids 		= explode(',',$post['webstore_id']);
                        $websiteid 		= array();
                        $imageslist = array();
                        if($post['images'] != ""){
                            $imageslist 	= explode(',',$post['images']);
                        }
                        foreach ($storeids as $key => $value) 
                        {
                            $q 				= "SELECT website_id FROM  `store` where store_id = $value";
                            $getwebsiteid 	= $this->_getConnection()->fetchAll($q);
                            $websiteid[]	= $getwebsiteid[0]['website_id'];
                        }
                        $websiteIds = implode(",",$websiteid);
                        $productsku = $this->_product->getIdBySku($post['sku']);

                        $name			= sha1($post['name'])."_".$post['sku'];
                        $imagename		= str_replace(" ","_",$name);
                        $path = array();
                        if ($post['base_image'] != "")
                        {
                            $path['base_image']	= $post['base_image'];
                        }	
                        if ($post['thumbnail_image'] != "")
                        {
                            $path['thumbnail_image'] = $post['thumbnail_image'];
                        }	
                        if ($post['small_image'] != "") 
                        {
                            $path['small_image'] = $post['small_image'];
                        }	
                        $p=0;
                        foreach($path as $key => $value)
                        {
                            $completeSaveLoc 	= $mediapath.'catalog\product\webservice\\'.$imagename.$p. '.jpg';
                            $SaveLoc= "/webservice/".$imagename.$p. ".jpg";//'/c/h/'.$imagename.$p.'.png';
                            file_put_contents($completeSaveLoc, file_get_contents($value));
                    
                            if ($key == 'small_image')
                            {
                                $imagelocsmall = $completeSaveLoc;
                            }
                            if ($key == 'thumbnail_image')
                            {
                                $imagelocthumbnail = $completeSaveLoc;
                            }
                            if ($key == 'base_image')
                            {
                                $imagelocbase = $completeSaveLoc;
                            }
                            $p++;
                        } 
                        $product = $this->_product;
                        $product->load($productsku);
                    
                        /**
                         * BEGIN REMOVE EXISTING MEDIA GALLERY
                         */
                        
                        $attributes = $this->_galleryReadHandle->execute($product);
                        
                        if (isset($attributes['media_gallery'])) 
                        {
                            $gallery = $product->getMediaGalleryImages();
                            foreach($gallery as $image){
                                if($this->imageProcessor->getImage($product,$image->getFile())== $product->getImage() and $post['base_image'] !=""){
                                   $this->imageProcessor->removeImage($product,$image->getFile());
                                }
                                if($this->imageProcessor->getImage($product,$image->getFile())== $product->getThumbnail() and $post['thumbnail_image'] !=""){
                                   $this->imageProcessor->removeImage($product,$image->getFile());
                                }
                                if($this->imageProcessor->getImage($product,$image->getFile())== $product->getSmallImage() and $post['small_image'] !=""){
                                   $this->imageProcessor->removeImage($product,$image->getFile());
                                }
                                if ($this->imageProcessor->getImage($product,$image->getFile()) != $product->getSmallImage() and $this->imageProcessor->getImage($product,$image->getFile()) != $product->getThumbnail() and $this->imageProcessor->getImage($product,$image->getFile()) != $product->getThumbnail() and $post['images'] !="")
                                {
                                   $this->imageProcessor->removeImage($product,$image->getFile());
                                }
                            }

                            $product->save ();
                        }
                        /* END REMOVE EXISTING MEDIA GALLERY
                        */
                        if($post['status'] == 0 ){
                            $status = 2;
                        }else
                        {
                            $status = $post['status'];
                        }	
                                                
                        $product->setWebsiteIds($websiteid) 
                            ->setNetsuiteId($post['netsuite_id'])
                            ->setAttributeSetId(39) //9 OTC-NOSIZE
                            ->setTypeId('simple')
                            ->setSku($post['sku'])
                            ->setName($post['name'])
                            ->setGenericName($post['generic_name'])	
                            ->setDescription($post['description']) 
                            ->setShortDescription($post['short_description'])
                            ->setWeight($post['weight'])
                            ->setStatus($status)
                            ->setVisibility($post['visibility'])
                            ->setRitemedScDiscount($post['sc_discount'])
                            // ->setUnilabAntibiotic($post['antibiotic'])
                            ->setUnilabRx($post['unilab_rx'])
                            ->setUnilabType($post['unilab_type'])
                            ->setUnilabBenefit($post['unilab_benefit'])
                            ->setUnilabSegment($post['unilab_segment'])
                            // ->setUnilabDivision($post['unilab_division'])
                            // ->setUnilabGroup($post['unilab_group'])
                            ->setUnilabFormat($post['unilab_format'])
                            // ->setUnilabDirections($post['unilab_direction'])
                            // ->setUnilabIngredients($post['unilab_ingredients'])
                            // ->setUnilabBrand($post['unilab_brand'])
                            ->setUnilabSize($post['unilab_size'])
                            ->setUnilabSort($post['sort_order'])
                            ->setUnilabUnitPrice($post['unit_price'])
                            ->setUnilabMoq($post['moq'])
                            ->setPrice($post['price'])
                            ->setTaxClassId($post['tax_class'])
                            ->setStockData(array(
                                'use_config_manage_stock' => 0,
                                'manage_stock'=>$post['manage_stock'],
                                'min_sale_qty'=>1, 
                                'is_in_stock' =>$post['is_in_stock'],
                                'qty' =>$post['qty']
                                ))
                            ->setCategoryIds($catIds)
                            ->setUom($post['uom']);
                            
                        if ($post['base_image'] != "") 
                        {
                            $product->addImageToMediaGallery($imagelocbase, 'image', false,false);
                        }
                        if ($post['thumbnail_image'] != "")
                        {
                            $product->addImageToMediaGallery($imagelocthumbnail, 'thumbnail', false,false);
                        }
                        if ($post['small_image'] != "") 
                        {
                            $product->addImageToMediaGallery($imagelocsmall, 'small_image', false,false);
                        }
        
                        $i=$p;
                        foreach($imageslist as $key => $value)
                        {
                            $completeSaveLoc 	= $mediapath.'catalog\product\webservice\\'.$imagename.$p. '.jpg';
                            $SaveLoc 			= "/webservice/".$imagename.$i. ".jpg"; 
                            file_put_contents($completeSaveLoc, file_get_contents($value));
                            $product->addImageToMediaGallery($completeSaveLoc, '', false,false);
                            $i++;
                        }
                        
                        $product->setNetsuiteId($post['netsuite_id']);
                        $product->getResource()->saveAttribute($product, 'netsuite_id');
                        
                        if($product->save()) {

                            $product_newid    = $this->_product->getIdBySku($post['sku']);
                            $productNew       = $this->_product->load($product_newid); 
                            $prodid		      = $productNew->getId();	
        
                            $response['code'] 	= "1";
                            $response['sku']  	 	= $post['sku'];
                            $response['description']  	= "Success";
                            $response['id'] = $product->getId();

                        } else {

                            $response['description'] = "Timeout";
                            $response['sku']  = $post['sku'];
                            $response['code']  = "0,F";

                        }
            
                    }
                    else {
                        $response['code'] = "0,L";
                        $response['description'] = "Invalid item attributes";
                    }
    
                } else {
                    $response['code'] =  "0,E";
                    $response['description'] = "Required fields should not be null";
    
                }
                

            } else {
                $response['code'] = "0,B";
                $response['description'] = "Item not found";
            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->createlogs($post['sku'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']));

        return $response;
    }

    protected function _getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->resourceConnection->getConnection('core_write');
        }
        return $this->connection;
    }

    public function createlogs($id,$from,$cmdEvent,$status,$message){
		$connection = $this->_getConnection();
		$currentdate = date("Y-m-d H:i:s");  
		$data = array(
					'transaction_id' 	=>  $id,
					'cmdEvent'			=>	$cmdEvent,
					'data_from'			=>	$from,
					'status' 			=>  $status,
					'logs'				=>  $message,
					'date'				=>	$currentdate,
					'type'				=> 	'receive'
		);
		$connection->insert('unilab_logs_netsuite', $data);

	}
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }

    public function testProduct($post)
    {
        $response = [];
        
        if(
            is_string($post['category_ids']) && 
            is_string($post['unilab_benefit']) &&
            is_string($post['format']) &&
            is_integer($post['unilab_type'])
        ) {
            $product_id = $this->_product->getIdBySku($post['sku']);
            $product = $this->_product->load($product_id);

            // $product->setNetsuiteId(123);
            // $product->getResource()->saveAttribute($product, 'netsuite_id');

            // $product->setUnilabBenefit($post['unilab_benefit']);
            // $product->setUnilabFormat($post['format']);

            if($product->save()){
                $response['product'] = $product->getNetsuiteId();
                $response['benefits'] = $product->getUnilabBenefit();
                $response['format'] = $product->getUnilabFormat();
                $response['images']['base'] = $product->getImage();
                $response['images']['thumbnail'] = $product->getThumbnail();
                $response['images']['small_image'] = $product->getSmallImage();

            } else {
                $response['code'] = "error";
            }
        } else {

            $response['code'] = "0,L";
            $response['description'] = "Invalid item attributes";

        }
        $this->indexerFunctionProg();
        return $response;
    }
    public function indexerFunctionProg(){
        $indexerIds = array(
            'catalog_category_product',
            'catalog_product_category',
            'catalog_product_price',
            'catalog_product_attribute',
            'cataloginventory_stock',
            'catalogrule_product',
            'catalogsearch_fulltext',
        );
        foreach ($indexerIds as $indexerId) {
            $indexer = $this->indexerFactory->create();
            $indexer->load($indexerId);
            $indexer->reindexAll();
        }
        return true;
    }
}