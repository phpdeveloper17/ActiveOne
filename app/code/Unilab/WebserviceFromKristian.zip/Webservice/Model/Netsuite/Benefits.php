<?php

namespace Unilab\Webservice\Model\Netsuite;

class Benefits {

    public function __construct(
        \Unilab\Benefits\Model\EmployeeBenefit $benefit,
        \Unilab\Benefits\Model\EmployeeBenefitFactory $benefitFactory,
        \Unilab\Webservice\Helper\Log $logHelper
    ) {
        $this->_benefit = $benefit;
        $this->_benefitFactory = $benefitFactory;
        $this->_logHelper = $logHelper;
    }

    public function create($post)
    {  
        $response = [];
        $new_record_id = "";

        try {
            
            if(
                $post['internalid'] != "" AND
                $post['employee_id'] != "" AND
                $post['purchase_cap_id'] != "" AND
                $post['purchase_cap_limit'] != "" AND
                $post['extension_amount'] != "" AND
                $post['consumed'] != "" AND
                $post['available'] != "" AND
                $post['refresh_period'] != "" AND
                $post['start_date'] != "" AND
                $post['refresh_date'] != "" AND
                $post['website_id'] != "" AND 
                $post['webstore_id'] != ""
            ) {

                $benefit = $this->_benefit->getCollection()
                                ->addFieldToFilter('netsuite_id',$post['internalid'])
                                ->addFieldToFilter('emp_id',$post['employee_id'])
                                ->addFieldToFilter('purchase_cap_id',$post['purchase_cap_id'])->getFirstItem();
                
                $start_date = date("Y-m-d", strtotime($post['start_date']));
                $refresh_date = date("Y-m-d", strtotime($post['refresh_date']));

                if(!$benefit->getId()) {

                    $model = $this->_benefitFactory->create();
                    $model->setNetsuiteId($post['internalid']);
                    $model->setEmpId($post['employee_id']);
                    $model->setPurchaseCapId($post['purchase_cap_id']);
                    $model->setPurchaseCapLimit($post['purchase_cap_limit']);
                    $model->setExtension($post['extension_amount']);
                    $model->setConsumed($post['consumed']);
                    $model->setAvailable($post['available']);
                    $model->setRefreshPeriod($post['refresh_period']);
                    $model->setStartDate($start_date);
                    $model->setRefreshDate($refresh_date);
                    $model->setWebsiteId($post['website_id']);
                    $model->setStoreId($post['webstore_id']);

                    if($model->save()) {
                        $new_record_id = $model->getId();
                        $response['code'] = 0;
                        $response['description'] = "Success";
                    } else {
                        $response['code'] = "0,F";
                        $response['description'] = "Timeout";
                    }

                } else {

                    $response['code'] = "0,N";
                    $response['description'] = "Record already exists";

                }
                
            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required field(s) should not be null";
            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->_logHelper->createlogs($new_record_id,"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    public function update($post)
    {
        $response = [];
        
        try {

            if(
                $post['internalid'] != "" AND
                $post['employee_id'] != "" AND
                $post['purchase_cap_id'] != "" AND
                $post['purchase_cap_limit'] != "" AND
                $post['extension_amount'] != "" AND
                $post['consumed'] != "" AND
                $post['available'] != "" AND
                $post['refresh_period'] != "" AND
                $post['start_date'] != "" AND
                $post['refresh_date'] != "" AND
                $post['website_id'] != "" AND 
                $post['webstore_id'] != ""
            ) {

                $model = $this->_benefit->getCollection()
                                ->addFieldToFilter('netsuite_id',$post['internalid'])
                                ->addFieldToFilter('emp_id',$post['employee_id'])
                                ->addFieldToFilter('purchase_cap_id',$post['purchase_cap_id'])->getFirstItem();

                $start_date = date("Y-m-d", strtotime($post['start_date']));
                $refresh_date = date("Y-m-d", strtotime($post['refresh_date']));

                if($model->getId()) {

                    $model->setNetsuiteId($post['internalid']);
                    $model->setEmployeeId($post['employee_id']);
                    $model->setPurchaseCapId($post['purchase_cap_id']);
                    $model->setPurchaseCapLimit($post['purchase_cap_limit']);
                    $model->setExtension($post['extension_amount']);
                    $model->setConsumed($post['consumed']);
                    $model->setAvailable($post['available']);
                    $model->setRefreshPeriod($post['refresh_period']);
                    $model->setStartDate($start_date);
                    $model->setRefreshDate($refresh_date);
                    $model->setWebsiteId($post['website_id']);
                    $model->setStoreId($post['webstore_id']);

                    if($model->save()) {
                        $response['code'] = 0;
                        $response['description'] = "Success";
                    } else {
                        $response['code'] = "0,F";
                        $response['description'] = "Timeout";
                    }

                } else {

                    $response['code'] = "0,O";
                    $response['description'] = "Employee benefit not found";

                }
                
            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required field(s) should not be null";
            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->_logHelper->createlogs($post['internalid'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    public function testBenefits($post) 
    {
        $response = [];
        $start_date = date("Y-m-d", strtotime($post['start_date']));
        $refresh_date = date("Y-m-d", strtotime($post['refresh_date']));
        
        //create benefit
        //$benefit = $this->_benefitFactory->create();
        
        //edit
        $benefit = $this->_benefit->load($post['internalid'], 'netsuite_id');

        // $benefit->setEmpId($post['employee_id']);
        // $benefit->setGroupId($post['group_id']);
        // $benefit->setEntityId($post['entity_id']);
        // $benefit->setPurchaseCapId($post['purchase_cap_id']);
        // $benefit->setPurchaseCapLimit($post['purchase_cap_limit']);
        // $benefit->setExtension($post['extension_amount']);
        // $benefit->setConsumed($post['consumed']);
        // $benefit->setAvailable($post['available']);
        // $benefit->setRefreshPeriod($post['refresh_period']);
        $benefit->setStartDate($start_date);
        $benefit->setRefreshDate($refresh_date);
        // $benefit->setNetsuiteId($post['internalid']);
        // $benefit->setWebsiteId($post['website_id']);
        // $benefit->setStoreId($post['store_id']);

        if($benefit->save()) {
            
            $response['code']           = 1;
            $response['description']    = "Success";
            $response['internalid']     = $benefit->getId();
        
        } else {

            $response['code']           = 0;
            $response['description']    = "Timeout";

        }

        return $response;
    }
}