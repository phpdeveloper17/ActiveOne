<?php

/**
 * Copyright 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Unilab\Webservice\Model\Netsuite;

// use Unilab\Webservice\Api\AonewebserviceInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Sales\Model\Order;
/**
 * Defines the implementaiton class of the calculator service contract.
 */
class Orderstatus
{
    protected $_resource;
    public function __construct(
            \Magento\Framework\App\ResourceConnection $resource,
            \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
			RequestInterface $request,
            \Magento\Framework\Json\Helper\Data $jsonHelper,
            \Magento\Framework\ObjectManagerInterface $_objectManager,
			\Unilab\Webservice\Model\Validate\Status $status,
			\Magento\Framework\App\RequestInterface $httpRequest,
			\Magento\Sales\Model\Service\InvoiceService $invoiceService,
			\Magento\Framework\DB\Transaction $transactionFactory,
			\Magento\Sales\Model\Order\Email\Sender\InvoiceSender $invoiceSender
        ) {
            $this->_resource 		= $resource;
            $this->_orderRepository = $orderRepository;
			$this->request 			= $request;
            $this->jsonHelper		= $jsonHelper;
            $this->_objectManager   = $_objectManager;
			$this->status           = $status;
			$this->request 			= $httpRequest;
			$this->_invoiceService 	= $invoiceService;
			$this->_transactionFactory = $transactionFactory;
			$this->_invoiceSender	= $invoiceSender;
        }
	
	
    public function execute(){

	}
	
	protected function getHostname(){
		$RequestURL = $this->request->getServer('HTTP_REFERER');
		if(empty($RequestURL)){
			$this->_hostname	= $this->request->getServer('HTTP_HOST');					
		}else{
			$RequestBaseurl 	= parse_url($RequestURL);
			$this->_hostname	= $RequestBaseurl['host'];					
		}
        return $this->_hostname;
    }	
	
	public function updateToProcessing($post){
        
        $increment_id = $post['orderno'];

		$order              = $this->_objectManager->get('Magento\Sales\Model\Order')->loadByIncrementId($increment_id);

		// return [
		// 	'status' => $order->getStatus(),
		// 	'order' => $order->getData()
		// ];
		$orderstatus 	= $order->getStatus();
		
        $this->_order		= $order;
        $responseData       = array();
        try{
			
			if(!$this->_order->getData()){
				throw new \Exception(__("Order Number not exists!"));
			}
			// ******** <-- Check if Order Status Exist or valid -->	
			$orderstatus 	= $order->getStatus();
			if ($orderstatus ==	"canceled" || $orderstatus =="closed"){
				$responseData['ErrHndler'] = 'Order was '.$orderstatus . '. Cannot process';		
				$responseData['success'] = false;
			}elseif ($orderstatus =="complete"){
				$responseData['ErrHndler'] = 'Order already complete';
				$responseData['success'] = false;
			}elseif ($orderstatus =="processing"){
				$responseData['ErrHndler'] = 'Order already processing';
				$responseData['success'] = false;
			}else{
				$order->setState(Order::STATE_PROCESSING, true)
				->save();
				
				$invoice = $this->_invoiceService->prepareInvoice($order);
				
				if (!$invoice->getTotalQty()) {
				    throw new \Exception(__('Cannot create an invoice without products.'));
				}
				$amount = $invoice->getGrandTotal();
				$invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
				$invoice->register();


				$this->_transactionFactory->addObject($invoice);
				$this->_transactionFactory->addObject($invoice->getOrder());
				$this->_transactionFactory->save();

				$invoice->getOrder()->setIsInProcess(true);
				$history = $invoice->getOrder()->addStatusHistoryComment( 'Captured amount of ₱'.$amount. ' online.', true );
				$history->setIsCustomerNotified(true);
				$this->_invoiceSender->send($invoice);
				$order->save();	

				$responseData['ErrHndler'] = "Data was successfully updated.";
				$responseData['orderno']  = $increment_id;
				$responseData['success']  = true;
			}
		}catch(Exception $e){
			$responseData['DocNum'] 		= $increment_id;
			$responseData['ErrHndler'] 		= $e->getMessage();
			$responseData['success'] 		= false;
		}
		$this->createlogs( $increment_id,"Magento",$post['cmdEvent'],$responseData['success'],json_encode($responseData['ErrHndler']));
		return $responseData;
	}
	public function updateToComplete($post){
		$increment_id = $post['orderno'];

		$order              = $this->_objectManager->get('Magento\Sales\Model\Order')->loadByIncrementId($increment_id);
		$orderstatus 	= $order->getStatus();
		
        $this->_order		= $order;
        $responseData       = array();
        try{
			
			if(!$this->_order->getData()){
				throw new \Exception(__("Order Number not exists!"));
			}
			// ******** <-- Check if Order Status Exist or valid -->	
			$orderstatus 	= $order->getStatus();
			if ($orderstatus ==	"canceled" || $orderstatus =="closed"){
				$responseData['ErrHndler'] = 'Order was '.$orderstatus . '. Cannot process';		
				$responseData['success'] = false;
			}elseif ($orderstatus ==	"processing"){
				$connection = $this->_resource->getConnection('core_write');
				$query= "UPDATE  sales_order_grid SET  status = 'complete' WHERE increment_id = '$increment_id'";
				$connection->query($query);
		
				$order->setData('state', "complete");
				$order->setStatus("complete");       
				$history = $order->addStatusHistoryComment('Order was set to Complete by our automation tool.', false);
				$history->setIsCustomerNotified(false);
				$order->save();

				$responseData['ErrHndler'] = "Order was successfully updated.";
				$responseData['orderno']  = $increment_id;
				$responseData['success']  = true;
			}elseif($orderstatus ==	"complete"){
				$responseData['ErrHndler'] = 'Order already completed';
				$responseData['success'] = false;
			}else{
				$responseData['ErrHndler'] = 'Order processing is required';
				$responseData['success'] = false;
			}
		}catch(Exception $e){
			$responseData['DocNum'] 		= $increment_id;
			$responseData['ErrHndler'] 		= $e->getMessage();
			$responseData['success'] 		= false;
		}
		$this->createlogs( $increment_id,"Magento",$post['cmdEvent'],$responseData['success'],json_encode($responseData['ErrHndler']));
		return $responseData;
	}
	public function createlogs($id,$from,$cmdEvent,$status,$message){
		$connection = $this->_resource->getConnection('core_write');
		$currentdate = date("Y-m-d H:i:s");  
		$data = array(
					'transaction_id' 	=>  $id,
					'cmdEvent'			=>	$cmdEvent,
					'data_from'			=>	$from,
					'status' 			=>  $status,
					'logs'				=>  $message,
					'date'				=>	$currentdate,
					'type'				=> 	'receive'
		);
		$connection->insert('unilab_logs_netsuite', $data);

	}
}