<?php

namespace Unilab\Webservice\Model\Netsuite;

// use Unilab\Webservice\Api\AonewebserviceInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Sales\Model\Order;

class OrderStatus {
    
    protected $_resource;
    
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
		RequestInterface $request,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
		\Unilab\Webservice\Model\Validate\Status $status,
		\Magento\Framework\App\RequestInterface $httpRequest,
		\Magento\Sales\Model\Service\InvoiceService $invoiceService,
		\Magento\Framework\DB\Transaction $transactionFactory,
        \Magento\Sales\Model\Order\Email\Sender\InvoiceSender $invoiceSender,
        Order $orderModel
    ) {
        $this->_resource 		   = $resource;
        $this->_orderRepository    = $orderRepository;
		$this->request 			   = $request;
        $this->jsonHelper		   = $jsonHelper;
        $this->_objectManager      = $_objectManager;
		$this->status              = $status;
		$this->request 			   = $httpRequest;
		$this->_invoiceService 	   = $invoiceService;
		$this->_transactionFactory = $transactionFactory;
        $this->_invoiceSender	   = $invoiceSender;
        $this->_orderModel         = $orderModel;
    }

    protected function getHostname(){
		$RequestURL = $this->request->getServer('HTTP_REFERER');
		if(empty($RequestURL)){
			$this->_hostname	= $this->request->getServer('HTTP_HOST');					
		}else{
			$RequestBaseurl 	= parse_url($RequestURL);
			$this->_hostname	= $RequestBaseurl['host'];					
		}
        return $this->_hostname;
    }	

    public function updateToCancel($post) 
    {
        $increment_id = $post['orderno'];
        $cancel_state = $this->_orderModel::STATE_PROCESSING;
        $response = [];

        

        $order = $this->_orderModel->load($increment_id, 'increment_id');
        //$order              = $this->_objectManager->get('Magento\Sales\Model\Order')->loadByIncrementId($increment_id);
        

        
        if($order->getIncrementId())
        {   
            $order_status = $order->getStatus();

            if($order_status == "canceled") {
                $response['code'] = "0,K";
                $response['description'] = "Status already canceled";
            }
            elseif($order_status == "closed") {
                $response['code'] = "0";
                $response['description'] = "Order was ".$order_status;
            }
            else {

                $connection = $this->_resource->getConnection('core_write');
				$query= "UPDATE  sales_order_grid SET  status = 'canceled' WHERE increment_id = '$increment_id'";
				$connection->query($query);

                $order->setState($this->_orderModel::STATE_CANCELED)
                    ->setStatus($this->_orderModel::STATE_CANCELED);

                if($order->save()) {
                    $response['code'] = "1";
                    $response['description'] = "Success";
                    $response['doc_no'] = $order->getIncrementId();
                }
                else {
                    $response['code'] = "0,F";
                    $response['description'] = "Timeout";
                }
            }
        } else {
            $response['code'] = "0,H";
            $response['description'] = "Order # not found";
        }
        
        $this->createlogs( $increment_id,"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']));

        return $response;
        // return ['order_number' => $order->getIncrementId(), "status" => $order->getStatus()];
    }

    public function updateToProcessing($post) 
    {
        $increment_id = $post['orderno'];

		$order = $this->_orderModel->load($increment_id, 'increment_id');//$this->_objectManager->get('Magento\Sales\Model\Order')->loadByIncrementId($increment_id);
		
		// return [
		// 	'status' => $order->getStatus(),
		// 	'order' => $order->getData()
		// ];
		$orderstatus 	= $order->getStatus();
		
		$this->_order		= $order;
		if(!$this->_order->getData()){
			// throw new \Exception(__("Order Number not exists!"));
			$response['code'] = "0,H";
			$response['description'] = "Order # not found";
			return $response;
		}
        $response       = array();
        try{
			
			
			// ******** <-- Check if Order Status Exist or valid -->	
			$orderstatus = $order->getStatus();
			if ($orderstatus ==	"canceled" || $orderstatus =="closed"){
				$response['description'] = 'Order was '.$orderstatus . '. Cannot process';		
				$response['code'] = "0";
			}elseif ($orderstatus =="complete"){
				$response['description'] = 'Order already complete';
				$response['code'] = "0,J";
			}elseif ($orderstatus =="processing"){
				$response['description'] = 'Order already processing';
				$response['code'] = "0,I";
			}else{
				$order->setState(Order::STATE_PROCESSING, true)
				->save();
				
				$invoice = $this->_invoiceService->prepareInvoice($order);
				
				if (!$invoice->getTotalQty()) {
				    throw new \Exception(__('Cannot create an invoice without products.'));
				}
				$amount = $invoice->getGrandTotal();
				$invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
				$invoice->register();


				$this->_transactionFactory->addObject($invoice);
				$this->_transactionFactory->addObject($invoice->getOrder());
				$this->_transactionFactory->save();

				$invoice->getOrder()->setIsInProcess(true);
				$history = $invoice->getOrder()->addStatusHistoryComment( 'Captured amount of ₱'.$amount. ' online.', true );
				$history->setIsCustomerNotified(true);
				$this->_invoiceSender->send($invoice);
				$order->save();	

				$response['description'] = "Data was successfully updated.";
				$response['orderno']  = $increment_id;
				$response['code']  = "1";
			}
		}catch(\Exception $e){
			
			$response['DocNum'] 		= $increment_id;
			$response['description'] 		= $e->getMessage();
			$response['code'] 		= "0";
		}
        
        $this->createlogs( $increment_id,"Magento",$post['cmdEvent'],$response['code'],json_encode($response['description']));
        
        return $response;
    }

    public function updateToComplete($post)
    {
        $increment_id = $post['orderno'];

		$order              = $this->_orderModel->load($increment_id, 'increment_id');//$this->_objectManager->get('Magento\Sales\Model\Order')->loadByIncrementId($increment_id);
		$orderstatus 	= $order->getStatus();
		
		$this->_order		= $order;
		if(!$this->_order->getData()){
			//throw new \Exception(__("Order Number not exists!"));
			$response['code'] = "0,H";
			$response['description'] = "Order # not found";
			return $response;
		}
        $response       = array();
        try{
			
			// ******** <-- Check if Order Status Exist or valid -->	
			$orderstatus 	= $order->getStatus();
			if ($orderstatus ==	"canceled" || $orderstatus =="closed"){
				$response['description'] = 'Order was '.$orderstatus . '. Cannot process';		
				$response['code'] = "0";
			}elseif ($orderstatus ==	"processing"){
				$connection = $this->_resource->getConnection('core_write');
				$query= "UPDATE  sales_order_grid SET  status = 'complete' WHERE increment_id = '$increment_id'";
				$connection->query($query);
		
				$order->setData('state', "complete");
				$order->setStatus("complete");       
				$history = $order->addStatusHistoryComment('Order was set to Complete by our automation tool.', false);
				$history->setIsCustomerNotified(false);
				$order->save();

				$response['description'] = "Order was successfully updated.";
				$response['orderno']  = $increment_id;
				$response['code']  = "1";
			}elseif($orderstatus ==	"complete"){
				$response['description'] = 'Status already completed';
				$response['code'] = "0,J";
			}else{
				$response['description'] = 'Order processing is required';
				$response['code'] = "0";
			}
		}catch(Exception $e){
			$response['DocNum'] 		= $increment_id;
			$response['description'] 		= $e->getMessage();
			$response['code'] 		= "0";
		}
        
        $this->createlogs( $increment_id,"Magento",$post['cmdEvent'],$response['code'],json_encode($response['description']));
        
        return $response;
    }

    public function createlogs($id,$from,$cmdEvent,$status,$message){
		$connection = $this->_resource->getConnection('core_write');
		$currentdate = date("Y-m-d H:i:s");  
		$data = array(
					'transaction_id' 	=>  $id,
					'cmdEvent'			=>	$cmdEvent,
					'data_from'			=>	$from,
					'status' 			=>  $status,
					'logs'				=>  $message,
					'date'				=>	$currentdate,
					'type'				=> 	'receive'
		);
		$connection->insert('unilab_logs_netsuite', $data);

	}

}