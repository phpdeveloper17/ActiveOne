<?php
namespace Unilab\Webservice\Model\Netsuite;

class Maintenance{
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    private $logger;
    protected $directoryList;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Eav\Setup\EavSetupFactory $eavSetupFactory
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager= $storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->eavConfig = $eavConfig;
        $this->_eavSetupFactory = $eavSetupFactory;
    }

    public function createType($post)
    {
            
        try{
            $arg_attribute = 'unilab_type';
            $arg_value = $post['name'];
            
            $attr =$this->eavConfig->getAttribute('catalog_product', $arg_attribute);
            $attr_id = $attr->getAttributeId();

            $option['attribute_id'] = $attr_id;
            $option['value']['any_option_name'][0] = $arg_value;

            $setup = $this->_eavSetupFactory->create();
            $setup->addAttributeOption($option);
            $response['ErrHndler'] = "Data was successfully saved.";
            $response['success'] 		= true;
        }catch(\Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }

        return $response;
    }
    public function createFormat($post)
    {
            
        try{
            $arg_attribute = 'unilab_format';
            $arg_value = $post['name'];
            
            $attr = $this->eavConfig->getAttribute('catalog_product', $arg_attribute);
            $attr_id = $attr->getAttributeId();

            $option['attribute_id'] = $attr_id;
            $option['value']['any_option_name'][0] = $arg_value;

            $setup = $this->_eavSetupFactory->create();
            $setup->addAttributeOption($option);
            $response['ErrHndler'] = "Data was successfully saved.";
            $response['success'] 		= true;
        }catch(\Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }

        return $response;
    }
    public function createBenefit($post)
    {
            
        try{
            $arg_attribute = 'unilab_benefit';
            $arg_value = $post['name'];
            
            $attr = $this->eavConfig->getAttribute('catalog_product', $arg_attribute);
            $attr_id = $attr->getAttributeId();

            $option['attribute_id'] = $attr_id;
            $option['value']['any_option_name'][0] = $arg_value;

            $setup = $this->_eavSetupFactory->create();
            $setup->addAttributeOption($option);
            $response['ErrHndler'] = "Data was successfully saved.";
            $response['success'] 		= true;
        }catch(\Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }

        return $response;
    }
    public function createSegment($post)
    {
            
        try{
            $arg_attribute = 'unilab_segment';
            $arg_value = $post['name'];
            
            $attr = $this->eavConfig->getAttribute('catalog_product', $arg_attribute);
            $attr_id = $attr->getAttributeId();

            $option['attribute_id'] = $attr_id;
            $option['value']['any_option_name'][0] = $arg_value;

            $setup = $this->_eavSetupFactory->create();
            $setup->addAttributeOption($option);
            $response['ErrHndler'] = "Data was successfully saved.";
            $response['success'] 		= true;
        }catch(\Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }

        return $response;
    }
    public function createDivision($post)
    {
            
        try{
            $arg_attribute = 'unilab_division';
            $arg_value = $post['name'];
            
            $attr = $this->eavConfig->getAttribute('catalog_product', $arg_attribute);
            $attr_id = $attr->getAttributeId();

            $option['attribute_id'] = $attr_id;
            $option['value']['any_option_name'][0] = $arg_value;

            $setup = $this->_eavSetupFactory->create();
            $setup->addAttributeOption($option);
            $response['ErrHndler'] = "Data was successfully saved.";
            $response['success'] 		= true;
        }catch(\Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }

        return $response;
    }
    public function createGroup($post)
    {
            
        try{
            $arg_attribute = 'unilab_group';
            $arg_value = $post['name'];
            
            $attr = $this->eavConfig->getAttribute('catalog_product', $arg_attribute);
            $attr_id = $attr->getAttributeId();

            $option['attribute_id'] = $attr_id;
            $option['value']['any_option_name'][0] = $arg_value;

            $setup = $this->_eavSetupFactory->create();
            $setup->addAttributeOption($option);
            $response['ErrHndler'] = "Data was successfully saved.";
            $response['success'] 		= true;
        }catch(\Exception $e){
            $response['ErrHndler'] 		= $e->getMessage();
            $response['success'] 		= false;
        }

        return $response;
    }
  
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
}
?>