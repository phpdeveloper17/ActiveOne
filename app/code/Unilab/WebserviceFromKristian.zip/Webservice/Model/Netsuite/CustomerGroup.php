<?php

namespace Unilab\Webservice\Model\Netsuite;

class CustomerGroup {
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    protected $logger;
    protected $_customer;
    protected $_customerAddress;

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\Address $customerAddress,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Model\ResourceModel\Group\Collection $customerGroupCollection,
        \Magento\Customer\Api\GroupRepositoryInterface $groupRepository,
        \Magento\Customer\Model\GroupFactory $groupFactory,
        \Magento\Customer\Model\Group $groupModel,
        \Unilab\Webservice\Helper\Log $logHelper
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_customer = $customer;
        $this->_customerAddress = $customerAddress;
        $this->_customerFactory = $customerFactory;
        $this->_customerGroupCollection = $customerGroupCollection;
        $this->_groupFactory = $groupFactory;
        $this->_groupRepository = $groupRepository;
        $this->_groupModel = $groupModel;
        $this->_logHelper = $logHelper;
    }

    public function create($post)
    {   
        try {
            if(
                $post['company_code'] != "" AND
                $post['company_code_name'] != "" AND
                $post['company_tin'] != "" AND
                $post['company_terms'] != "" AND
                $post['tax_class'] != "" AND
                $post['active'] != "" AND
                $post['contact_person'] != "" AND
                $post['contact_number'] != "" AND
                $post['credit_status'] != "" AND
                $post['website_id'] != "" AND
                $post['store_id'] != "" AND
                $post['internalid'] != ""
            ) {  
                $company  = $this->_groupModel->getCollection()
                    ->addFieldToFilter('netsuite_id', $post['internalid'])
                    ->addFieldToFilter('company_code', $post['company_code']);
                    
                if(!$company->getCustomerGroupId()){  
                    $store = $this->getStoreInfo($post['store_id']);
                    if($store->getId()){
                        $group = $this->_groupFactory->create();   
                            
                        $group->setCompanyCode($post['company_code']);
                        $group->setCustomerGroupCode($post['company_code_name']);
                        $group->setCompanyTin($post['company_tin']);
                        $group->setCompanyTerms($post['company_terms']);
                        $group->setTaxClassId($post['tax_class']);
                        $group->setIsActive($post['active']);
                        $group->setContactPerson($post['contact_person']);
                        $group->setContactNumber($post['contact_number']);
                        $group->setCreditStatus($post['credit_status']);
                        $group->setWebsiteId($post['website_id']);
                        $group->setStoreId($post['store_id']);
                        $group->setNetsuiteId($post['internalid']);

                        if($group->save()){
                            $response['code'] = "1";
                            $response['description'] = "Success";
                            $response['internalid'] = $group->getId();
                        }
                    }
                    else {
                        $response['code'] = "0,D";
                        $response['description'] = "Store not Found";
                        $response['data'] = ['internalid' => 1];
                    }
                } else {
                    $response['code'] = "0,N";
                    $response['description'] = "Record already exists";
                }
            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required field(s) should not be null.";
            }
        } catch (\Exception $e) {
            $response['code'] = "0";
            $response['description'] 	= $e->getMessage();
        }

        $this->_logHelper->createlogs($post['company_code'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    public function update($post)
    {
        try {
            $group  = $this->_groupModel->getCollection()
            ->addFieldToFilter('netsuite_id', $post['internalid'])
            ->addFieldToFilter('company_code', $post['company_code']);
           
            if($group->getCompanyCode()) {
                if(
                    $post['company_code'] != "" AND
                    $post['company_code_name'] != "" AND
                    $post['company_tin'] != "" AND
                    $post['company_terms'] != "" AND
                    $post['tax_class'] != "" AND
                    $post['active'] != "" AND
                    $post['contact_person'] != "" AND
                    $post['contact_number'] != "" AND
                    $post['credit_status'] != "" AND
                    $post['website_id'] != "" AND
                    $post['store_id'] != "" AND 
                    $post['internalid'] != ""
                ) {
                    $store = $this->getStoreInfo($post['store_id']);
                    if($store->getId()){
                               
                        $group->setCompanyCode($post['company_code']);
                        $group->setCustomerGroupCode($post['company_code_name']);
                        $group->setCompanyTin($post['company_tin']);
                        $group->setCompanyTerms($post['company_terms']);
                        $group->setTaxClassId($post['tax_class']);
                        $group->setIsActive($post['active']);
                        $group->setContactPerson($post['contact_person']);
                        $group->setContactNumber($post['contact_number']);
                        $group->setCreditStatus($post['credit_status']);
                        $group->setWebsiteId($post['website_id']);
                        $group->setStoreId($post['store_id']);
                        $group->setNetsuiteId($post['internalid']);
    
                        if($group->save()){
                            $response['code'] = "1";
                            $response['description'] = "Success";
                            $response['internalid'] = $group->getId();
                        }
                    }
                    else {
                        $response['code'] = "0,D";
                        $response['description'] = "Store not Found";
                        $response['data'] = ['internalid' => 1];
                    }
                } else {
                    $response['code'] = "0,E";
                    $response['description'] = "Required field(s) should not be null.";
                }
            }
            else {
                $response['code'] = "0,C";
                $response['description'] = "Client not Found";
            }
        } catch (\Exception $e) {
            $response['code'] = "0";
            $response['description'] 	= $e->getMessage();
        }

        $this->_logHelper->createlogs($post['company_code'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    public function getStoreInfo($store_id)
    {
        return $this->_storeManager->getStore($store_id);
    }
}