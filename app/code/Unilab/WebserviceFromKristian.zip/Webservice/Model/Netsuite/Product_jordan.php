<?php

namespace Unilab\Webservice\Model\Netsuite;

class Product {
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    private $logger;
    protected $directoryList;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Catalog\Model\Product $product,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Magento\Catalog\Model\Product\Gallery\ReadHandler $galleryReadHandle
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_product = $product;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->directoryList = $directoryList;
        $this->_galleryReadHandle = $galleryReadHandle;
    }

    public function create($post)
    {
        $currentdate = date("Y-m-d H:i:s");

        if (!is_dir('media/catalog/product/webservice/')) {
            mkdir('media/catalog/product/webservice', 0777, true); 	
        }

        try {
            
            if(
                $post['name'] != "" AND
                $post['product_type'] != "" AND
                $post['generic_name'] != "" AND
                $post['description'] != "" AND
                $post['short_description'] != "" AND
                $post['sku'] != "" AND 
                $post['weight'] != "" AND
                $post['status'] != "" AND
                $post['visibility'] != "" AND
                $post['unilab_rx'] != "" AND
                //$post['division'] != "" AND
                $post['unilab_format'] != "" AND
                $post['unilab_benefit'] != "" AND
                $post['unilab_segment'] != "" AND
                // $post['size'] != "" AND
                //$post['image_base'] != "" AND test
                //$post['image_small'] != "" AND test
                //$post['image_thumbnail'] != "" AND test
                $post['website_id'] != "" AND
                $post['webstore_id'] != "" AND
                // $post['category1'] != "" AND -> $post['category_ids'];
                // $post['category2'] != "" AND
                // $post['category3'] != "" AND
                // $post['category4'] != "" AND
                // $post['category5'] != "" AND
               // $post['unit_of_measure'] != "" AND test
                $post['unit_price'] != "" AND
                $post['moq'] != "" AND
                $post['price'] != "" AND
                $post['tax_class_id'] != ""
            ) {
    
                if(
                    is_string($post['category_ids']) && is_string($post['unilab_benefit']) && is_string($post['unilab_format']) && is_integer($post['unilab_type'])
                ){
                    
                    $product_id = $this->_product->getIdBySku($post['sku']);
                    $product = $this->_product->load($product_id);
                    //print_r($product->getData());
                    if($product->getSku()) {
                        $response['code'] = "0";
                        $response['description'] = "SKU Already Exist! ID: ".  $product->getId(). " Name: ". $product->getName();
                        $this->createlogs($post['sku'],"Magento",$post['cmdEvent'],$response['success'],json_encode($response['Errhandler']));
                        // $this->createVarlogs('createProductexist.log',$response['Errhandler']);
                        return $response;
                    } 
                    $catIds = explode(',',$post['category_ids']);

                    if($post['status'] == 0 ){
                        $status = 2;
                    }else
                    {
                        $status = $post['status'];
                    }
                    $oldStore = $this->_storeManager->getStore();
                    $product->setWebsiteIds($post['website_id']) 
                        ->setNetsuiteId($post['netsuite_id'])
						->setAttributeSetId(9) //9 OTC-NOSIZE
						->setTypeId('simple')
						->setSku($post['sku'])
						->setName($post['name'])
						->setGenericName($post['generic_name'])	
						->setDescription($post['description']) 
						->setShortDescription($post['short_description'])
						->setWeight($post['weight'])
						->setStatus($status)
						->setVisibility($post['visibility'])
						->setRitemedScDiscount($post['sc_discount'])
						// ->setUnilabAntibiotic($post['antibiotic'])
						->setUnilabRx($post['unilab_rx'])
						->setUnilabType($post['unilab_type'])
						->setUnilabBenefit($post['unilab_benefit'])
						->setUnilabSegment($post['unilab_segment'])
						->setUnilabDivision($post['unilab_division'])
						->setUnilabGroup($post['unilab_group'])
						->setUnilabFormat($post['unilab_format'])
						// ->setUnilabDirections($post['unilab_direction'])
						// ->setUnilabIngredients($post['unilab_ingredients'])
						// ->setUnilabBrand($post['unilab_brand'])
						->setUnilabSize($post['unilab_size'])
						->setUnilabSort($post['sort_order'])
						->setUnilabUnitPrice($post['unit_price'])
						->setUnilabMoq($post['moq'])
						->setPrice($post['price'])
						->setTaxClassId($post['tax_class_id'])
						// ->setStockData(array(
						// 	'use_config_manage_stock' => 0,
						// 	'manage_stock'=>$post['manage_stock'],
						// 	'min_sale_qty'=>1, 
						// 	'is_in_stock' =>$post['is_in_stock'],
						// 	'qty' =>$post['qty']
						// 	))
						->setCategoryIds($catIds)
                        ->setUom($post['uom']); echo '/////////////////';
                    if ($post['base_image'] != "")
                    {
                        $product->addImageToMediaGallery($imagelocbase, 'image', false,false);
                    }
                    if ($post['thumbnail_image'] != "")
                    {
                        $product->addImageToMediaGallery($imagelocthumbnail,'thumbnail', false,false);
                    }
                    if ($post['small_image'] != "") 
                    {
                        $product->addImageToMediaGallery($imagelocsmall,'small_image', false,false);
                    }

                    //$i = $p;
                
                    if($post['images'] != "")
                    { $i = $p;
                        foreach($imageslist as $key => $value)
                        {
                            if ($value)
                            {
                                $completeSaveLoc 	= $_SERVER['DOCUMENT_ROOT'].'/media/catalog/product/webservice/'.$imagename.$p. '.jpg';
                                $SaveLoc 			= "/webservice/".$imagename.$i. ".jpg";//'/c/h/'.$imagename.$p.'.png';

                                file_put_contents($completeSaveLoc, file_get_contents($value));
                                $product->addImageToMediaGallery($completeSaveLoc, '', false,false);
                            }
                        }
                        
                        $i++;
                    }

                    
                   echo '====='.$post['netsuite_id'].'=========';
                    //$product->setNetsuiteId($post['internalid']);
                    $product->setNetsuiteId($post['netsuite_id']);
                    
                    
                    //$product->getSelect()->__toString();
                    $product->getResource()->saveAttribute($product, 'netsuite_id');
                    $response['code'] = "0,L";
                    $response['description'] = "Jordan";
                    // if($product->save()){

                    //     $product_newid    = $this->_product->getIdBySku($post['sku']);
                    //     $productNew       = $this->_product->load($product_newid);  
                        
                    //     $prodid		      = $productNew->getId();	

                    //     $response['code'] = "1";
                    //     $response['sku']  = $post['sku'];
                    //     $response['description']  = "Success";
                    //     $response['id'] = $product->getId();


                    // }else{

                    //     $response['description'] = "Timeout";
                    //     $response['sku']  = $post['sku'];
                    //     $response['code']  = "0,F";
                    // }
                }
                else {
                    $response['code'] = "0,L";
                    $response['description'] = "Invalid item attributes";
                }

            } else {
                $response['code'] =  "0,E";
                $response['description'] = "Required fields should not be null";

            }
            
        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->createlogs($post['sku'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']));
    
        return $response;
    }
    

    public function update($post)
    {
        $currentdate = date("Y-m-d H:i:s");
    
        try {
            
            $product_id = $this->_product->getIdBySku($post['sku']);
            
            if($product_id) {
                
                if(
                    $post['name'] != "" AND
                    $post['product_type'] != "" AND
                    $post['generic_name'] != "" AND
                    $post['description'] != "" AND
                    $post['short_description'] != "" AND
                    $post['sku'] != "" AND 
                    $post['weight'] != "" AND
                    $post['status'] != "" AND
                    $post['visibility'] != "" AND
                    $post['unilab_rx'] != "" AND
                    //$post['division'] != "" AND
                    $post['unilab_format'] != "" AND
                    $post['unilab_benefit'] != "" AND
                    $post['unilab_segment'] != "" AND
                    // $post['size'] != "" AND
                    //$post['base_image'] != "" AND
                    //$post['small_image'] != "" //AND
                    // $post['thumbnail_image'] != "" AND
                     $post['website_id'] != "" AND
                     $post['webstore_id'] != "" AND
                    // $post['category1'] != "" AND -> $post['category_ids'];
                    // $post['category2'] != "" AND
                    // $post['category3'] != "" AND
                    // $post['category4'] != "" AND
                    // $post['category5'] != "" AND
                    //$post['unit_of_measure'] != "" AND test
                    $post['unit_price'] != "" AND
                    $post['moq'] != "" AND
                    $post['price'] != "" AND
                    $post['tax_class_id'] != ""
                ) {
                    
                    if(
                        is_string($post['category_ids']) && 
                        is_string($post['unilab_benefit']) &&
                        is_string($post['unilab_format']) &&
                        is_integer($post['unilab_type'])
                    ){
                        //Update logic here
                        
                        $oldStore = $this->_storeManager->getStore();
                        $this->_storeManager->setCurrentStore($oldStore);
                        
                        //$catIds 		= explode(',', $post['category_ids']);
                        
                        $storeids 		= array();
                        $storeids 		= explode(',',$post['webstore_id']);
                        $websiteid 		= array();
                        $imageslist = array();
                        if($post['images'] != ""){
                            $imageslist 	= explode(',',$post['images']);
                        }
                        foreach ($storeids as $key => $value) 
                        { 
                            $q 				= "SELECT website_id FROM  `store` where store_id = $value";
                            $getwebsiteid 	= $this->_getConnection()->fetchAll($q);
                            $websiteid[]	= $getwebsiteid[0]['website_id'];
                            
                        }
                        $websiteIds = implode(",",$websiteid);
                        
                        $productsku = $this->_product->getIdBySku($post['sku']);

                        $name			= sha1($post['name'])."_".$post['sku'];
                        $imagename		= str_replace(" ","_",$name);
                        $path = array();
                        
                        if ($post['base_image'] != "")
                        {
                            $path['base_image']	= $post['base_image']; 
                        }	
                        if ($post['thumbnail_image'] != "")
                        {
                            $path['thumbnail_image'] = $post['thumbnail_image']; 
                        }	
                        if ($post['small_image'] != "") 
                        {
                            $path['small_image'] = $post['small_image']; 
                        }	
                        $p=0; 
                        foreach($path as $key => $value)
                        {
                            $completeSaveLoc 	= $_SERVER['DOCUMENT_ROOT'].'/media/catalog/product/webservice/'.$imagename.$p. '.jpg';
                            $SaveLoc= "/webservice/".$imagename.$p. ".jpg";//'/c/h/'.$imagename.$p.'.png';
                            file_put_contents($completeSaveLoc, file_get_contents($value));
                    
                            if ($key == 'small_image')
                            {
                                $imagelocsmall = $completeSaveLoc;
                            }
                            if ($key == 'thumbnail_image')
                            {
                                $imagelocthumbnail = $completeSaveLoc;
                            }
                            if ($key == 'base_image')
                            {
                                $imagelocbase = $completeSaveLoc;
                            }
                            $p++;
                        } 
                        $product = $this->_product;
                        $product->load($productsku); echo $productsku;
                        /**
                         * BEGIN REMOVE EXISTING MEDIA GALLERY
                         */
                        $attributes = $this->_galleryReadHandle->execute($product);
                        //hide by jordan
                        // if (isset($attributes['media_gallery'])) 
                        // {
                        //     $gallery 		= $attributes['media_gallery'];;
                        //     //Get the images
                        //     $galleryData 	= $product->getMediaGallery ();
                        //     foreach ( $galleryData ['images'] as $image ) 
                        //     {
                        //         //If image exists
                        //         if ($gallery->getBackend()->getImage ($product, $image ['file'])['file'] == $product->getImage() and $post['image_base'] !="")
                        //         {
                        //             $gallery->getBackend()->removeImage( $product, $image ['file'] );
                        //         }
                        //         if ($gallery->getBackend()->getImage($product, $image ['file'])['file'] ==  $product->getThumbnail() and $post['image_thumbnail'] !="")
                        //         {
                        //             $gallery->getBackend()->removeImage ($product, $image ['file']);
                        //         }
                        //         if ($gallery->getBackend()->getImage($product, $image ['file'])['file'] == $product->getSmallImage() and $post['image_small'] !="")
                        //         {
                        //             $gallery->getBackend()->removeImage ($product, $image ['file']);
                        //         }
                        //         if ($gallery->getBackend()->getImage( $product, $image ['file'] )['file'] != $product->getSmallImage() and $gallery->getBackend ()->getImage( $product, $image ['file'] )['file'] != $product->getThumbnail() and $gallery->getBackend ()->getImage( $product, $image ['file'])['file'] != $product->getThumbnail() and $post['images'] !="")
                        //         {
                        //             $gallery->getBackend()->removeImage ($product, $image ['file']);
                        //         }
                        //     }
                        //     $product->save ();
                        // }
                                            /**
                         * END REMOVE EXISTING MEDIA GALLERY
                         */
                        if($post['status'] == 0 ){
                            $status = 2;
                        }else
                        {
                            $status = $post['status'];
                        }	
                                                
                        $product->setWebsiteIds($websiteid) 
                            ->setNetsuiteId($post['netsuite_id'])
                            ->setName($post['name'])
                            ->setGenericName($post['generic_name'])	
                            ->setDescription($post['description']) 
                            ->setShortDescription($post['short_description'])
                            ->setWeight($post['weight'])
                            ->setStatus($status)
                            ->setVisibility($post['visibility'])
                            // ->setRitemedScDiscount($post['sc_discount'])
                            // ->setUnilabAntibiotic($post['antibiotic'])	
                            ->setUnilabRx($post['unilab_rx'])
                            ->setUnilabType($post['unilab_type'])
                            ->setUnilabBenefit($post['unilab_benefit'])
                            ->setUnilabSegment($post['unilab_segment'])
                            ->setUnilabDivision($post['unilab_division'])		
                            ->setUnilabGroup($post['unilab_group'])
                            ->setUnilabFormat($post['unilab_format'])
                            // ->setUnilabDirections($post['unilab_direction'])
                            // ->setUnilabIngredients($post['unilab_ingredients'])
                            // ->setUnilabBrand($post['unilab_brand'])
                            ->setUnilabSize($post['unilab_size'])
                            // ->setUnilabSort($post['sort_order'])				
                            ->setUnilabUnitPrice($post['unit_price'])
                            ->setUnilabMoq($post['moq'])
                            ->setPrice($post['price'])
                            ->setTaxClassId($post['tax_class_id'])
                            // ->setStockData(array(
                            //             'use_config_manage_stock' => 0,
                            //             'manage_stock'=>$post['manage_stock'],
                            //             'min_sale_qty'=>1, 
                            //             'is_in_stock' =>$post['is_in_stock'], 
                            //             'qty' =>$post['qty']
                            //             ))
                            //->setCategoryIds($catIds);
                            ->setCategoryIds($post['category_ids']);
                            // ->setUom($post['uom']); 
                           echo '>>>test<<'; 
                        if ($post['image_base'] != "") 
                        {
                            $product->addImageToMediaGallery($imagelocbase, 'image', false,false);
                        }
                        if ($post['image_thumbnail'] != "")
                        {
                            $product->addImageToMediaGallery($imagelocthumbnail, 'thumbnail', false,false);
                        }
                        if ($post['image_small'] != "") 
                        {
                            $product->addImageToMediaGallery($imagelocsmall, 'small_image', false,false);
                        }
            
                        $i=$p;
                        foreach($imageslist as $key => $value)
                        {
                            $completeSaveLoc 	= $_SERVER['DOCUMENT_ROOT'].'/media/catalog/product/webservice/'.$imagename.$p. '.jpg';
                            $SaveLoc 			= "/webservice/".$imagename.$i. ".jpg"; 
                            file_put_contents($completeSaveLoc, file_get_contents($value));
                            $product->addImageToMediaGallery($completeSaveLoc, '', false,false);
                            $i++;
                        }
                        
                        $product->setNetsuiteId($post['internalid']);
                        $product->getResource()->saveAttribute($product, 'netsuite_id');
                        
                        if($product->save()) {

                            $product_newid    = $this->_product->getIdBySku($post['sku']);
                            $productNew       = $this->_product->load($product_newid); 
                            $prodid		      = $productNew->getId();	
        
                            $response['code'] 	= "1";
                            $response['sku']  	 	= $post['sku'];
                            $response['description']  	= "Success";
                            $response['id'] = $product->getId();

                        } else {

                            $response['description'] = "Timeout";
                            $response['sku']  = $post['sku'];
                            $response['code']  = "0,F";

                        }
            
                    }
                    else {
                        $response['code'] = "0,L";
                        $response['description'] = "Invalid item attributes";
                    }
    
                } else {
                    $response['code'] =  "0,E";
                    $response['description'] = "Required fields should not be null";
    
                }
                

            } else {
                $response['code'] = "0,B";
                $response['description'] = "Item not found";
            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->createlogs($post['sku'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']));

        return $reponse;
    }

    protected function _getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->resourceConnection->getConnection('core_write');
        }
        return $this->connection;
    }

    public function createlogs($id,$from,$cmdEvent,$status,$message){
		$connection = $this->_getConnection();
		$currentdate = date("Y-m-d H:i:s");  
		$data = array(
					'transaction_id' 	=>  $id,
					'cmdEvent'			=>	$cmdEvent,
					'data_from'			=>	$from,
					'status' 			=>  $status,
					'logs'				=>  $message,
					'date'				=>	$currentdate,
					'type'				=> 	'receive'
		);
		$connection->insert('unilab_logs_netsuite', $data);

	}
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }

    public function testProduct($post)
    {
        $response = [];
        
        if(
            is_string($post['category_ids']) && 
            is_string($post['unilab_benefit']) &&
            is_string($post['format']) &&
            is_integer($post['unilab_type'])
        ) {
            $product_id = $this->_product->getIdBySku($post['sku']);
            $product = $this->_product->load($product_id);

            // $product->setNetsuiteId(123);
            // $product->getResource()->saveAttribute($product, 'netsuite_id');

            // $product->setUnilabBenefit($post['unilab_benefit']);
            // $product->setUnilabFormat($post['format']);

            if($product->save()){
                $response['product'] = $product->getNetsuiteId();
                $response['benefits'] = $product->getUnilabBenefit();
                $response['format'] = $product->getUnilabFormat();
                $response['images']['base'] = $product->getImage();
                $response['images']['thumbnail'] = $product->getThumbnail();
                $response['images']['small_image'] = $product->getSmallImage();

            } else {
                $response['code'] = "error";
            }
        } else {

            $response['code'] = "0,L";
            $response['description'] = "Invalid item attributes";

        }
        return $response;
    }
    
}