<?php

namespace Unilab\Webservice\Model\Netsuite;

class Pricelist {
    
    public function __construct(
        \Unilab\Pricelist\Model\Pricelist $pricelistModel,
        \Unilab\Pricelist\Model\PricelistFactory $pricelistFactory,
        \Unilab\Benefits\Model\Productpricelist $productPricelistModel,
        \Unilab\Benefits\Model\ProductpricelistFactory $productPricelistFactory,
        \Magento\Customer\Model\Group $groupModel,
        \Unilab\Webservice\Helper\Log $logHelper,
        \Unilab\Benefits\Model\Pricelevel $pricelevelModel,
        \Unilab\Pricelist\Model\Catalogrule $catalogRule
    ){
        $this->_pricelistModel          = $pricelistModel;
        $this->_pricelistFactory        = $pricelistFactory;
        $this->_productPricelist        = $productPricelistModel;
        $this->_productPricelistFactory = $productPricelistFactory;
        $this->_customerGroupModel      = $groupModel;
        $this->_logHelper               = $logHelper;
        $this->_pricelevelModel         = $pricelevelModel;
        $this->_catalogRule             = $catalogRule;
    }

    public function create($post)
    {
        $response = [];
        $new_record_id = "";

        try {
            
            if(
                $post['price_id'] != "" AND
                $post['pricelist_name'] != "" AND
                $post['company_code'] != "" AND
                $post['price_level_id'] != "" AND
                $post['from_date'] != "" AND
                $post['to_date'] != "" AND
                $post['active'] != "" AND
                $post['internalid'] != ""
            ) {

                $company = $this->_customerGroupModel->load($post['company_code'], 'customer_group_code');

                if($company->getId()){

                    $pricelevel = $this->_pricelevelModel->load($post['price_level_id'], 'price_level_id');

                    $pricelist = $this->_pricelistFactory->create();
                    $pricelist->setPriceId($post['price_id']);
                    $pricelist->setName($post['pricelist_name']);
                    $pricelist->setCompany($post['company_code']);
                    $pricelist->setPriceLevelId($pricelevel->getId());
                    $pricelist->setFromDate($post['from_date']);
                    $pricelist->setToDate($post['to_date']);
                    $pricelist->setLimitedDays($post['limited_days']);
                    $pricelist->setLimitedTimeFrom($post['limited_time_from']);
                    $pricelist->setLimitedTimeTo($post['limited_time_to']);
                    $pricelist->setActive($post['active']);
                    $pricelist->setNetsuiteId($post['internalid']);

                    if($pricelist->save()){

                        $new_record_id = $pricelist->getId();
                        $response['code'] = "1";
                        $response['description'] = "Success";
                        $response['internalid'] = $new_record_id;
                    } else {
                        $response['code'] = "0,F";
                        $response['description'] = "Timeout";
                    }

                } else {
                    $response['code'] = "0,C";
                    $response['description'] = "Client not found";
                }

            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required field(s) should not be null";
            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->_logHelper->createlogs($new_record_id,"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    public function update($post)
    {
        // $pricelist = $this->_pricelistModel->load($post['price_id'], 'price_id');

        // return ['pricelist' => $pricelist->getData()];

        try {
            
            if(
                $post['pricelist'] != "" AND
                $post['company_code'] != "" AND
                $post['price_level_id'] != "" AND
                $post['from_date'] != "" AND
                $post['to_date'] != "" AND
                $post['active'] != "" AND
                $post['internalid'] != ""
            ) {

                $company = $this->_customerGroupModel->load($post['company_code'], 'customer_group_code');

                if($company->getId()){

                    $pricelevel = $this->_pricelevelModel->load($post['price_level_id'], 'price_level_id');

                    $pricelist = $this->_pricelistModel->load($post['internalid'], 'netsuite_id');
                    $pricelist->setPriceId($post['price_id']);
                    $pricelist->setName($post['pricelist']);
                    $pricelist->setCompany($post['company_code']);
                    $pricelist->setPriceLevelId($pricelevel->getId());
                    $pricelist->setFromDate($post['from_date']);
                    $pricelist->setToDate($post['to_date']);
                    $pricelist->setActive($post['active']);
                    $pricelist->setNetsuiteId($post['internalid']);

                    if($pricelist->save()){
                        $response['code'] = "1";
                        $response['description'] = "Success";
                        $response['internalid'] = $pricelist->getId();
                    } else {
                        $response['code'] = "0,F";
                        $response['description'] = "Timeout";
                    }

                } else {
                    $response['code'] = "0,C";
                    $response['description'] = "Client not found";
                }

            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required field(s) should not be null";
            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->_logHelper->createlogs($post['price_id'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    public function createProductPricelist($post)
    { 
        $response = [];
        $new_record_id = "";
        try {
            
            if(
                $post['internalid']        != "" AND
                $post['pricelist']         != "" AND
                $post['product_sku']       != "" AND
                $post['product_name']      != "" AND
                $post['qty_from']          != "" AND
                $post['qty_to']            != "" AND
                $post['from_date']         != "" AND
                $post['to_date']           != "" AND
                $post['unit_price']        != "" AND
                $post['webstore_id']       != "" AND
                $post['website_id']        != ""
            ) {
                
                $collection = $this->_productPricelist->getCollection()
                    ->addFieldToFilter('pricelist_id', $post['pricelist_id'])
                    ->addFieldToFilter('product_sku', $post['product_sku'])
                    ->load();
                    //print_r($collection->getData());
                $productPricelist = $collection->getFirstItem();
                
                if($productPricelist->getId()) {

                    $collection1 = $this->_productPricelist->getCollection()
                    ->addFieldToFilter('pricelist_id', $post['pricelist_id'])
                    ->addFieldToFilter('product_sku', $post['product_sku'])
                    ->load();
                    
                    $item = $collection1->getFirstItem();
                
                    $catalogrule = $this->_catalogRule->load($item->getPricelistId(), 'name');
                    
                    $pricelevel = $this->_pricelevelModel->load($catalogrule->getPriceLevelId());

                    $client = $this->_customerGroupModel->load($pricelevel->getPriceLevelId(), 'company_code');

                    if($client->getId()) {

                        $model = $this->_productPricelistFactory->create();
                        $model->setNetsuiteId($post['internalid']);
                        $model->setPricelistId($post['pricelist']);
                        $model->setProductSku($post['product_sku']);
                        $model->setProductName($post['product_name']);
                        $model->setQtyFrom($post['qty_from']);
                        $model->setQtyTo($post['qty_to']);
                        $model->setUnitPrice($post['unit_price']);
                        $model->setWebsiteId($post['website_id']);
                        $model->setStoreId($post['store_id']);

                        if($model->save()) {
                            
                            $new_record_id = $model->getId();

                            $response['code'] = 1;
                            $response['description'] = "Success";
                            $response['internalid'] = $new_record_id;

                        } else {
                        
                            $response['code'] = "0,F";
                            $response['description'] = "Timeout";

                        }

                    } else {

                        $response['code'] = "0,C";
                        $response['description'] = "Client not found";
                        
                    }

                } else {

                    $response['code'] = "0,N";
                    $response['description'] = "Record already exists";

                }

            } else {

                $response['code'] = "0,E";
                $response['description'] = "Required field(s) should not be null";

            }
            
        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->_logHelper->createlogs($new_record_id, "Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    public function updateProductPricelist($post)
    {
        $response = [];

        try {
            
            if(
                $post['internalid']        != "" AND
                $post['pricelist']         != "" AND
                $post['product_sku']       != "" AND
                $post['product_name']      != "" AND
                $post['qty_from']          != "" AND
                $post['qty_to']            != "" AND
                $post['from_date']         != "" AND
                $post['to_date']           != "" AND
                $post['unit_price']        != "" AND
                $post['webstore_id']       != "" AND
                $post['website_id']        != ""
            ) {

                $collection1 = $this->_productPricelist->getCollection()
                ->addFieldToFilter('pricelist_id', $post['pricelist_id'])
                ->addFieldToFilter('product_sku', $post['product_sku'])
                ->load();
                
                $item = $collection1->getFirstItem();

                $catalogrule = $this->_catalogRule->load($item->getPricelistId(), 'name');
                
                $pricelevel = $this->_pricelevelModel->load($catalogrule->getPriceLevelId());

                $client = $this->_customerGroupModel->load($pricelevel->getPriceLevelId(), 'company_code');

                if($client->getId()) {

                    $model = $this->_productPricelist->load($post['internalid'], 'netsuite_id');
                    $model->setNetsuiteId($post['internalid']);
                    $model->setPricelistId($post['pricelist']);
                    $model->setProductSku($post['product_sku']);
                    $model->setProductName($post['product_name']);
                    $model->setQtyFrom($post['qty_from']);
                    $model->setQtyTo($post['qty_to']);
                    $model->setUnitPrice($post['unit_price']);
                    $model->setWebsiteId($post['website_id']);
                    $model->setStoreId($post['store_id']);

                    if($model->save()) {
                            
                        $new_record_id = $model->getId();

                        $response['code'] = 1;
                        $response['description'] = "Success";
                        $response['internalid'] = $new_record_id;

                    } else {
                        
                        $response['code'] = "0,F";
                        $response['description'] = "Timeout";

                    }

                } else {

                    $response['code'] = "0,C";
                    $response['description'] = "Client not found";

                }
            
            } else {

                $response['code'] = "0,E";
                $response['description'] = "Required field(s) should not be null";

            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        return $response;
    }

    public function testPricelist($post)
    {
    //     $collection = $this->_productPricelist->getCollection()
    //                 ->addFieldToFilter('pricelist_id', $post['pricelist_id'])
    //                 ->addFieldToFilter('product_sku', $post['product_sku'])
    //                 ->load();
    //     $item = $collection->getFirstItem();

    //     $catalogrule = $this->_catalogRule->load($item->getPricelistId(), 'name');
        
    //     $pricelevel = $this->_pricelevelModel->load($catalogrule->getPriceLevelId());

    //     $client = $this->_customerGroupModel->load($pricelevel->getPriceLevelId(), 'company_code');

    //    if($client->getId()) {

            

    //    } else {

    //    }

       return [
           'data' => $post['data']['bodyValues']['company_code']
       ];
    }
}