<?php
namespace Unilab\Webservice\Model\Netsuite;

class Employee {
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    protected $logger;
    protected $directoryList;
    protected $_customer;
    protected $_customerAddress;

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Unilab\Webservice\Helper\Log $logHelper,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\Address $customerAddress,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Model\ResourceModel\Customer\Collection $customerCollection,
        \Magento\Customer\Model\ResourceModel\Group\Collection $customerGroupCollection,
        \Magento\Customer\Model\Group $groupModel,
        \Unilab\Benefits\Model\CompanyBranch $companyBranch,
        \Unilab\Benefits\Model\CompanyBranchFactory $companyBranchFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Customer\Model\ResourceModel\CustomerFactory $customerResourceFactory
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_customer = $customer;
        $this->_customerAddress = $customerAddress;
        $this->_customerFactory = $customerFactory;
        $this->_customerGroupCollection = $customerGroupCollection;
        $this->_customerGroupModel = $groupModel;
        $this->_companyBranch = $companyBranch;
        $this->_companyBranchFactory = $companyBranchFactory;
        $this->_logHelper = $logHelper;
        $this->_customerRepository = $customerRepository;
        $this->_customerCollection = $customerCollection;
        $this->_customerResourceFactory = $customerResourceFactory;
    }
    public function netsuitesettings($storeid){
        $baseurl  = $this->_storeManager->getStore()->getBaseUrl();
        $arr      = explode('/',$baseurl);
        $settings = [];
        $settings['gateway'] = $this->scopeConfig->getValue('webservice/netsuiteregsettings/netsuitereggateway',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeid);
        $settings['token']   = $this->scopeConfig->getValue('webservice/netsuiteregsettings/netsuiteregtoken',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeid);
        $settings['sitehost']= $this->scopeConfig->getValue('webservice/netsuiteregsettings/netsuiteurl',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeid);
        // $settings['hostname']= $arr[2];
        $settings['hostname'] = 'clickhealth.ecomqa.com';
		
		return $settings;
    }
    
    public function createEmployee($post) 
    {
        $response = [];
        $arr = [];

        try {
            if(
                $post['employee_id'] !='' AND 
                $post['company_code'] != '' AND 
                $post['price_level'] != '' AND 
                $post['shipcode'] != '' AND 
                $post['title'] != '' AND
                $post['firstname'] != '' 	AND  
                $post['middlename'] != '' AND 
                $post['lastname'] != '' AND 
                $post['email_address'] != '' AND 
                $post['date_of_birth'] != '' AND
                $post['gender'] != '' AND
                $post['password'] != '' AND
                $post['civil_status'] != '' AND
                $post['hired_date'] != '' AND
                $post['is_active'] != '' AND
                $post['contact_number'] != '' AND
                $post['date_registered'] != '' AND
                $post['employment_status'] != '' AND
                $post['website_id'] != '' AND
                $post['store_id'] != '' //AND 
                // $post['employeeid'] != ''
            ) {
                $collection = $this->_customer->getCollection()->addFieldToFilter('employee_id', $post['employee_id'])->load();
                // foreach ($collection as $emp) {
                //     $arr['id'] = $emp->getId();
                // }
                // echo $arr['id'];
                //$employee = $this->_customer->load($arr['id']);
                //echo $employee->getId();
                //if(!$employee->getId()) {
                if(count($collection) == 0){    
                    // $customerGroup  = $this->_customerGroupCollection->addFieldToFilter('customer_group_id', ['eq' => $post['company_code']]);
                    $customerGroup = $this->_customerGroupModel->load($post['company_code'], 'company_code');
                    
                    if($customerGroup->getCompanyCode()) {
                    
                        $oldStore = $this->_storeManager->getStore();
                        $this->_storeManager->setCurrentStore($oldStore);

                        $storeids 		= array();
                        $storeids 		= explode(',',$post['store_id']);
                        $websiteid 		= array();
                        $imageslist = array();
                        
                        foreach ($storeids as $key => $value) 
                        {
                            $q 				= "SELECT website_id FROM  store where store_id = $value";
                            $getwebsiteid 	= $this->_getConnection()->fetchAll($q);
                            $websiteid[]	= $getwebsiteid[0]['website_id'];
                        }
                        $websiteIds 	= implode(",",$websiteid);
        
                            
                        $customer = $this->_customerFactory->create();
                        $customer->setWebsiteId($post['website_id']);
                        $customer->setStoreId($post['store_id']);
                        $customer->setFirstname($post['firstname']);
                        $customer->setLastname($post['lastname']);
                        $customer->setMiddlename($post['middlename']);
                        $customer->setEmployeeId($post['employee_id']);
                        $customer->setGroupId($post['company_code']);
                        $customer->setPriceLevel($post['price_level']);
                        $customer->setDob($post['date_of_birth']);
                        $customer->setEmail($post['email_address']);
                        $customer->setPassword($post['password']);
                        //$customer->setDateRegistered($post['date_registered']);
                        //$customer->setCivilStatus($post['civil_status']);
                        //$customer->setActive($post['is_active']);
                        //$customer->setDateHired($post['date_hired']);
                        //$customer->setContactNumber($post['contact_number']);
                        //$customer->setEmploymentStatus($post['employment_status']);
                        $customer->setDefaultShipping($post['shipcode']);
                        $customer->setGender($post['gender']);
                        $customer->setPrefix($post['title']);
                        //$customer->setNetsuiteId($post['internalid']);
                        
                        if($customer->save()) {
                            $customerNew  = $this->_customer->load($customer->getId());
                            $customerData = $customerNew->getDataModel();
                            $customerData->setCustomAttribute('contact_number', $post['contact_number']);
                            $customerData->setCustomAttribute('date_hired', date("Y-m-d H:i:s", strtotime(@$post['date_of_hired'])));
                            $customerData->setCustomAttribute('date_registered', date("Y-m-d H:i:s", strtotime(@$post['date_registered'])));
                            $customerData->setCustomAttribute('price_level', $post['price_level']);
                            $customerData->setCustomAttribute('active', $post['is_active']);
                            $customerData->setCustomAttribute('civil_status', $post['civil_status']);
                            $customerData->setCustomAttribute('employment_status', $post['employment_status']);
                            $customerData->setCustomAttribute('employee_id', $post['employee_id']);
                            $customerData->setCustomAttribute('netsuite_id', $post['internalid']);
                            $customerNew->updateData($customerData);

                            $customerResource = $this->_customerResourceFactory->create();
                            $customerResource->saveAttribute($customerNew, 'contact_number');
                            $customerResource->saveAttribute($customerNew, 'date_hired');
                            $customerResource->saveAttribute($customerNew, 'date_registered');
                            $customerResource->saveAttribute($customerNew, 'price_level');
                            $customerResource->saveAttribute($customerNew, 'active');
                            $customerResource->saveAttribute($customerNew, 'civil_status');
                            $customerResource->saveAttribute($customerNew, 'employment_status');
                            $customerResource->saveAttribute($customerNew, 'employee_id');
                            $customerResource->saveAttribute($customerNew, 'netsuite_id');

                            $response['code'] = 1;
                            $response['description'] = "Success";
                        } else {
                            $response['code'] = "0,F";
                            $response['description'] = "Timeout";
                        }
                    }
                    else {
                        $response['code'] = "0,C";
                        $response['description'] = "Client not found";
                    }

                } else {
                    $response['code'] = "0,N";
                    $response['description'] = "Record already exists";
                }
               
            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required fields should not be null";
            }
        } catch (\Exception $e) {
            $response['description'] 		= $e->getMessage();
            $response['code'] 		= 0;
        }

        $this->_logHelper->createlogs($post['employee_id'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
            
    }

    public function updateEmployee($post) 
    {
        $response = [];
        $arr = [];

        try {
            if(
                $post['employee_id'] !='' AND 
                $post['company_code'] != '' AND 
                $post['price_level'] != '' AND 
                $post['shipcode'] != '' AND 
                $post['title'] != '' AND
                $post['firstname'] != '' 	AND  
                $post['middlename'] != '' AND 
                $post['lastname'] != '' AND 
                $post['email_address'] != '' AND 
                $post['date_of_birth'] != '' AND
                $post['gender'] != '' AND
                $post['password'] != '' AND
                $post['civil_status'] != '' AND
                $post['hired_date'] != '' AND
                $post['is_active'] != '' AND
                $post['contact_number'] != '' AND
                $post['date_registered'] != '' AND
                $post['employment_status'] != '' AND
                $post['website_id'] != '' AND
                $post['store_id'] != '' //AND
                // $post['employeeid'] != ''
            ) {

                $customerGroup = $this->_customerGroupModel->load($post['company_code'], 'company_code');

                if($customerGroup->getCompanyCode()) {
                    
                    $oldStore = $this->_storeManager->getStore();
                    $this->_storeManager->setCurrentStore($oldStore);

                    $storeids 		= array();
                    $storeids 		= explode(',',$post['storeid']);
                    $websiteid 		= array();
                    $imageslist = array();
                    
                    foreach ($storeids as $key => $value) 
                    {
                        $q 				= "SELECT website_id FROM  store where store_id = $value";
                        $getwebsiteid 	= $this->_getConnection()->fetchAll($q);
                        $websiteid[]	= $getwebsiteid[0]['website_id'];
                    }
                    $websiteIds 	= implode(",",$websiteid);
        
                    //http://blog.chapagain.com.np/magento2-create-customer-programmatically/
        
                    $collection = $this->_customer->getCollection()->addFieldToFilter('employee_id', $post['employee_id'])->load();
        
                    //can also do this
                    $item = $collection->getFirstItem();

                    // foreach ($collection as $emp) {
                    //     $arr['id'] = $emp->getId();
                    // }
    
                    if($item->getId()) {
                        $employee = $this->_customer->load($item->getId());
                        $employee->setWebsiteId($post['website_id']);
                        $employee->setStoreId($post['store_id']);
                        $employee->setFirstname($post['firstname']);
                        $employee->setLastname($post['lastname']);
                        $employee->setMiddlename($post['middlename']);
                    // $employee->setEmployeeId($post['employee_id']);
                        $employee->setGroupId($post['company_code']);
                        //$employee->setPriceLevel($post['price_level']);
                        $employee->setDob($post['date_of_birth']);
                        $employee->setEmail($post['email_address']);
                        $employee->setPassword($post['password']);
                        // $employee->setDateRegistered($post['date_registered']);
                        // $employee->setCivilStatus($post['civil_status']);
                        // $employee->setActive($post['is_active']);
                        // $employee->setDateHired($post['date_hired']);
                        // $employee->setContactNumber($post['contact_number']);
                        // $employee->setEmploymentStatus($post['employment_status']);
                        $employee->setDefaultShipping($post['shipcode']);
                        $employee->setGender($post['gender']);
                        $employee->setPrefix($post['title']);
                        $employee->setNetsuiteId($post['internalid']);
                        
                        if($employee->save()) {

                            $customerData = $employee->getDataModel();
                            $customerData->setCustomAttribute('contact_number', $post['contact_number']);
                            $customerData->setCustomAttribute('date_hired', date("Y-m-d H:i:s", strtotime(@$post['date_of_hired'])));
                            $customerData->setCustomAttribute('date_registered', date("Y-m-d H:i:s", strtotime(@$post['date_registered'])));
                            $customerData->setCustomAttribute('price_level', $post['price_level']);
                            $customerData->setCustomAttribute('active', $post['is_active']);
                            $customerData->setCustomAttribute('civil_status', $post['civil_status']);
                            $customerData->setCustomAttribute('employment_status', $post['employment_status']);
                            $customerData->setCustomAttribute('employee_id', $post['employee_id']);
                            $customerData->setCustomAttribute('netsuite_id', $post['internalid']);
                            $employee->updateData($customerData);

                            $customerResource = $this->_customerResourceFactoru->create();
                            $customerResource->saveAttribute($employee, 'contact_number');
                            $customerResource->saveAttribute($employee, 'date_hired');
                            $customerResource->saveAttribute($employee, 'date_registered');
                            $customerResource->saveAttribute($employee, 'price_level');
                            $customerResource->saveAttribute($employee, 'active');
                            $customerResource->saveAttribute($employee, 'civil_status');
                            $customerResource->saveAttribute($employee, 'employment_status');
                            $customerResource->saveAttribute($employee, 'employee_id');
                            $customerResource->saveAttribute($employee, 'netsuite_id');

                            $response['code'] = 1;
                            $response['description'] = "Success";
                        } else {
                            $response['code'] = "0,F";
                            $response['description'] = "Timeout";
                        }
                    } else {

                        $response['code'] = "0,O";
                        $response['description'] = "Employee not found";

                    }
                }
                else {
                    $response['code'] = "0,C";
                    $response['description'] = "Customer not found";
                }

            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required fields should not be null";
            }
        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->_logHelper->createlogs($post['employee_id'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    

	public function createAddress($post)
	{
       
        try {
            
            if (
                // $post['id'] != "" AND
                $post['ship_code'] != "" AND
                $post['company_id'] != "" AND
                $post['contact_person'] != "" AND //should be firstname middlename lastname
                $post['contact_number'] != "" AND //telephone
                $post['branch_address'] != "" AND
                $post['branch_province'] != "" AND
                $post['branch_city'] != "" AND
                //$post['country_id'] != "" AND //country_id
                $post['branch_postcode'] != "" AND //postcode
                $post['billing_address'] != "" AND //shipping address
                $post['shipping_address'] != "" AND //billing address
                $post['website_id'] != "" AND
                $post['webstore_id'] != "" AND
                $post['internalid'] != ""
            ) {
                $companyBranch = $this->_companyBranch->load($post['internalid'], 'netsuite_id');

                if(!$companyBranch->getId()) {

                    $group = $this->_customerGroupModel->load($post['company_id'], 'customer_group_id');
                    
                    if($group->getId()) {

                        $store_id = $this->_storeManager->getStore()->getId();

                        if($store_id == $post['webstore_id']) {
                            
                            //create address logic here
                            $companyBranch = $this->_companyBranchFactory->create();
                            $companyBranch->setShipCode($post['ship_code']);
                            $companyBranch->setCompanyId($post['company_id']);
                            $companyBranch->setContactPerson($post['contact_person']);
                            $companyBranch->setContactNumber($post['contact_number']);
                            $companyBranch->setBranchAddress($post['branch_address']);
                            $companyBranch->setBranchProvince($post['branch_province']);
                            $companyBranch->setBranchCity($post['branch_city']);
                            $companyBranch->setBranchPostcode($post['branch_postcode']);
                            $companyBranch->setShippingAddress($post['shipping_address']);
                            $companyBranch->setBillingAddress($post['billing_address']);
                            $companyBranch->setWebsiteId($post['website_id']);
                            $companyBranch->setStoreId($post['webstore_id']);
                            $companyBranch->setNetsuiteId($post['internalid']);
                            
                            if($companyBranch->save()) {
                                $response['code'] = 0;
                                $response['description'] = "Success";
                                $response['id'] = $companyBranch->getId();
                            } else {
                                $response['code'] = "0,F";
                                $response['description'] = "Timeout";
                            }

                        } else {
                            $response['code'] = "0,D";
                            $response['description'] = "Store not found";
                        }

                    } else {
                        $response['code'] = "0,C";
                        $response['description'] = "Client not found"; 
                    }
                } else {
                    $response['code'] = "0,N";
                    $response['description'] = "Record already exists";
                }

            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required fields should not be null";
            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->_logHelper->createlogs($post['company_id'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
    }

    public function updateAddress($post)
    {
        try {
            
            if (
                // $post['id'] != "" AND
                $post['ship_code'] != "" AND
                $post['company_id'] != "" AND
                $post['contact_person'] != "" AND 
                $post['contact_number'] != "" AND //telephone
                $post['branch_address'] != "" AND
                $post['branch_province'] != "" AND
                $post['branch_city'] != "" AND
                //$post['country_id'] != "" AND //country_id
                $post['branch_postcode'] != "" AND //postcode
                $post['billing_address'] != "" AND //shipping address
                $post['shipping_address'] != "" AND //billing address
                $post['website_id'] != "" AND
                $post['webstore_id'] != "" AND
                $post['internalid'] != ""
            ) {

                $group = $this->_customerGroupModel->load($post['company_id'], 'customer_group_id');
                
                if($group->getId()) {

                    $store_id = $this->_storeManager->getStore()->getId();

                    if($store_id == $post['webstore_id']) {
                        
                        //create address logic here
                        $companyBranch = $this->_companyBranch->load($post['internalid'], 'netsuite_id');
                        $companyBranch->setShipCode($post['ship_code']);
                        $companyBranch->setCompanyId($post['company_id']);
                        $companyBranch->setContactPerson($post['contact_person']);
                        $companyBranch->setContactNumber($post['contact_number']);
                        $companyBranch->setBranchAddress($post['branch_address']);
                        $companyBranch->setBranchProvince($post['branch_province']);
                        $companyBranch->setBranchCity($post['branch_city']);
                        $companyBranch->setBranchPostcode($post['branch_postcode']);
                        $companyBranch->setShippingAddress($post['shipping_address']);
                        $companyBranch->setBillingAddress($post['billing_address']);
                        $companyBranch->setWebsiteId($post['website_id']);
                        $companyBranch->setStoreId($post['webstore_id']);
                        $companyBranch->setNetsuiteId($post['internalid']);
                        
                        if($companyBranch->save()) {
                            $response['code'] = "0";
                            $response['description'] = "Success";
                            $response['id'] = $companyBranch->getId();
                        } else {
                            $response['code'] = "0,F";
                            $response['description'] = "Process timeout";
                        }

                    } else {
                        $response['code'] = "0,D";
                        $response['description'] = "Store not found";
                    }

                } else {
                    $response['code'] = "0,C";
                    $response['description'] = "Client not found"; 
                }

            } else {
                $response['code'] = "0,E";
                $response['description'] = "Required fields should not be null sss";
            }

        } catch (\Exception $e) {
            $response['code'] = 0;
            $response['description'] = $e->getMessage();
        }

        $this->_logHelper->createlogs($post['company_id'],"Netsuite",$post['cmdEvent'],$response['code'],json_encode($response['description']), "receive");

        return $response;
	}

	public function getAddressCustomerinfo($customerId,$addressId){
		
	}
	
    public function getCustomerinfo($customerId){

        $customer = $this->_customer->load($customerId);
        $customerAddress = $this->_customerAddress->load($customer->getDefaultBilling());
        $street 	 		= $customerAddress->getStreet();
		$provinceid	 		= $customerAddress->getregion_id();
		$cityid 	 		= $customerAddress->getCity();
		$cityname	 		= $customerAddress['city'];
        $customerAddressId 	= $customerAddress->getId();
        $cityname	 		= $customerAddress->getCity();
        $read		 		= $this->_getConnection(); 
		$rscity 	 		= $read->fetchRow("SELECT city_id from unilab_cities where name = '$cityname'"); 
        $subcription		= $read->fetchRow("SELECT subscriber_status FROM  newsletter_subscriber WHERE  customer_id ='$customerId'");
        $results['email'] 				= $customer->getEmail();
		$results['password'] 			= $customer->getPasswordHash();
		$results['firstname']			= $customer->getFirstname();
		$results['middlename'] 			= $customer->getMiddlename();
		$results['lastname'] 			= $customer->getLastname();
		$results['civil_status'] 		= $customer->getCivilStatus(); 
		$results['gender']	 			= $customer->getGender();
		$results['dob']					= $customer->getDob();
		$results['created_at']			= $customer->getCreatedAt();
		
		$results['storeid']				= $customer->getStoreId();
		$results['groupid']				= $customer->getGroupId();
		$results['websiteid']			= $customer->getWebsiteId();
		$results['customer_id']			= $customer->getId();
		//address
		$results['company']				= $customerAddress->getCompany();
		$results['country_id'] 			= $customerAddress->getCountry_id(); //'PH';
		$results['province'] 			= $customerAddress->getRegion();
		$results['city'] 				= $customerAddress->getCity();
		$results['address'] 			= $street[0];
		$results['postcode'] 			= $customerAddress->getpostcode();	
		$results['landline'] 			= $customerAddress->gettelephone();
		$results['mobile'] 				= $customerAddress->getmobile();
		$results['agree_on_terms'] 		= $customer->getAgreeOnTerms();
		$results['is_subscribed'] 		= $subcription['subscriber_status'];
		$results['customeraddressid'] 	= $customerAddress->getId();

		$bill = $customer->getDefaultBilling();
		$ship = $customer->getDefaultShipping();
	
		if ($ship != ""){

			$results['isshipping'] = 1;

		}else{
			$results['isshipping'] = 0;

		}
		if ($bill != ""){

			$results['isbilling'] = 1;
			
		}else{
			$results['isbilling'] = 0;

        }
        return $results;
       
    }
    public function getCustomersent($customerId)
	{
		$query 	= "SELECT sent_dbm_netsuite from customer_entity WHERE entity_id='$customerId'";
		$result = $this->_getConnection()->fetchRow($query); 
		
		return $result['sent_dbm_netsuite'];
	}
   
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
    

    public function testEmployee($post)
    {
        /**
         * employee_id = eav_attribute with id 139
         */
        //$customer = $this->_customer->load($post['employee_id']);

        //$customer = $this->_customerRepository->getById($post['id']); NOT WORKING

        // $customer->setEmployeeId('XMEN01'); //ECOMADMIN1
        // $customer->setAccountId('XMEN01');//ECOMADMIN1
        // $customer->save();
        // return [
        //         // 'customer' => $customer->getData(), 
        //         'employee_id' => $customer->getEmployeeId(),
        //         'account_id' => $post['employee_id'],
        //         'company_code' => $customer->getGroupId(),
        //         'price_level' => $customer->getPriceLevel(),
        //         'ship_code' => $customer->getDefaultShipping(),
        //         'title' => $customer->getPrefix(),
        //         'firstname' => $customer->getFirstname(),
        //         'middlename' => $customer->getMiddlename(),
        //         'lastname' => $customer->getLastname(),
        //         'email' => $customer->getEmail(),
        //         'birth_date' => $customer->getDob(),
        //         'gender' => $customer->getGender(),
        //         'password' => $customer->getPassword(),
        //         'civil_status' => $customer->getCivilStatus(),
        //         'hired_date' => $customer->getDateHired(),
        //         'active' => $customer->getActive(),
        //         'contact_no' => $customer->getContactNumber(),
        //         'date_registered' => $customer->getDateRegistered(),
        //         'employment_status' => $customer->getEmploymentStatus(),
        //         'website_id' => $customer->getWebsiteId(),
        //         'store_id' => $customer->getStoreId()
        // ];

        // $arr = [];

        $collection = $this->_customer->getCollection()->addFieldToFilter('employee_id', $post['employee_id'])->load();
        
        foreach ($collection as $customer) {
            $arr['employee_id'] = $customer->getEmployeeId();
            $arr['id'] = $customer->getId();
            $arr['firstname'] = $customer->getFirstname();
            $arr['lastname'] = $customer->getLastname();
            $arr['netsuite_id'] = $customer->getNetsuiteId();
        }

        $employee = $this->_customer->load($arr['id']);
        $employee->setNetsuiteId(123);
        $employee->save();

        return ['data' => $employee->getEmployeeId()];
    }
    protected function _getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->resourceConnection->getConnection('core_write');
        }
        return $this->connection;
    }
}
?>