<?php
namespace Unilab\Webservice\Model\Netsuite\Postdata;

  class Employee{
    protected $connection;
    protected $_customer;
    protected $NetsuiteHeader;
    //protected $_resource;

    public function __construct(
      //\Magento\Framework\App\ResourceConnection $resourceConnection,
      \Magento\Customer\Model\Customer $customer,
      \Magento\Customer\Model\ResourceModel\CustomerFactory $customerResourceFactory,
      \Unilab\Webservice\Model\OAuth\NetsuiteHeader $NetsuiteHeader,
      \Unilab\Webservice\Helper\Log $webserviceLog,
      \Magento\Framework\App\ResourceConnection $resource

    ) {
      //$this->connection = $resourceConnection;
      $this->_customer = $customer;
      $this->customerResourceFactory = $customerResourceFactory;
      $this->NetsuiteHeader = $NetsuiteHeader;
      $this->_webserviceLog = $webserviceLog;
      //$this->_resource = $resource;
    }
    public function updateEmployee($employeeId, $storeId){

       $customer = $this->_customer->load($employeeId);
       $currentdate = date("Y-m-d H:i:s");
       $gender = $customer->getGender() == 1?'Male': 'Female';
       $customerId = $customer->getEntityId();

       $data = [
          'employeeid' => $customer->getNetsuiteId(),
          'data' =>[
                    'bodyValues' =>[
                          'company_code' => $customer->getGroupId(),
                          'ship_code' => $customer->getDefaultShipping(),
                          'firstname' => $customer->getFirstname(),
                          'lastname' => $customer->getLastname(),
                          'email_address' => $customer->getEmail(),
                          'date_of_birth' => $customer->getDob(),
                          'gender' => $gender,
                          'password' => $customer->getPasswordHash(),
                          'civil_status' => $customer->getCivilStatus(),
                          'contactno' => $customer->getContactNumber(),
                          'employment_status' => $customer->getEmploymentStatus()
                      ]
          ]
        ];
        $response = $this->NetsuiteHeader->execute_curl_netsuite($data,'368'); //368
        $isSentToNS = 1;
        echo "<pre>";
          print_r($response);
        echo "</pre>";
        // echo "<pre>";
        //   print_r($customer->getData());
        // echo "</pre>";
        if(@$response['code'] == 1){ // success response
          $isSentToNS = $response['code'];
            $fields['is_sentto_ns'] = $isSentToNS;
            $fields['sentto_ns_date'] = $currentdate;
            $fields['update_sentto_ns'] = $isSentToNS;
            $fields['update_sentto_ns_date'] = $currentdate;
            $this->updateIsSentToNetsuite($employeeId,$fields);
            echo 'ok';
          $this->_webserviceLog->createlogs($customerId, 'Netsuite', 'UpdateEmployee', $isSentToNS, json_encode($response), 'send');
        }else{
          if(@$response['code']){
              $isSentToNS = @$response['code'];
              echo 'not success 1';
              $this->updateIsSentToNetsuite($employeeId,$fields);
          }else{
              $isSentToNS = 0;
              echo 'not success 2';
          }
          $this->_webserviceLog->createlogs($customerId, 'Netsuite', 'UpdateEmployee', $isSentToNS, json_encode($response), 'send');
        }
      // echo "<pre>";
      //     print_r($response);
      // echo "</pre>";
      return json_encode($response);
    }
    public function updateIsSentToNetsuite($employeeId,$fields){
      $connection = $this->_resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
      $where = array($connection->quoteInto('entity_id=?',$employeeId));
      $connection->update('customer_entity', $fields, $where);
    }
  }
 ?>
