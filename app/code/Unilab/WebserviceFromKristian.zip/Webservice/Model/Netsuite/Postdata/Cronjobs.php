<?php
namespace Unilab\Webservice\Model\Netsuite\Postdata;

class Cronjobs{
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    protected $logger;
    protected $directoryList;
    protected $_employeePostdata;
    protected $_orderPostdata;
    protected $_order;
    protected $_orderCollectionFactory;

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Model\Product $product,
        \Unilab\Webservice\Model\Netsuite\Postdata\Employee $employeePostdata,
        \Unilab\Webservice\Model\Netsuite\Postdata\Order $orderPostdata,
        //\Magento\Sales\Model\Order $order,
        //\Magento\Customer\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $employeeResourceFactory
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_employeePostdata = $employeePostdata;
        $this->_orderPostdata = $orderPostdata;
        $this->_product = $product;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->_employeeCollectionFactory = $employeeResourceFactory;
    }
    public function runcronjobs(){

    }
    public function updateEmployee(){
        $response = array();
        $StoreId = $this->_storeManager->getStore()->getStoreId();
        try{
            $query 	= 'SELECT entity_id FROM  customer_entity WHERE is_sentto_ns = 0 order by entity_id LIMIT 10';
            $result = $this->_getConnection()->fetchAll($query);

            foreach ($result as $value){
              $employeeid = $value['entity_id'];
              $response = $this->_employeePostdata->updateEmployee($employeeid, $StoreId);
              $this->createVarlogs('SendUpdateEmployeeCronJob.log', $response);
            }
        }catch(\Exception $e){
            $this->createVarlogs('NetsuitePostdataCronjobsUpdateCustomer.log', $e->getMessage());
        }
        return true;
    }
    public function sendOrder(){
        $response = array();
        $StoreId = $this->_storeManager->getStore()->getStoreId();
        try{
            $result = $this->_orderCollectionFactory->create()->addFieldToSelect(
                  ['store_id']
                  )->addFieldToFilter('is_sentto_ns', 0);
            $result->getSelect()->limit(10);
                  //print_r($result->getSelect()->__toString());
                  // echo $result->getSelect();
            foreach ($result as $value){
               $orderid = $value['entity_id'];
               $response = $this->_orderPostdata->createOrder($orderid, $StoreId);
               $this->createVarlogs('SendOrderCronJob.log', $response);
               print_r($response);
            }
        }catch(\Exception $e){
          print_r($e->getMessage());
            //$this->createVarlogs('NetsuitePostdataCronjobsSendOrder.log', $e->getMessage());
        }
        return true;
    }

    protected function _getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->resourceConnection->getConnection('core_write');
        }
        return $this->connection;
    }

    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }

}
?>
