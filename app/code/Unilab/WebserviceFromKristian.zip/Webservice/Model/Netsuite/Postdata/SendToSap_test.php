<?php
namespace Unilab\Webservice\Model\Order;

class SendToSap{

    protected $resourceConnection;
    private $logger;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
		    \Unilab\Webservice\Model\Validate\Category $Category,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Group $Group

    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_category = $Category;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_group = $Group;
        $this->_getConnection   = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

    }
    public function execute(){
    }

    public function send($increment_id=null, $cancelled = 'N'){
		date_default_timezone_set('Asia/Taipei');
		if($_POST['so_number']){
			$increment_id 	= $_POST['so_number'];
			$cancelled 		= $_POST['cancelled'];
		}
		if(empty($cancelled)){
			$cancelled = 'N';
		}
		$order 		= $this->_objectManager->create('\Magento\Sales\Model\Order')->loadByIncrementId($increment_id);

		if(!$order->getId()){
			$response['success'] 		= false;
			$response['Errhandler'] 	= "Order Number not exist!";
			return $response;
		}

		$isRxApproval = $this->checkRxapproval($order->getId());

        if($isRxApproval > 0){
			$response['success'] 		= false;
			$response['Errhandler'] 	= "$increment_id - This order Need for Rx Approval";
			$fields = array();
			$fields['is_sent']	 	= 0;
			$fields['error_logs'] 	= $response['Errhandler'];
			$this->createlogs($fields);
			return $response;
		}

		if($order->getStatus() != 'processing'){
			$response['success'] 		= false;
			$response['Errhandler'] 	= "Order Status - ".$order->getStatus().". Only processing order can send to SAP.";

			$fields = array();
			$fields['is_sent']	 	= 0;
			$fields['error_logs'] 	= $response['Errhandler'];
			$this->createlogs($fields);
			return $response;
		}

		try{
			$response['orderHeader'] 	= $this->getOrderHeader($increment_id, $cancelled);
			$response['orderDetails'] 	= $this->getallitemsDetails($order->getId());

			$SAPGateway = $this->scopeConfig->getValue('aonewebservicesection/aonewebservicegroup/urlgateway', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
			// new HTTP request to some HTTP
			$client = new Zend_Http_Client($SAPGateway);
			// set some parameters

			foreach($response['orderHeader'] as $key=>$value){
				foreach($value as $_Key=>$_value){
					$client->setParameterPost($_Key, $_value);
				}
			}

			$countItems = 0;
			$totalGrand = 0;
			foreach($response['orderDetails'] as $key=>$value){
				$Quantity 	= 0;
				$UnitPrice 	= 0;
				foreach($value as $_Key=>$_value){
					if($_Key === 'LineNum'){
						$client->setParameterPost('LineNum['.$countItems.']',$_value);
					}elseif($_Key === 'ItemCode'){
						$client->setParameterPost('ItemCode['.$countItems.']',$_value);
					}elseif($_Key === 'Quantity'){
						$Quantity = $_value;
						$client->setParameterPost('Quantity['.$countItems.']',$_value);
					}elseif($_Key === 'ItemDiscPrcnt'){
						$client->setParameterPost('ItemDiscPrcnt['.$countItems.']',$_value);
					}elseif($_Key === 'ItemDiscAmt'){
						$client->setParameterPost('ItemDiscAmt['.$countItems.']',$_value);
					}elseif($_Key === 'UnitPrice'){
						$UnitPrice = $_value;
						$client->setParameterPost('UnitPrice['.$countItems.']',$_value);
					}elseif($_Key === 'UoM'){
						$client->setParameterPost('UoM['.$countItems.']',$_value);
					}
				}

				$totalGrand = ($UnitPrice * $Quantity) + $totalGrand;
				$countItems++;
			}
			$client->setParameterPost('DocTotal', $totalGrand);
			$client->setParameterPost('Comments', "");

			$sapresponse = $client->request(Zend_Http_Client::POST);
			$SapData 	 = json_decode($sapresponse->getbody());
			//if($SapData && $SapData->success != '-1' && $SapData->success != 0){
			if($SapData && $SapData->success == 1){
				$fieldsorders 					= array();
				$fieldsorders['is_sendtosap']	= '1';

				$where = array($this->_getConnection->quoteInto('increment_id=?',$increment_id));
				$this->_getConnection->update('sales_order', $fieldsorders, $where);
				$this->_getConnection->commit();

				$where = array($this->_getConnection->quoteInto('increment_id=?',$increment_id));
				$this->_getConnection->update('sales_order_grid', $fieldsorders, $where);
				$this->_getConnection->commit();

				$fields['is_sent']	 	= 1;
				$fields['error_logs'] 	= json_encode($SapData);

				$this->createlogs($fields, $increment_id);

                file_put_contents($increment_id.'./_success_dataSendtoSap.log', print_r($response,1).PHP_EOL,FILE_APPEND);
                file_put_contents($increment_id.'./_success_sendtosap.log', print_r($SapData,1).PHP_EOL,FILE_APPEND);

			}else{
				//$this->_getConnection()->beginTransaction();
				$fields 				= array();
				$fields['is_sent']	 	= 0;
				if($SapData){
					$fields['error_logs'] 		= json_encode($SapData);
					$response['Errhandler'] 	= json_encode($SapData);
				}else{
					$fields['error_logs'] 		= $sapresponse;
					$response['Errhandler'] 	= $sapresponse;
				}
				if(empty($increment_id)){
					$increment_id = $SapData->DocNum;
				}
				$this->createlogs($fields, $increment_id);
                $response['success'] 	= false;
                file_put_contents($increment_id.'./_error_dataSendtoSap.log', print_r($response,1).PHP_EOL,FILE_APPEND);
                file_put_contents($increment_id.'./_error_SapData.log', print_r($SapData,1).PHP_EOL,FILE_APPEND);

			}

		}catch(\Exception $e){
			$fields = array();
			$fields['is_sent']	 	= 0;
			$fields['error_logs'] 	= $e->getMessage();
			$this->createlogs($fields, $increment_id);
			$response['success'] 	= false;
            $response['Errhandler'] = $e->getMessage();
            file_put_contents('./Errorto.log', print_r($e->getMessage(),1).PHP_EOL,FILE_APPEND);
		}
		return $response;
    }
    protected function createlogs($fields = null, $increment_id = null){
		try{
			$connection = $this->_getConnection;
			$connection->beginTransaction();
			$fields['date_created']	 = date("Y-m-d H:i:s");
			$fields['so_number'] 	= $increment_id;
			$connection->insert('rra_send_to_sap_report', $fields);
            $connection->commit();
            file_put_contents($increment_id .'./_sapresponse.log', print_r($fields,1).PHP_EOL,FILE_APPEND);
		}catch(Exception $e){
            $lastInsertId = false;
            file_put_contents('./error_creatinglogs.log', print_r($e->getMessage(),1).PHP_EOL,FILE_APPEND);
		}
		return true;
		//return $lastInsertId;
    }
    protected function getOrderHeader($increment_id = null, $cancelled = 'N')
	{
		$Sqlselect = $this->_getConnection->select()
				->from('sales_order', array('increment_id AS DocNum', 'customer_group_id as GrpID',
				'CONCAT(customer_firstname, " ", customer_lastname) AS EmpName',
				'discount_amount AS DiscPrcnt','discount_amount AS DiscSum',
				'grand_total AS DocTotal','tax_amount AS U_TaxAmount',
				'IF(convenience_fee > 0,convenience_fee,false) AS U_conFee'))
				->join('customer_group','sales_order.customer_group_id = customer_group.customer_group_id',
					array('company_code AS CardCode'))
				->join('sales_payment_transaction','sales_order.entity_id = sales_payment_transaction.order_id',
					array('txn_id AS U_txnNumber','parent_txn_id AS U_refNumber','created_at AS U_refCreated'))
				->join('rra_emp_purchasecap','sales_order.pcap_id = rra_emp_purchasecap.id',
					array('tnx_id AS PayTerm',))
				->join('sales_order_payment','sales_order.entity_id = sales_order_payment.parent_id',
					array('method as TenderType'))
				->join('rra_tender_type','sales_order_payment.method = rra_tender_type.paymentmethod_code',
					array('id AS TenderType'))
				 ->join('sales_order_address','sales_order_address.parent_id = sales_order.entity_id',
					 array('street AS Shipstreet'))

				->where('increment_id=?',$increment_id);

		$OrderHeader = $this->_getConnection->fetchAll($Sqlselect);

		$count=0;

		foreach($OrderHeader as $key=>$value){
			$OrderHeader[$key]['CANCELED'] = $cancelled;
			$OrderHeader[$key]['DocDate'] = date("Y-m-d H:i:s");
			$companyAddress 			=	$this->_getConnection->select()->from('rra_company_branches', array('ship_code'))
			->where('branch_address =?',$OrderHeader[$key]['Shipstreet'])->where('company_id =?',$OrderHeader[$key]['GrpID']);
			$companyAddress_item		=	$this->_getConnection->fetchRow($companyAddress);

			//$this->_getConnection()->commit();
			$OrderHeader[$key]['ShipToCode'] = $companyAddress_item['ship_code'];
			unset($OrderHeader[$key]['Shipstreet']);
			unset($OrderHeader[$key]['GrpID']);
		}
		return $OrderHeader;
	}

	protected function getallitemsDetails($orderID = 0)
	{
		$Sqlselect = $this->_getConnection->select()
				->from('sales_order_item', array('sku AS ItemCode','qty_ordered AS Quantity',
				'discount_percent AS ItemDiscPrcnt','discount_amount AS ItemDiscAmt',
				'price_incl_tax AS UnitPrice'))
				->where('order_id=?',$orderID);
		$OrderAllItems = $this->_getConnection->fetchAll($Sqlselect);
		$count=0;
		foreach($OrderAllItems as $key=>$value){
			$OrderAllItems[$key]['LineNum'] = $count;
			$OrderAllItems[$key]['UoM'] = "Pc";
			$count++;
		}
		$this->_getConnection->commit();
		return $OrderAllItems;
	}
	protected function checkRxapproval($order_id = null){
			$this->_getConnection->beginTransaction();
			$item_with_pres 			=	$this->_getConnection->select()->from('sales_order_item', array('*'))
			->where('prescription_id >?',0)->where('is_approve =?',0)->where('order_id =?',$order_id);
			$item_with_prescrestion		=	$this->_getConnection->fetchRow($item_with_pres);
			if($item_with_prescrestion['prescription_id'] > 0)	{
				//*** Change order Status to RX Approval ***///

				$fields 					= array();
				$fields['status']			= 'rx_approval';
				$where 						= array();
				$where[] 					= $this->_getConnection->quoteInto('status =?','processing');
				$where[] 					= $this->_getConnection->quoteInto('entity_id =?',$rx_not_approv);
				$this->_getConnection->update('sales_order_grid', $fields, $where);
				$this->_getConnection->commit();
				//*** Change order Status to RX Approval ***///
				$fields 					= array();
				$fields['status']			= 'rx_approval';
				$where 						= array();
				$where[] 					= $this->_getConnection->quoteInto('status =?','processing');
				$where[] 					= $this->_getConnection->quoteInto('entity_id =?',$rx_not_approv);
				$this->_getConnection->update('sales_order', $fields, $where);
				$this->_getConnection->commit();
			}
			return $item_with_prescrestion['prescription_id'];
	}
}
?>
