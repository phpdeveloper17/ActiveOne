<?php
namespace Unilab\Webservice\Model\Netsuite\Postdata;

class Testmodel{
   // protected $connection;
    protected $_order;
    protected $_customer;
    protected $transactions;
    protected $NetsuiteHeader;
    protected $storeManager;
    protected $_salesPaymentTransactions;
    protected $orderItemRepo;
    protected $itemFactory;
    protected $_orderRepository;
    protected $_resource;

    public function __construct(
        //\Magento\Framework\App\ResourceConnection $resourceConnection,
        
    ) {
        //$this->connection = $resourceConnection;
    
    }
    public function testSample(){
      return 'Testing Only';
    }
    

    
    
}
?>
