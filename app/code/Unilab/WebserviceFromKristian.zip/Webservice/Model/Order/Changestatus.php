<?php

/**
 * Copyright 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Unilab\Webservice\Model\Order;

// use Unilab\Webservice\Api\AonewebserviceInterface;
use Magento\Framework\App\RequestInterface;

/**
 * Defines the implementaiton class of the calculator service contract.
 */
class Changestatus
{
    protected $_resource;
    public function __construct(
            \Magento\Framework\App\ResourceConnection $resource,
            // \Magento\Sales\Model $_orderRepository,
            \Magento\Framework\App\ResourceConnection $resourceConnection,
            \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
			RequestInterface $request,
            \Magento\Framework\Json\Helper\Data $jsonHelper,
            \Magento\Framework\ObjectManagerInterface $_objectManager,
			\Unilab\Webservice\Model\Validate\Status $status,
			\Magento\Framework\App\RequestInterface $httpRequest
			

        ) {
            $this->_resource 		= $resource;
            // $this->order = $_orderRepository;
            $this->_resourceConnection = $resourceConnection;
            $this->_orderRepository = $orderRepository;
			$this->request 			= $request;
            $this->jsonHelper		= $jsonHelper;
            $this->_objectManager   = $_objectManager;
			$this->status           = $status;
			$this->request 			= $httpRequest;
            
        }
	
	
    public function execute(){


        // $data['token'] = 'NTI2YmFiNGQ5ODMxMDdjOThjYzBiYjY2M2UxNWE1NGM6bG9jYWxob3N0';
        
        // $isTokenValid  = $this->validateToken($data['token']);

        // if($isTokenValid['token_result'] >= 1){

        //     $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/isTokenValid.log');
        //     $logger = new \Zend\Log\Logger();
        //     $logger->addWriter($writer);
        //     $logger->info(json_encode($isTokenValid));

        // }

	}
	
	protected function getHostname(){
	
		$RequestURL = $this->request->getServer('HTTP_REFERER');
		
		if(empty($RequestURL)){
			$this->_hostname	= $this->request->getServer('HTTP_HOST');					
		}else{
			$RequestBaseurl 	= parse_url($RequestURL);
			$this->_hostname	= $RequestBaseurl['host'];					
		}
			
        return $this->_hostname;
    }	
	
	public function processOrder($post){
        
        $increment_id		= $post['so_number'];

        $order              = $this->_objectManager->get('Magento\Sales\Model\Order')->loadByIncrementId($increment_id);
        $this->_order		= $order;
        $responseData       = array();
        try{
			
			if(!$this->_order->getData()){
				Mage::throwException(__("Order Number not exists!"));
			}
			
			// ******** <-- Check if Order Status Exist or valid -->	
			
			if(!$_POST['status']){
				
				$StatusRes['MsgHndler']	= 'in_transit';
				$StatusRes['success']	= true;
				
			}else{
				$order_status	= $_POST['status'];				
				$StatusRes 		= $this->status->validatestatus($order_status);				
			}
				
			if($StatusRes['success'] == true){
				
				$response  = $this->UpdateStatus($StatusRes, $increment_id);
                // $response['success'] = false; //need to delete , for testing only
                // $response['ErrHndler'] = 'error'; //need to delete , for testing only
                
				if($response['success'] == true){
					$responseData['ReportItem'] 	= $this->getallitems();
					$responseData['orderHeader'] 	= $this->getOrderHeader($increment_id);	
					$responseData['success'] 		= $StatusRes['success'];
				}else{
					
					$responseData['success'] 	= $response['success'];
					$responseData['ErrHndler'] 	= $response['ErrHndler'];					
				}
				
				
			}else{
				
				$responseData['order_code'] = $order_status;	
				$responseData['success'] 	= $StatusRes['success'];
				$responseData['ErrHndler'] 	= $StatusRes['ErrHndler'];
			}
				
						
			
		}catch(Exception $e){
			$responseData['DocNum'] 		= $increment_id;
			$responseData['ErrHndler'] 		= $e->getMessage();
			$responseData['success'] 		= false;				
		}

		return $responseData;

    }
    
    protected function UpdateStatus($StatusRes = null)
	{
				
		if($StatusRes['MsgHndler'] === 'complete'){
			// ******** <-- Change Order Status except Compete Status -->
			$response = $this->completeorder($StatusRes['MsgHndler']);
			
		}elseif($StatusRes['MsgHndler'] === 'canceled'){
			
			// ******** <-- Change Order Status except canceled Status -->
			$response = $this->cancelorder($StatusRes['MsgHndler']);
					
		}else{
	
			$createdrresponse 	= $this->createdelivereportitem();
			if($createdrresponse['success'] == true){
				$checkItems 			= $this->getallitems();
				$totalItems				= $checkItems['OrdererItems'];
				$totalItemsdelivered	= $checkItems['DeliveredItems'];
				
				if($totalItems == $totalItemsdelivered){
					$response = $this->changeorderstatus($StatusRes['MsgHndler']);	
				}else
				{
					$response['success'] = true;					
					$response['MsgHndler'] = "Partial DR.";					
				}
			}											
		}
		
		return $response;

    }
    
	// ******** <-- Change Order Status except Compete Status -->
	protected function  changeorderstatus($status = null)
	{
			
		if($this->_order->getStatus() != 'processing'){		
			$response['ErrHndler'] 	= "Only processing order status is allowed for this transaction. Current Order Status - ". $this->_order->getStatus();
			$response['success'] 	= false;	
			return $response;
		}	
		
		try {
			
			
			$this->_getConnection->beginTransaction();				

			$fields 			= array();
			$fields['status'] 	= $status;
			$where = array($this->_getConnection->quoteInto('increment_id=?',$_POST['so_number']));
			$this->_getConnection->update('sales_order_grid', $fields, $where);		
			$this->_getConnection->commit();
			
			$history = $this->_order->addStatusHistoryComment("Order was set to $status by ".$this->getHostname(), false);			
			$history->setIsCustomerNotified(false);	
			$this->_order->setStatus($status);
			$this->_order->save();	
							
			$response['MsgHndler'] 	= $status;
			$response['success'] 	= true;	
					
			
		}catch (Mage_Core_Exception $e) {
			
			Mage::log($e->getMessage(), null, "orderChangeStatus_error.log");				
			$response['ErrHndler'] 	= $e->getMessage();
			$response['success'] 	= false;
		
		}		

		return $response;
	}


	// ******** <-- Change Order Status To Complete -->			
	protected function completeorder($status = null)
	{
		
		if($this->_order->getStatus() != 'in_transit'){		
			$response['ErrHndler'] 	= "Only In-transit order status is allowed for this transaction. Current Order Status - ". $this->_order->getStatus();
			$response['success'] 	= false;	
			return $response;
		}		
		try{
			
			$this->_order->setData('state', $status);
			$this->_order->setStatus($status);       
			$history = $this->_order->addStatusHistoryComment("Order was set to $status by ".$this->getHostname(), false);
			$history->setIsCustomerNotified(false);
			$this->_order->save();
			
			$this->_getConnection->beginTransaction();				

			$fields 			= array();
			$fields['status'] 	= $status;
			$where = array($this->_getConnection->quoteInto('increment_id=?',$_POST['so_number']));
			$this->_getConnection->update('sales_order_grid', $fields, $where);		
			$this->_getConnection->commit();			
			
			$response['MsgHndler'] 	= $status;
			$response['success'] 	= true;					
					
		}catch(Exception $e){
			
			Mage::log($e->getMessage(), null, "completeOrder_error.log");			
			$response['ErrHndler'] 	= $e->getMessage();
			$response['success'] 	= false;			
		}
		
		return $response;
		
	}
	
	// ******** <-- Change Order Status To Canceled -->			
	protected function cancelorder($status = null)
	{
		
		if($this->_order->getStatus() === 'in_transit' || $this->_order->getStatus() === 'complete'){
			Mage::throwException(Mage::helper('core')->__("Only Processing order status is allowed for this transaction. Current Order Status - ". $this->_order->getStatus()));			
		}		
		try{
			$this->_getConnection = $this->_resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
			
			$this->_order->setData('state', $status);
			$this->_order->setStatus($status);       
			$history = $this->_order->addStatusHistoryComment("Order was set to $status by ".$this->getHostname(), false);
			$history->setIsCustomerNotified(false);
			$this->_order->save();		

			$this->_getConnection->beginTransaction();				

			$fields 			= array();
			$fields['status'] 	= $status;
			$where = array($this->_getConnection->quoteInto('increment_id=?',$_POST['so_number']));
			$this->_getConnection->update('sales_order_grid', $fields,$where);		
			$this->_getConnection->commit();			

			$response['MsgHndler'] 	= $status;
			$response['success'] 	= true;					
					
		}catch(Exception $e){
			
			Mage::log($e->getMessage(), null, "cancelOrder_error.log");	
			$response['ErrHndler'] 	= $e->getMessage();
			$response['success'] 	= false;			
		}
		
		return $response;
		
	}	
	
	protected function updateorderitem()
	{
		
		$this->_getConnection()->beginTransaction();	
	
		try{
			
			$fields 				= array();
			$fields['so_number']	= $_POST['so_number'];
			$fields['dr_number']	= $_POST['dr_number'];
			$fields['item_sku']		= $_POST['item_sku'];
			$fields['item_qty']		= $_POST['item_qty'];
			$fields['date_created']	= date("Y-m-d H:i:s");
			$fields['date_updated']	= date("Y-m-d H:i:s");
			$this->_getConnection()->insert('sap_delivery_report', $fields);
			$this->_getConnection()->commit();	
		
			$response['success'] 	= true;

		}catch(Exception $e){
			
			$response['success'] 		= false;
			$response['ErrHndler'] 	= $e->getMessage();
		}	

		return $response;	
		
	}
	
	protected function createdelivereportitem()
	{
		
		$orderID = $this->_order->getId();
		$this->_getConnection()->beginTransaction();	
		
		$rescurrentdrItem = $this->getcurrentdrItem();
		
		if(!$_POST['item_qty']){
			Mage::throwException(Mage::helper('core')->__('Quantity is required'));
		}elseif($rescurrentdrItem['success'] == false){
			Mage::throwException(Mage::helper('core')->__($rescurrentdrItem['ErrHndler']));
		}else{
			$orderqtyItem = $rescurrentdrItem['MsgHndler'];
		}	
	
		try{
				
			
			$fields 				 = array();
			$fields['delivered_qty'] = $_POST['item_qty'] + $orderqtyItem;
			$where = array(
				$this->_getConnection->quoteInto('sku=?', $_POST['item_sku']),
				$this->_getConnection->quoteInto('order_id=?', $orderID));
				
			$this->_getConnection->update('sales_order_item', $fields, $where);		
			$this->_getConnection->commit();	

			
			$fields 				= array();
			$fields['so_number']	= $_POST['so_number'];
			$fields['dr_number']	= $_POST['dr_number'];
			$fields['item_sku']		= $_POST['item_sku'];
			$fields['item_qty']		= $_POST['item_qty'];
			$fields['date_created']	= date("Y-m-d H:i:s");
			$fields['date_updated']	= date("Y-m-d H:i:s");
			$this->_getConnection->insert('rra_sap_delivery_report', $fields);
			
			$this->_getConnection->commit();	
		
			$response['success'] 	= true;

		}catch(Exception $e){
			
			Mage::log($e->getMessage(), null, "DRItems_error.log");				
			$response['success'] 	= false;
			$response['ErrHndler'] 	= $e->getMessage();
		}	

		return $response;		
		
	}
	
	protected function getallitems()
	{
		$orderID = $this->_order->getId();
				
		$Sqlselect = $this->_getConnection->select()
				->from('sales_order_item', array('*')) 
				->where('order_id=?',$orderID);   
				
		$orderqtyItem = $this->_getConnection->fetchAll($Sqlselect);	
		
		$totalItems 		 = 0;
		$totalItemsdelivered = 0;
		
		foreach($orderqtyItem as $_item){
			$totalItems +=$_item['qty_ordered'];
			$totalItemsdelivered +=$_item['delivered_qty'];
		}

		$response['OrdererItems'] 	= $totalItems;
		$response['DeliveredItems'] = $totalItemsdelivered;
		
		return $response;		
	}
	
	protected function getcurrentdrItem()
	{
		
		$orderID = $this->_order->getId();
				
		$Sqlselect = $this->_getConnection->select()
				->from('sales_order_item', array('qty_ordered', 'delivered_qty')) 
				->where('order_id=?',$orderID)->where('sku=?',$_POST['item_sku']);   				
				
		$orderqtyItem 	= $this->_getConnection->fetchRow($Sqlselect);	
		
		$totaltobe 		= $orderqtyItem['delivered_qty'] + $_POST['item_qty'];
		$orderedqtyItem	= $orderqtyItem['qty_ordered'];
		
		if(!$orderqtyItem){
			$response['success'] 		= false;
			$response['ErrHndler'] 	= "SKU For this Order not exist!";			
		}
		
		elseif($totaltobe > $orderedqtyItem){
		
			$response['success'] 	= false;
			$response['ErrHndler'] 	= "Item delivered : ". $orderqtyItem['delivered_qty'] * 1 ." Ordered Item(s): " . $orderedqtyItem * 1 . ". Please check your item to be delivered : " .$_POST['item_qty'];
		}
		else{
			
			$response['success'] 	= true;
			$response['MsgHndler'] 	= $orderqtyItem['delivered_qty'];
			
		}

		return $response;
		
	}
	
	protected function getOrderHeader($increment_id = 0)
	{
		 
		$Sqlselect = $this->_getConnection->select()
				->from('sales_order', array('increment_id AS DocNum','created_at AS DocDate',
				'CONCAT(customer_firstname, " ", customer_middlename, " " , customer_lastname) AS U_MEmpName',
				'billing_address_id AS shipping_code', 
				'discount_amount AS DiscPrcnt',
				'grand_total AS DocTotal','tax_amount',
				'IF("convenience_fee" > 0,"convenience_fee",false) AS convenience_fee')) 
				->join('customer_group','sales_order.customer_group_id = customer_group.customer_group_id',
					array('company_code AS CardCode'))	
				->join('sales_order_payment','sales_order.entity_id = sales_order_payment.parent_id',
					array('method as PaymentMethod'))		
				->join('sales_payment_transaction','sales_order.entity_id = sales_payment_transaction.order_id',
					array('parent_txn_id AS U_refNumber','created_at AS U_refCreated'))	
				->join('rra_emp_purchasecap','sales_order.pcap_id = rra_emp_purchasecap.id',
					array('tnx_id AS transactionType'))		
				->join('rra_tender_type','sales_order_payment.method = rra_tender_type.payment_method_code',
					array('id AS tenderType'))							
				->where('increment_id=?',$increment_id);   

		$OrderHeader = $this->_getConnection->fetchAll($Sqlselect);	
		
		
		return $OrderHeader;		
	}
	

}