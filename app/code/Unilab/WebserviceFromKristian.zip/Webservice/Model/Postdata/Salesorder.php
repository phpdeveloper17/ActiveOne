<?php
namespace Unilab\Webservice\Model\Postdata;

class Salesorder{
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    protected $logger;
    protected $directoryList;
    protected $_customer;
    protected $_order;

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Sales\Model\Order $order
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_customer = $customer;
        $this->_order = $order;
    }
    public function webservicesettings($storeid){
		$storeId = 19;
		$settings 				= array();
		$settings['gateway'] 	= $this->scopeConfig->getValue('webservice/websettings/ahcgateway', $storeId);
		$settings['token']		= $this->scopeConfig->getValue('webservice/websettings/ahctoken', $storeId);	
		
		return $settings;
		return $settings;
    }
    public function sendorder($increment_id)
    {
        $response = array();
        try{
            $order 		= $this->_order->loadByIncrementId($increment_id);
            if($order->getStatus() != 'processing'){
                $response['success'] 	= false;
                $response['message'] 	= "Order Status - ".$order->getStatus().". Only processing order can be sent.";
                return $response;
            }
            $websettings = $this->webservicesettings();
		
            $gateway 	= $websettings['gateway'];	
            $token		= $websettings['token'];
                        
            $postdata 	= array();
            $postdata['token']			= $token;
            $postdata['cmdEvent'] 		= 'AddNewOrder';
            $postdata['orderHeader'] 	= json_encode($this->getOrderHeader($increment_id)); //json_decode(json_encode($this->getOrderHeader($increment_id), true));
            $postdata['orderDetails']	= json_decode(json_encode($this->getOrderDetails($order->getId()), true));//json_encode($this->getOrderDetails($order->getId())); 

            $client = new \Zend_Http_Client($gateway); 
                
            $client->setParameterPost('token', $postdata['token']); 
            $client->setParameterPost('cmdEvent', $postdata['cmdEvent']);
            $client->setParameterPost('orderHeader', $postdata['orderHeader']);
            $client->setParameterPost('orderDetails', $postdata['orderDetails']);
                        
            $postresponse = $client->request(\Zend_Http_Client::POST);
            
            $data 	 = json_decode($postresponse->getbody());
            if($data && $data->success == 1)
            {
                try{
                    $fields 			= array();
                    $fields['sent']		= '1';

                    $where = array($this->_getConnection()->quoteInto('increment_id=?',$increment_id));
                    $this->_getConnection()->update('sales_order', $fields, $where);
                    
                    $response['message'] = $data->message;
                    $response['success'] = $data->success;	
                    
                    $this->createSendlogs($increment_id, $fields['sent'], $data);
                    
                }catch(\Exception $e){
                    $response['message'] = $e->getMessage();
                    $response['success'] = false;
                    
                    $this->createSendlogs($increment_id, 0, $data);
                }
            }else{
                $this->createSendlogs($increment_id, 0, $data);
            }
        }catch(\Exception $e){
            $response['message'] 		= $e->getMessage();
            $response['success'] 		= false;
        }
        return $response;
	}
    public function getOrderHeader($increment_id)
	{
        $result = [];
		$qryorder = $this->_getConnection()->select()->from('sales_order', array('*')) 
				->join('sales_payment_transaction','sales_order.entity_id = sales_payment_transaction.order_id',array('*'))
				->join('sales_order_payment','sales_order.entity_id = sales_order_payment.parent_id',array('*'))
				->where('increment_id=?',$increment_id);  			
				
		$order = $this->_getConnection()->fetchRow($qryorder);			

        //Shipping
        $shipping_id = $order['shipping_address_id'];
        $qryshipto	 = $this->_getConnection()->select()->from('sales_order_address', array('*')) 
                        ->where('entity_id=?',$shipping_id);  	
        $rsshipto 	 = $this->_getConnection()->fetchRow($qryshipto);
        
        $shipto		 = $rsshipto['firstname'] . " " . $rsshipto['lastname'] . ", " . $rsshipto['street'] . ", " . $rsshipto['city'] . ", " . $rsshipto['region'] . ", " . $rsshipto['postcode']; 
        
        // Billing
        $billing_id	 = $order['billing_address_id'];
        $qrybillto 	 = $this->_getConnection()->select()->from('sales_order_address', array('*')) 
                        ->where('entity_id=?',$billing_id);  	
        $rsbillto 	 = $this->_getConnection()->fetchRow($qrybillto);
        
        $billto		 = $rsbillto['firstname'] . " " . $rsbillto['lastname'] . ", " . $rsbillto['street'] . ", " . $rsbillto['city'] . ", " . $rsbillto['region'] . ", " . $rsbillto['postcode'];  
        
        $result = array();
        $result['email'] 			= $order['customer_email'];
        $result['Trannum'] 			= $order['increment_id'];
        $result['Name'] 			= $order['customer_firstname'] . ' ' . $order['customer_lastname'];
        $result['DiscPrcnt'] 		= number_format($order['discount_amount'],4,".",","); //$order['discount_amount']; // no discount percent
        $result['DiscSum'] 			= number_format($order['discount_amount'],4,".",","); //$order['discount_amount'];
        $result['TranTotal'] 		= number_format($order['grand_total'],2,".",","); //$order['grand_total'];
        $result['TaxAmount'] 		= number_format($order['tax_amount'],2,".",","); //$order['tax_amount']; 	
        $result['RefNumber'] 		= $order['txn_id'];
        $result['RefCreated'] 		= $order['created_at'];
        $result['PaymentMethod'] 	= $order['method'];
        $result['TranDate'] 		= $order['created_at']; //order date
        $result['ShipTo'] 			= $shipto;
        $result['BillTo'] 			= $billto; 
		
		return $result;
		
    }
    public function getOrderDetails($orderID)
	{
		$qrydetails = $this->_getConnection()->select()->from('sales_order_item', array('*')) 
					->where('order_id=?',$orderID);
		$_details = $this->_getConnection()->fetchAll($qrydetails);	
		
		$result = array();
		$result2 = array();
		
		$count=0;
		foreach($_details as $details)
		{
			$result['ItemCode'] 	= $details['sku'];
			$result['Quantity'] 	= $details['qty_ordered'];
			$result['ItemDiscPrcnt'] = number_format($details['discount_percent'],2,".",","); //$details['discount_percent'];
			$result['ItemDiscAmt'] 	= number_format($details['discount_amount'],2,".",","); //$details['discount_amount']; // no discount percent
			$result['UnitPrice'] 	= number_format($details['price_incl_tax'],2,".",","); //$details['price_incl_tax'];
			$result['LineNum'] 		= $count;
			array_push($result2, $result); 
			$count++;
		}
		return $result2;		
		
	}
    protected function _getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->resourceConnection->getConnection('core_write');
        }
        return $this->connection;
    }
    public function createSendlogs($increment_id, $sent, $response)
	{
		date_default_timezone_set('Asia/Taipei');
		$date = date("Y-m-d H:i:s");
		
		$fields		= array();
		$fields['increment_id']	= $increment_id;
		$fields['sent']			= $sent;
		$fields['errror_logs']	= json_encode($response);
		$fields['createddate']	= $date;
		
		$this->_getConnection()->insert('unilab_sendtoahc_logs', $fields);
		$id = $this->_getConnection()->lastinsertid();
	}
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
    
}
?>