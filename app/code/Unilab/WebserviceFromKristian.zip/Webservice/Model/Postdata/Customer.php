<?php
namespace Unilab\Webservice\Model\Postdata;

class Customer{
    protected $connection;
    protected $resourceConnection;
    protected $_storeManager;
    protected $logger;
    protected $directoryList;
    protected $_customer;
    protected $_customerAddress;

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\Address $customerAddress
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_customer = $customer;
        $this->_customerAddress = $customerAddress;
    }
 //Create Product Webservice
    public function webservicesettings(){
        $settings 				= array();
		$settings['gateway'] 	= $this->scopeConfig->getValue('webservice/sitesettings/sitegateway');
		$settings['token']		= $this->scopeConfig->getValue('webservice/sitesettings/sitetoken');
		$settings['sitehost']	= $this->scopeConfig->getValue('webservice/sitesettings/websiteurl');
		return $settings;
    }
    public function sendcustomer($email, $websiteId)
    {
        $response = array();
        try{
            $websettings = $this->webservicesettings();
			
			$postdata 	= array();
			$postdata['gateway'] 	= $websettings['gateway'];
			$postdata['token'] 		= $websettings['token'];
			$postdata['sitehost'] 	= $websettings['sitehost'];
			$postdata['cmdEvent'] 	= 'DataMigration';
			
			$customers 				= $this->getCustomerinfo($email, $websiteId);
            $postdata['customers'] 	= $customers;

            $adapter = new \Zend_Http_Client_Adapter_Curl();
			$adapter->setCurlOption(CURLOPT_REFERER, $postdata['sitehost']);
			
			$client = new \Zend_Http_Client($postdata['gateway']); 
			$client->setAdapter($adapter);
			
			$client->setParameterPost('sitehost', $postdata['sitehost']); 
			$client->setParameterPost('token', $postdata['token']); 
			$client->setParameterPost('cmdEvent', $postdata['cmdEvent']); 
			
			$client->setParameterPost('email', $customers['email']); 
			$client->setParameterPost('password', $customers['password']); 
			$client->setParameterPost('firstname', $customers['firstname']); 
			$client->setParameterPost('middlename', $customers['middlename']); 
			$client->setParameterPost('lastname', $customers['lastname']); 
			$client->setParameterPost('civil_status', $customers['civil_status']); 
			$client->setParameterPost('gender', $customers['gender']); 
			$client->setParameterPost('dob', $customers['dob']); 
			$client->setParameterPost('created_at', $customers['created_at']);
			$client->setParameterPost('storeid', $customers['storeid']);
			
			$client->setParameterPost('country_id', $customers['country_id']); 
			$client->setParameterPost('provinceid', $customers['provinceid']); 
			$client->setParameterPost('cityid', $customers['cityid']); 
			$client->setParameterPost('address', $customers['address']); 
			$client->setParameterPost('postcode', $customers['postcode']); 
			$client->setParameterPost('landline', $customers['landline']); 
			$client->setParameterPost('mobile', $customers['mobile']); 
			
			$storeresponse = $client->request(\Zend_Http_Client::POST); 
            
            $StoreData 	 = (array) json_decode($storeresponse->getbody());
            if(@$StoreData['success'] == 1)
            {	
                try{		
                    $query 	= "update customer_entity set senttoOS='1' where email='$email' and website_id='$websiteId'";
                    $this->_getConnection()->query($query);
                }catch(Exception $e){
                    $StoreData['message'] = $e->getMessage();
                    $StoreData['success'] = false;
                }
            
            }else{
                $this->createVarlogs('wbs_OS_error_postdata.log', $postdata);
                $this->createVarlogs('wbs_OS_error_postdata.log', $StoreData);
            }
        }catch(\Exception $e){
            $StoreData['message'] 		= $e->getMessage();
            $StoreData['success'] 		= false;
        }
        return $StoreData;
	}
    public function getCustomerinfo($email, $websiteId){
        $customer = $this->_customer;
        $customer->setWebsiteId($websiteId);
        $customer->loadByEmail($email);
        $customerAddress = $this->_customerAddress->load($customer->getDefaultBilling());

        $street 	= $customerAddress->getStreet();
		$provinceid = $customerAddress->getregion_id();
		$cityid 	= $customerAddress->getCity();
		
        $cityname = $customerAddress->getCity();

        $read = $this->_getConnection(); 
		$rscity = $read->fetchRow("select city_id from unilab_cities where name = '$cityname'"); 
		
		$results['email'] 			= $customer->getEmail();
		$results['password'] 		= $customer->getPasswordHash();
		$results['firstname']		= $customer->getFirstname();
		$results['middlename'] 		= $customer->getMiddlename();
		$results['lastname'] 		= $customer->getLastname();
		$results['civil_status'] 	= $customer->getCivilStatus(); 
		$results['gender']	 		= $customer->getGender();
		$results['dob']				= $customer->getDob();
        $results['created_at']		= $customer->getCreatedAt();
        
        $results['storeid']			= $this->scopeConfig->getValue('webservice/sitesettings/storeid');
        //address
		$results['country_id'] 		= $customerAddress->getCountry_id(); //'PH';
		$results['provinceid'] 		= $customerAddress->getregion_id();
		$results['cityid'] 			= $rscity['city_id'];
		$results['address'] 		= $street[0];
		$results['postcode'] 		= $customerAddress->getpostcode();	
		$results['landline'] 		= $customerAddress->gettelephone();
		$results['mobile'] 			= $customerAddress->getmobile();
			
		return $results;
    }
    public function autosendCustomers(){
        //$websiteId 	 = $this->scopeConfig->getValue('webservice/sitesettings/websiteid');unilab2016Ecommerce
		
		//$storeId 	 = 10; //Celeteque
		//$storeId 	 = 12; //Heymom
		// $storeId 	 = 13; //Activehealth
		//$storeId 	 = 16; //Athena
		//$storeId 	 = 21; //Clearascar
		//$storeId 	 =  1; //Clickhealth
		
		//$websiteId 	 = 3; //Celeteque
		//$websiteId 	 = 5; //Heymom
		$websiteId 	 = 6; //Activehealth
		//$websiteId 	 = 9; //Athena
		//$websiteId 	 = 14; //Clearascar
        //$websiteId 	 = 1; //Clickhealth
        // $qry = "SELECT distinct email FROM  customer_entity a LEFT JOIN customer_entity_varchar b ON a.entity_id = b.entity_id WHERE  website_id = $websiteId AND  senttoOS =0 AND attribute_id =5 AND  value NOT LIKE  '%please%' order by email LIMIT 200";
        $qry = "SELECT distinct email FROM  customer_entity a LEFT JOIN customer_entity_varchar b ON a.entity_id = b.entity_id WHERE  website_id = 1 AND  senttoOS =0 AND attribute_id =140 AND  value NOT LIKE  '%please%' order by email LIMIT 1";
		$_result = $this->_getConnection()->fetchAll($qry);	
		$response = [];
		foreach($_result as $result){
            $email2 = $result['email'];
            $response = $this->sendcustomer($email2, $websiteId);
		}
		
		return $response;
    }
    protected function _getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->resourceConnection->getConnection('core_write');
        }
        return $this->connection;
    }
    public function createlogs($id,$from,$cmdEvent,$status,$message){
		$connection = $this->_getConnection();
		$currentdate = date("Y-m-d H:i:s");  
		$data = array(
					'transaction_id' 	=>  $id,
					'cmdEvent'			=>	$cmdEvent,
					'data_from'			=>	$from,
					'status' 			=>  $status,
					'logs'				=>  $message,
					'date'				=>	$currentdate,
					'type'				=> 	'send'
		);
		$connection->insert('unilab_logs_netsuite', $data);
	}
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
    
}
?>