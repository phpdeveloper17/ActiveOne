<?php
namespace Unilab\Webservice\Model\ResourceModel\OrderStatus;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	protected $_eventPrefix = 'unilab_webservice_token_collection';
	protected $_eventObject = 'token_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Unilab\Webservice\Model\Token', 'Unilab\Webservice\Model\ResourceModel\Token');
	}

}