<?php
namespace Unilab\Webservice\Model\ResourceModel\Logs;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	protected $_eventPrefix = 'unilab_webservice_logs_collection';
	protected $_eventObject = 'logs_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Unilab\Webservice\Model\Logs', 'Unilab\Webservice\Model\ResourceModel\Logs');
	}

}