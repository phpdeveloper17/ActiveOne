<?php
namespace Unilab\Webservice\Model\ResourceModel\Companies;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	protected $_eventPrefix = '_collection';
	protected $_eventObject = 'companies_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Unilab\Webservice\Model\Companies', 'Unilab\Webservice\Model\ResourceModel\Companies');
	}

}