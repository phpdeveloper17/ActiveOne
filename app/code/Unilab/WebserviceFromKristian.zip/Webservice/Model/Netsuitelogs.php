<?php
namespace Unilab\Webservice\Model;
class Netsuitelogs extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'unilab_logs_netsuite';

	protected $_cacheTag = 'unilab_logs_netsuite';

	protected $_eventPrefix = 'unilab_logs_netsuite';

	protected function _construct()
	{
		$this->_init('Unilab\Webservice\Model\ResourceModel\Netsuitelogs');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}

}