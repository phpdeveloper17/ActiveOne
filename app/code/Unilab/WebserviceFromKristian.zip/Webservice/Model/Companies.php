<?php
namespace Unilab\Webservice\Model;
class Companies extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'customer_group';

	protected $_cacheTag = 'customer_group';

	protected $_eventPrefix = 'customer_group';

	protected function _construct()
	{
		$this->_init('Unilab\Webservice\Model\ResourceModel\Companies');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}


}