<?php
namespace Unilab\Webservice\Model\Product;

class Product{
    protected $resourceConnection;
    protected $_storeManager;
    private $logger;
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection,
		\Unilab\Webservice\Model\Validate\Category $Category,
        \Magento\Catalog\Model\Product $product,
        \Magento\Framework\ObjectManagerInterface $_objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry

    ) {
        $this->resourceConnection = $resourceConnection;
        $this->_category = $Category;
        $this->_product = $product;
        $this->_objectManager   = $_objectManager;
        $this->_storeManager=$storeManager;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_registry = $registry;


    }
 //Create Product Webservice


 public function Addnewproduct()
 {

    $DbFilename = null;			
    $_POST['websiteids'] 	= array(1);
    $_POST['countrycode'] 	= $this->scopeConfig->getValue('general/country/default',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    
    if($_POST['unilab_rx'] == true){
        $_POST['istype'] 		= 6;
        $_POST['attributeid']	= 2;
    }else{
        $_POST['istype'] 		= 7;	
        $_POST['attributeid']	= 1;			
    }
                    
                        
    //if($_POST['ImgFilename']){
    //	$DbFilename = Mage::helper('aonewebservice')->createproductimage($_POST['ImgFilename']);
    //}
    
 //    Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);
    $product_id = $this->_product->getIdBySku($_POST['sku']);
    
    if($product_id){
        
        $product = $this->_product->load($product_id);
        $response['success'] 	= false;
        $response['Errhandler'] = "SKU Already Exist! ID: ".  $product->getId(). " Name: ". $product->getName();
        
        return $response;

    }

    try{
        
     //    Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);				
        $product =$this->_product;

        $product
            ->setWebsiteIds($_POST['websiteids'])
            ->setAttributeSetId($_POST['attributeid'])
            ->setTypeId('simple')
            ->setCreatedAt(strtotime('now')) 
            ->setSku($_POST['sku']) 
            ->setName($_POST['name']) 
            ->setWeight($_POST['weight'])
            ->setStatus($_POST['status'])
            ->setTaxClassId($_POST['tax_class_id'])
            ->setVisibility(4)
            ->setNewsFromDate(strtotime('now'))
            ->setNewsToDate(strtotime('now'))
            ->setgeneric_name($_POST['generic_name'])
            ->setunilab_unit_price($_POST['unit_price'])
            ->setunilab_moq($_POST['moq'])
            ->setunilab_rx($_POST['unilab_rx'])
            ->setunilab_type($_POST['istype'])
            ->setunilab_uom($_POST['uom'])
            ->setuom($_POST['uom'])
            ->setunilab_benefit($_POST['unilab_benefit'])
            ->setCountryOfManufacture($_POST['countrycode']) 
            /*
			->setPrice($_POST['moq'] * $_POST['unit_price'])
            ->setCost($_POST['moq'] * $_POST['unit_price'])
			*/

            ->setDescription($_POST['description'])
            ->setShortDescription($_POST['short_description'])
            //->setMediaGallery (array('images'=>array (), 'values'=>array ()))
            //->addImageToMediaGallery('media/catalog/product/'.$DbFilename, array('image','thumbnail','small_image'), false, false)	
            ->setStockData(array(
                               'use_config_manage_stock' => 0,
                               'manage_stock'=>0,
                               'min_sale_qty'=>1, 
                               'is_in_stock' => 1, 
                               'qty' => $_POST['qty']
                           ))->setCategoryIds($this->getcategoryids());
                
        $product->save();
        
        $product_newid  		= $this->_product->getIdBySku($_POST['sku']);
        $productNew 			= $this->_product->load($product_newid);			
        $response['id'] 		= $productNew->getId();
        $response['success'] 	= true;
        $response['msgHndlr'] 	= "Product was successfully added.";

    }catch(Exception $e){
        
        $response['success'] 	= false;
        $response['Errhandler'] = $e->getMessage();
    }	
    
        
    return $response;

}


    // Update Product Webservice
    public function Updateproducts()
	{
		
		$DbFilename 					= null;
		$_POST['websiteids']	        = array(1);
		
		if($_POST['unilab_rx'] == true){
			$_POST['istype'] 		= 6;
			$_POST['attributeid']	= 1;
		}else{
			$_POST['istype'] 		= 7;	
			$_POST['attributeid']	= 2;			
		}

		$product_id  = $this->_product->getIdBySku($_POST['sku']);

		if(!$product_id){
            $this->logger->critical("SKU Not Exist!");
		}
			
        
        // $_POST['countrycode'] 	= $this->scopeConfig->getStoreConfig('general/country/default');
       $_POST['countrycode'] 	= $this->scopeConfig->getValue('general/country/default',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        
		
		$categoryId 					= $this->_category->_getcatId($_POST['categoryName']);
		$_POST['categoryids'] 	= array( $this->_storeManager->getStore("default")->getRootCategoryId(), $categoryId);		
		

		// Mage::setIsDeveloperMode(true);
		//       Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);
		// $this->_storeManager->setCurrentStore($this->_storeManager->load(Mage_Core_Model_App::ADMIN_STORE_ID));

// Mage::app()->setCurrentStore(Mage::getModel('core/store')->load(Mage_Core_Model_App::ADMIN_STORE_ID));



		//REMOVE COMMENT / ADD 
		//$this->_storeManager->setCurrentStore('ADMIN_STORE_ID');


		$product =  $this->_product->load($product_id);

		$product
					->setWebsiteIds($_POST['websiteids'])
					->setAttributeSetId($_POST['attributeid'])
					->setTypeId('simple')
					->setCreatedAt(strtotime('now')) 
					->setSku($_POST['sku']) 
					->setName($_POST['name']) 
					->setWeight($_POST['weight'])
					->setStatus($_POST['status'])
					->setTaxClassId($_POST['tax_class_id'])
					->setVisibility(\Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH)
					->setNewsFromDate(strtotime('now'))
					->setNewsToDate(strtotime('now'))
					->setgeneric_name($_POST['generic_name'])
					->setunilab_unit_price($_POST['unit_price'])
					->setunilab_moq($_POST['moq'])
					->setunilab_rx($_POST['unilab_rx'])
					->setunilab_type($_POST['istype'])
					->setunilab_uom($_POST['uom'])
					->setunilab_benefit($_POST['unilab_benefit'])
					->setCountryOfManufacture($_POST['countrycode']) 
					/*
					->setPrice($_POST['moq'] * $_POST['unit_price']) 
					->setCost($_POST['moq'] * $_POST['unit_price'])
					*/
					->setDescription($_POST['description'])
					->setShortDescription($_POST['short_description'])
					//->setMediaGallery (array('images'=>array (), 'values'=>array ()))
					//->addImageToMediaGallery('media/catalog/product/'.$DbFilename, array('image','thumbnail','small_image'), false, false)	
					->setStockData(array(
									   'use_config_manage_stock' => 0,
									   'manage_stock'=>0,
									   'min_sale_qty'=>1, 
									   'is_in_stock' => 1, 
									   'qty' => $_POST['qty']
								   ))->setCategoryIds($this->getcategoryids());

		try { 
		
			$product->save(); 
			
			$product_newid  		= $this->_product->getIdBySku($_POST['sku']);
			$productNew 			= $this->_product->load($product_newid);
			
			$productnewDetails['id'] 				= $product_newid;
			$productnewDetails['sku'] 				= $productNew->getSku();
			$productnewDetails['name'] 				= $productNew->getname();
			$productnewDetails['description'] 		= $productNew->getdescription();
			$productnewDetails['shortdescription'] 	= $productNew->getShortDescription();
		
			$response['success'] 		 			= true;
			$response['productDeteails'] 			= $productnewDetails;
			$response['msgHndlr'] 		 			= "Product was successfully updated.";
				
			
		}catch(Exception $e) { 
		
			$response['success'] 	= false;
			$response['Errhandler'] = $e->getMessage();
			
		} 
			
		return $response;		
		
    }

    //Update Product Price Webservice
    
	public function Updateproductsprice($post)
	{
	
		$product_id = $this->_product->getIdBySku($post['sku']);

		if($product_id){
			
			// Mage::setIsDeveloperMode(true);
			// $this->_storeManager->setCurrentStore($this->_storeManager->load(Mage_Core_Model_App::ADMIN_STORE_ID));
            $this->_storeManager->setCurrentStore(\Magento\Store\Model\Store::ADMIN_CODE);
			$product = $this->_product->load($product_id);

			$product->setPrice($post['price']);
			$product->setCost($post['price']);
			$product->setunilab_unit_price($post['price']);

			try { 
			
				$product->save(); 
				// $response['ProductName'] 	= $product->getName();
				// $response['ProductID'] 		= $product->getId();
				$response['success'] 		= true;
				$response['Errhandler'] 	= "Price was successfully updated!";
				
			}catch(Exception $e) { 
			
				$response['success'] 	= false;
				$response['Errhandler'] = $e->getMessage();
				
			} 
							
		}else{
			
			$response['success'] 	= false;
			$response['Errhandler'] = "SKU Not Exist!";			
		}

		return $response;		
		
	}

    // DELETE PRODUCTS WEBSERVICE

    public function deleteproducts()
	{
		
		$product_id = $this->_product->getIdBySku($_POST['sku']);
		$this->_registry->register('isSecureArea', true);
		
		if(!$product_id){
            $this->logger->critical("SKU Not Exist!");
		}
		
		try{
			$this->_product->load($product_id)->delete();
			
			$response['success'] 	= true;
			// $response['prodID'] 	= $product_id;
			$response['Errhandler'] = "Product was successfully deleted!";
			
		}catch(Exception $e){
			
			$response['success'] 	= false;
			$response['Errhandler'] = $e->getMessage();			
		}
			
			
		return $response;

	}

    //Show Product Data Webservice
	
    public function showdata(){
		 
		$response 		= $this->_product->load($_POST['id'])->getData(); 		
			
		return $response;

    }
    
    //Inactive Product Webservice

    public function Inactive()
	{
	
		$product_id = $this->_product->getIdBySku($_POST['sku']);

		if($product_id){
			
			// Mage::setIsDeveloperMode(true);
			// Mage::app()->setCurrentStore(Mage::getModel('core/store')->load(Mage_Core_Model_App::ADMIN_STORE_ID));
            $this->_storeManager->setCurrentStore(\Magento\Store\Model\Store::ADMIN_CODE);

			$product = $this->_product->load($product_id);

			$product->setStatus($_POST['status']);

			try { 
			
				if($product->getStatus() == 1){
					$response['Status'] = "Enabled";
				}else{
					$response['Status'] = "Disabled";					
				}
				
				$product->save(); 
				$response['SKU'] 			= $_POST['sku'];
				$response['ProductName'] 	= $product->getName();
				$response['success'] 		= true;
				$response['msgHndlr'] 		= "Product was successfully ". $response['Status']. "!";
				
			}catch(Exception $e) { 
			
				$response['success'] 	= false;
				$response['Errhandler'] = $e->getMessage();
				
			} 
							
		}else{
			
			$response['success'] 	= false;
			$response['Errhandler'] = "SKU Not Exist!";			
		}

		return $response;		
		
	}

	protected function getcategoryids(){
		
		$categotyids = explode(",", $_POST['categoryName']);		
		$catids = array();		
		foreach($categotyids as $_value){			
			$catids[] = $this->_category->_getcatId($_value);			
		}

		return $catids;
	}


}
?>