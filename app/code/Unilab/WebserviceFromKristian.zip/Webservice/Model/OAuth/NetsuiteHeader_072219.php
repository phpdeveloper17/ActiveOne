<?php
namespace Unilab\Webservice\Model\OAuth;

use \Unilab\Webservice\Model\OAuth\OAuthConsumer;
use \Unilab\Webservice\Model\OAuth\OAuthToken;
use \Unilab\Webservice\Model\OAuth\OAuthSignatureMethodHMACSHA1 as OAuthSignatureMethod_HMAC_SHA1;
use \Unilab\Webservice\Model\OAuth\OAuthRequest;
class NetsuiteHeader{

	protected $OAuthConsumer;
	protected $scopeConfig;
    public function __construct(
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
		$this->scopeConfig = $scopeConfig;
		header("Access-Control-Allow-Origin: *");
		header("Access-Control-Allow-Headers: origin, x-requested-with, content-type");
		header("Access-Control-Allow-Methods: PUT, GET, POST");
    }
    public function getNetsuiteCmdEvent($cmdEvent)
	{
		$cmdevents = [];
		$cmdevents['cmdID'] = '8';
		$cmdevents['cmdMethod'] = 'POST';
		return $cmdevents;
    }
    public function getNetsuiteSettings()
	{
		$settings 					= [];
		$settings['enabled'] 		= $this->_scopeConfig('webservice/netsuitesettings/enabled');
		$settings['gateway'] 		= $this->_scopeConfig('webservice/netsuitesettings/gateway');
		$settings['consumer_secret']= $this->_scopeConfig('webservice/netsuitesettings/consumer_secret');
		$settings['token_secret']	= $this->_scopeConfig('webservice/netsuitesettings/token_secret');
		$settings['consumer_key']	= $this->_scopeConfig('webservice/netsuitesettings/consumer_key');
		$settings['token_key']		= $this->_scopeConfig('webservice/netsuitesettings/token_key');
		$settings['realm']			= $this->_scopeConfig('webservice/netsuitesettings/realm');
		$settings['auth_version']	= $this->_scopeConfig('webservice/netsuitesettings/auth_version');
		return $settings;
	}
	public function _scopeConfig($path){
		return $this->scopeConfig->getValue(
		$path,
		\Magento\Store\Model\ScopeInterface::SCOPE_STORE
		);
	}
    public function get2faHeader($cmdEvent){

		$netsuiteCmdEvent 	= $this->getNetsuiteCmdEvent($cmdEvent);
		$netsuiteSetting  	= $this->getNetsuiteSettings();

		$cmdID  = $netsuiteCmdEvent['cmdID'];
		$cmdMethod  = $netsuiteCmdEvent['cmdMethod'];

		$realm  = $netsuiteSetting['realm'];
		$gateway = $netsuiteSetting['gateway'];
		$ckey = $netsuiteSetting['consumer_key']; //Consumer Key
		$csecret = $netsuiteSetting['consumer_secret']; //Consumer Secret
		$tkey = $netsuiteSetting['token_key']; //Token ID
		$tsecret = $netsuiteSetting['token_secret']; //Token Secret

		$oauthVersion	= $netsuiteSetting['auth_version'];
		$url 			= $gateway.$cmdID."&deploy=1";

		$consumer = new OAuthConsumer($ckey, $csecret);
		$token = new OAuthToken($tkey, $tsecret);
		$sig = new OAuthSignatureMethod_HMAC_SHA1();
		$params = array(
			'oauth_nonce' => $this->generateRandomString(),
			'oauth_timestamp' => idate('U'),
			'oauth_version' => $oauthVersion,
			'oauth_token' => $tkey,
			'oauth_consumer_key' => $ckey,
			'oauth_signature_method' => $sig->get_name(),
		);

		$req = new OAuthRequest($cmdMethod,$url, $params);
		$req->set_parameter('oauth_signature', $req->build_signature($sig, $consumer, $token));
		$req->set_parameter('realm', $realm);

		$header = array(
			'header' => $req->to_header() . ',realm="'.$realm.'"',
			'Content-Type: application/json'

		);

		return $header;

	}

	public function generateRandomString() {
		$length = 20;
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';

		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	public function execute_curl_netsuite($data,$cmdEvent)
	{
		$netsuiteSetting  	= $this->getNetsuiteSettings();
		$netsuiteCmdEvent 	= $this->getNetsuiteCmdEvent($cmdEvent);

		$cmdID 				= $netsuiteCmdEvent['cmdID'];
		$cmdMethod 			= $netsuiteCmdEvent['cmdMethod'];
		$url				= $netsuiteSetting['gateway'];

		if($netsuiteSetting['enabled'] == 1)
		{


			$headers = $this->get2faHeader($cmdEvent);

			$gateway = curl_init($url.$cmdID.'&deploy=1');

			curl_setopt($gateway, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($gateway, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($gateway, CURLOPT_ENCODING, '');
			curl_setopt($gateway, CURLOPT_MAXREDIRS, 10);
			curl_setopt($gateway, CURLOPT_TIMEOUT, 30);
			curl_setopt($gateway, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
			curl_setopt($gateway, CURLOPT_CUSTOMREQUEST, $cmdMethod);
			curl_setopt($gateway, CURLOPT_POSTFIELDS, json_encode($data));
			curl_setopt($gateway, CURLOPT_HTTPHEADER, $headers);

			$response = curl_exec($gateway);

			curl_close($gateway);
			// file_put_contents("logs/return_netsuite".date('M-d-Y').".log", date('M-d-Y H:i:s')." ===== ".$response.PHP_EOL , FILE_APPEND);
			$response = json_decode($response,true);
			// echo "<pre>";
			// 	print_r($response);
			// echo "</pre>";
			// die;
		}else{
			$response['message']  			= "Netsuite setting is disabled.";
			$response['status']  			= false;
			$response['data']['success']	= false;
		}

		// $logs_tblName = 'connectionlogs_from_netsuite';

		// $this->Logs_model->insertLogs($data,$response,$url,$logs_tblName,$cmdEvent);
		// $data2 		= json_encode($data);
		// $response2 	= json_encode($response);
		// file_put_contents("logs/".$cmdEvent."_postdata_to_netsuite".date('M-d-Y').".log", date('M-d-Y H:i:s')." ===== ".$data2.PHP_EOL , FILE_APPEND);
		// file_put_contents("logs/".$cmdEvent."_response_to_netsuite".date('M-d-Y').".log", date('M-d-Y H:i:s')." ===== ".$response2.PHP_EOL , FILE_APPEND);

		return $response;

	}
}
?>
