<?php
namespace Unilab\Webservice\Model;
class OrderStatus extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'unilab_webservice_orderstatus';

	protected $_cacheTag = 'unilab_webservice_orderstatus';

	protected $_eventPrefix = 'unilab_webservice_orderstatus';

	protected function _construct()
	{
		$this->_init('Unilab\Webservice\Model\ResourceModel\OrderStatus');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}