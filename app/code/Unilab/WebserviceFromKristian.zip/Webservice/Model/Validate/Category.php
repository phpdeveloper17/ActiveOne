<?php
namespace Unilab\Webservice\Model\Validate;

class Category{
    protected $resourceConnection;

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        $this->resourceConnection = $resourceConnection;
    }    

    public function _getcatId($category_code=null)
	{	

        $connection             = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
		$categotysql 		    = "SELECT entity_id FROM catalog_category_entity_text WHERE value = '$category_code'";						
        $query                  = $connection->query($categotysql);
        $categoryidResult       = $query->fetch();
		
		if(!$categoryidResult['entity_id']){
			$categoryidResult['entity_id'] = 0;
		}
		
		return $categoryidResult['entity_id'];		
	}


}
?>