<?php
namespace Unilab\Webservice\Model\Validate;

class Status{
    protected $resourceConnection;

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        $this->resourceConnection = $resourceConnection;
    }


    public function validatestatus($status)
	{
		
        $connection = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        $query = $connection->query('SELECT id,status_name FROM unilab_aonestatus where status_name = "'.$status.'"');
        $result = $query->fetch();

		if(!empty($result['id']) && !empty($result['status_name'])){
			
			$response['MsgHndler'] 	= $result['status_name'];
			$response['success'] 	= true;

		}else{
			
			$response['ErrHndler'] 	= "Order Status code is not exist!";
			$response['success'] 	= false;
		}		

		return $response;

	}


}



?>