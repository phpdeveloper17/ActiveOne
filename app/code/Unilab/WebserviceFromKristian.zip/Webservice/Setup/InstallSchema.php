<?php

namespace Unilab\Webservice\Setup;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
	
	public function install(\Magento\Framework\Setup\SchemaSetupInterface $setup, \Magento\Framework\Setup\ModuleContextInterface $context)
	{
		$installer = $setup;
		$installer->startSetup();
		// Unilab Token Table
		if (!$installer->tableExists('unilab_token')) {
			$table = $installer->getConnection()->newTable(
				$installer->getTable('unilab_token')
			)
				->addColumn(
					'id',
					\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					11,
					[
						'auto_increment' => true,
                        'nullable' => false,
                        'primary' => true,
					],
					'ID'
				)
				->addColumn(
					'store',
					\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					11,
					['nullable' => false],
					'Store'
				)
				->addColumn(
					'host_name',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					255,
					['nullable' => false],
					'Host Name'
				)
				->addColumn(
					'return_url',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					255,
					['nullable' => false],
					'Return Url'
				)
				->addColumn(
					'token',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					255,
					['nullable' => false],
					'Token'
				)
				->addColumn(
					'is_active',
					\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					2,
					['nullable' => false],
					'Active'
				)
				->addColumn(
					'createddate',
					\Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
					null,
					['nullable' => false],
					'Create Date'
				)
				->addColumn(
					'updatedate',
					\Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
					null,
					[
						'nullable' => false,
						'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT,
					],
					'Modified Date'
				)
                ->setComment('Unilab Webservice Token')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
			$installer->getConnection()->createTable($table);
		}
		// End Unilab Token Table
		// Unilab Webservice logs Table
		if (!$installer->tableExists('unilab_webservice_logs')) {
			$table = $installer->getConnection()->newTable(
				$installer->getTable('unilab_webservice_logs')
			)
				->addColumn(
					'id',
					\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					11,
					[
						'auto_increment' => true,
                        'nullable' => false,
                        'primary' => true,
					],
					'ID'
				)
				->addColumn(
					'store',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					50,
					['nullable' => false],
					'Store'
				)
				->addColumn(
					'data_posted',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					'500M',
					['nullable' => true],
					'Data Posted Json'
				)
				->addColumn(
					'host_name',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					'500M',
					['nullable' => true],
					'Host Name'
				)
				->addColumn(
					'command_event',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					128,
					['nullable' => true],
					'Command Webservice Event'
				)
				->addColumn(
					'token_used',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					128,
					['nullable' => true],
					'Token'
				)
				
				->addColumn(
					'date_created',
					\Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
					null,
					['nullable' => true],
					'Create Date'
				)
				->addColumn(
					'date_updated',
					\Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
					null,
					[
						'nullable' => false,
						'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT,
					],
					'Modified Date'
				)
                ->setComment('Unilab Webservice Logs')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
			$installer->getConnection()->createTable($table);
		}
		// End Unilab Webservice logs Table
		// Unilab Netsuite logs Table
		if (!$installer->tableExists('unilab_logs_netsuite')) {
			$table = $installer->getConnection()->newTable(
				$installer->getTable('unilab_logs_netsuite')
			)
				->addColumn(
					'id',
					\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					11,
					[
						'auto_increment' => true,
                        'nullable' => false,
                        'primary' => true,
					],
					'ID'
				)
				->addColumn(
					'data_from',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					50,
					['nullable' => false],
					'Data From'
				)
				->addColumn(
					'transaction_id',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					50,
					['nullable' => false],
					'Transaction ID'
				)
				->addColumn(
					'cmdEvent',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					50,
					['nullable' => false],
					'Command Event'
				)
				->addColumn(
					'status',
					\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					5,
					['nullable' => false],
					'Status'
				)
				->addColumn(
					'logs',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					'500M',
					['nullable' => false],
					'Logs'
				)
				
				->addColumn(
					'date',
					\Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
					null,
					['nullable' => false],
					'Date'
				)
				->addColumn(
					'type',
					\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					50,
					['nullable' => false],
					'Type'
				)
                ->setComment('Unilab Netsuite Logs')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
			$installer->getConnection()->createTable($table);
		}
		// End Unilab Netsuite logs Table
		$installer->endSetup();
	}
}