<?php

namespace Unilab\Webservice\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Upgrades DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        //customer_entity
        $customer_entityTable = 'customer_entity';

        $setup->getConnection()
            ->addColumn(
                $setup->getTable($customer_entityTable),
                'is_sentto_ns',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                    'length' =>'1',
                    'default' => 0,
                    'nullable' => true,
                    'comment' =>'Sent to Netsuite',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($customer_entityTable),
                'sentto_ns_date',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                    'default' => null,
                    'nullable' => true,
                    'comment' =>'Sent to Netsuite Date',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($customer_entityTable),
                'update_sentto_ns',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                    'length' =>'1',
                    'default' => 0,
                    'nullable' => true,
                    'comment' =>'Update Sent to Netsuite',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($customer_entityTable),
                'update_sentto_ns_date',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                    'default' => null,
                    'nullable' => true,
                    'comment' =>'Update Sent to Netsuite Date',
                ]
            );
        //end customer_entity
        //sales_order
        $sales_orderTable = 'sales_order';

        $setup->getConnection()
            ->addColumn(
                $setup->getTable($sales_orderTable),
                'is_sentto_ns',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                    'length' =>'1',
                    'default' => 0,
                    'nullable' => true,
                    'comment' =>'Sent to Netsuite',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($sales_orderTable),
                'sentto_ns_date',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                    'default' => null,
                    'nullable' => true,
                    'comment' =>'Sent to Netsuite Date',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($sales_orderTable),
                'update_sentto_ns',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                    'length' =>'1',
                    'default' => 0,
                    'nullable' => true,
                    'comment' =>'Update Sent to Netsuite',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($sales_orderTable),
                'update_sentto_ns_date',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                    'default' => null,
                    'nullable' => true,
                    'comment' =>'Update Sent to Netsuite Date',
                ]
            );

        // end sales_order
        //customer_address_entity
        $customer_address_entityTable = 'customer_address_entity';

        $setup->getConnection()
            ->addColumn(
                $setup->getTable($customer_address_entityTable),
                'is_sentto_ns',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                    'length' =>'1',
                    'default' => 0,
                    'nullable' => true,
                    'comment' =>'Sent to Netsuite',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($customer_address_entityTable),
                'sentto_ns_date',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                    'default' => null,
                    'nullable' => true,
                    'comment' =>'Sent to Netsuite Date',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($customer_address_entityTable),
                'update_sentto_ns',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                    'length' =>'1',
                    'default' => 0,
                    'nullable' => true,
                    'comment' =>'Update Sent to Netsuite',
                ]
            );
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($customer_address_entityTable),
                'update_sentto_ns_date',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                    'default' => null,
                    'nullable' => true,
                    'comment' =>'Update Sent to Netsuite Date',
                ]
            );

        // end customer_address_entity

         //client address
         $rra_company_branchesTable = 'rra_company_branches';
         $setup->getConnection()
            ->addColumn(
                $setup->getTable($rra_company_branchesTable),
                'netsuite_id',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'default' => null,
                    'nullable' => true,
                    'comment' =>'Update Netsuite ID',
                ]
            );
        //end client address
        
        //employee benefit
        $rra_emp_benefitsTable = 'rra_emp_benefits';
        $setup->getConnection()
           ->addColumn(
               $setup->getTable($rra_emp_benefitsTable),
               'netsuite_id',
               [
                   'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                   'default' => null,
                   'nullable' => true,
                   'comment' =>'Update Netsuite ID',
               ]
           );
       //end employee benefit
       //pricelist
       $catalogruleTable = 'catalogrule';
       $setup->getConnection()
          ->addColumn(
              $setup->getTable($catalogruleTable),
              'netsuite_id',
              [
                  'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                  'default' => null,
                  'nullable' => true,
                  'comment' =>'Update Netsuite ID',
              ]
          );
      //end pricelist    
       //product pricelist
       $rra_pricelistproductTable = 'rra_pricelistproduct';
       $setup->getConnection()
          ->addColumn(
              $setup->getTable($rra_pricelistproductTable),
              'netsuite_id',
              [
                  'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                  'default' => null,
                  'nullable' => true,
                  'comment' =>'Update Netsuite ID',
              ]
          );
      //end product pricelist
      //customer group
      $customer_groupTable = 'customer_group';
      $setup->getConnection()
         ->addColumn(
             $setup->getTable($customer_groupTable),
             'netsuite_id',
             [
                 'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                 'default' => null,
                 'nullable' => true,
                 'comment' =>'Update Netsuite ID',
             ]
         );
      //end customer group

        $setup->endSetup();
        
    }
}
