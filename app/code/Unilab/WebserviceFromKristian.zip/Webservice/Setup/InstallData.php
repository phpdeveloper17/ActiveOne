<?php
namespace Unilab\Webservice\Setup;


use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\Set as AttributeSet;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
// use Magento\Framework\Module\Setup\Migration;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;



class InstallData implements InstallDataInterface
{
    /**
     * Customer setup factory
     *
     * @var \Magento\Customer\Setup\CustomerSetupFactory
     */
    private $customerSetupFactory;
    private $attributeSetFactory;
    private $eavSetupFactory;
    protected $resourceConnection;

    /**
     * Init
     *
     * @param \Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory
     */
    public function __construct(CustomerSetupFactory $customerSetupFactory,EavSetupFactory $eavSetupFactory,AttributeSetFactory $attributeSetFactory,\Magento\Framework\App\ResourceConnection $resourceConnection)
    {
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
        $this->eavSetupFactory = $eavSetupFactory;
        $this->resourceConnection = $resourceConnection;
    }
    /**
     * Installs DB schema for a module
     *
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {


        $installer = $setup;
        $installer->startSetup();

        $insertArray = array(
            'netsuite_id' => array(
                "type" => "int",
                "label" => "Netsuite ID",
                "input" => "text",
                "sort_order" => 1010,
                "position" => 1010
            ),
        );
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        foreach ($insertArray as $key => $data) {

            //$eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            // $eavSetup->removeAttribute(Customer::ENTITY, $key);

            $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

            $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
            $attributeSetId = $customerEntity->getDefaultAttributeSetId();

            /** @var $attributeSet AttributeSet */
            $attributeSet = $this->attributeSetFactory->create();
            $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

            $addAttr = array(
                'type' => $data['type'],
                'label' => $data['label'],
                'input' => $data['input'],
                'required' => false,
                'visible' => true,
                'user_defined' => true,
                'sort_order' => $data['sort_order'],
                'position' => $data['position'],
                'system' => 0
            );

            $customerSetup->addAttribute(Customer::ENTITY, $key, $addAttr);

            $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, $key)
            ->addData([
                'attribute_set_id' => $attributeSetId,
                'attribute_group_id' => $attributeGroupId,
                'used_in_forms' => ['adminhtml_customer'],
                'is_used_in_grid' => 1,
                'is_visible_in_grid' => 1,
                'is_filterable_in_grid' => 1,
                'is_searchable_in_grid' => 1,

            ]);

            $attribute->save();
        }
        $eavSetup->addAttribute(
                    \Magento\Catalog\Model\Product::ENTITY,
                'netsuite_id',
                [
                    'type' => 'int',
                    'label' => 'Netsuite ID',
                    'input' => 'text',
                    'required' => false,
                    'visible' => true,
                    'user_defined' => true,
                    'sort_order' => 1010,
                    'position' => 1010,
                    'system' => 0

                    // 'group' => 'General',
                    // 'type' => 'int',
                    // 'label' => 'Netsuite ID',
                    // 'backend' => '',
                    // 'input' => 'select',
                    // 'wysiwyg_enabled'   => false,
                    // 'source' => 'Namespace\ModuleName\Model\Config\Source\YesNo',
                    // 'required' => true,
                    // 'sort_order' => 15,
                    // 'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                    // 'used_in_product_listing' => false,
                    // 'visible_on_front' => false,
            ]
        );
        


        $installer->endSetup();
    }
}
