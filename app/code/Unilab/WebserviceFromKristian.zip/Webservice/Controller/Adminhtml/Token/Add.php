<?php

namespace Unilab\Webservice\Controller\Adminhtml\Token;

use Magento\Framework\Controller\ResultFactory;

class Add extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * @var \Unilab\Grid\Model\TokenFactory
     */
    private $tokenFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry,
     * @param \Unilab\City\Model\tokenFactory $orderstatusFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Unilab\Webservice\Model\TokenFactory $tokenFactory
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->tokenFactory = $tokenFactory;
    }

    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $token_data = $this->tokenFactory->create();
        $this->coreRegistry->register('token_data', $token_data);
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $title = __('Add New Token');
        $resultPage->getConfig()->getTitle()->prepend($title);
        return $resultPage;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Unilab_Webservice::add_token');
    }
}
