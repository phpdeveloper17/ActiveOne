<?php
namespace Unilab\Webservice\Controller\Adminhtml\Token;

class Save extends \Magento\Backend\App\Action
{
    
    var $tokenFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Unilab\Webservice\Model\TokenFactory $tokenFactory
    ) {
        parent::__construct($context);
        $this->tokenFactory = $tokenFactory;
        
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        
        if (!$data) {
            $this->_redirect('manage_webservice/webservice/addtoken');
            return;
        }
        try {
            $date       = date("Y-m-d H:i:s A");		
            $tokenData  = $this->tokenFactory->create();

            $tokenData->setData($data);


            if (isset($data['id'])) {
                $tokenData->setEntityId($data['id']);
                $tokenData->setUpdatedate($date);

              
            }else{
                $salt	    = md5($date);
                $token 	    = base64_encode($salt .':'.$data['host_name']);

                $tokenData->setUpdatedate($date);
                $tokenData->setCreateddate($date);
                $tokenData->setToken($token);
             
            }
            $tokenData->save();
            $this->messageManager->addSuccess(__('Token has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('manage_webservice/token/token');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Unilab_Webservice:save');
    }
}
