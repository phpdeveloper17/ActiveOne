<?php
namespace Unilab\Webservice\Controller\Adminhtml\Token;

use Magento\Framework\Controller\ResultFactory;

class Edit extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * @var \Unilab\Grid\Model\TokenFactory
     */
    private $tokenFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry,
     * @param \Unilab\City\Model\tokenFactory $tokenFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Unilab\Webservice\Model\TokenFactory $tokenFactory
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->tokenFactory = $tokenFactory;
    }

    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $tokenId = (int) $this->getRequest()->getParam('id');
        $token_data = $this->tokenFactory->create();
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        if ($tokenId) {
            $tokenData = $token_data->load($tokenId); 
            if (!$tokenData->getId()) {
                $this->messageManager->addError(__('Token no longer exist.'));
                $this->_redirect('manage_webservice/token/token');
                return;
            }
        }

        $this->coreRegistry->register('token_data', $tokenData);
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $title = __('Edit API Token Information');
        $resultPage->getConfig()->getTitle()->prepend($title);
        return $resultPage;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Unilab_Webservice::edit_token');
    }
}
