<?php
namespace Unilab\Webservice\Controller\Adminhtml\Cronjobs;

class SendCustomers extends \Magento\Backend\App\Action
{
    protected $cronJobs;
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Unilab\Webservice\Model\Netsuite\Postdata\CronjobsFactory $cronjobsFactory
    ) {
        parent::__construct($context);
        $this->cronjobs=$cronjobsFactory;
    }

    public function execute()
    {
        try{
            $this->_cronjobs = $this->cronjobs->create();
            $response = $this->_cronjobs->sendCustomer();
            $this->createVarlogs('SendCustomersCronJob.log', $response);
        }catch(\Exception $e){
            $this->createVarlogs('SendCustomersCronJob.log', $e->getMessage());
        }
        $this->_redirect('customer/index');
    }
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
  
}
