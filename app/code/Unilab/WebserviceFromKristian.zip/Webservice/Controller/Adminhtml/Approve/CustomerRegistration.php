<?php
namespace Unilab\Webservice\Controller\Adminhtml\Approve;

class CustomerRegistration extends \Magento\Backend\App\Action
{
    private $transportBuilder;
    private $inlineTranslation;
    protected $_storeManager;
    protected $customerResourceFactory;
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\ResourceModel\CustomerFactory $customerResourceFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Unilab\Webservice\Model\Netsuite\Postdata\CustomerFactory $customerPostData
    ) {
        parent::__construct($context);
        $this->_storeManager=$storeManager;
        $this->_customer=$customer;
        $this->scopeConfig = $scopeConfig;
        $this->customerPostData = $customerPostData;
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->customerResourceFactory = $customerResourceFactory;
    }

    public function execute()
    {
        
        try{
            $this->_customerPostData = $this->customerPostData->create();

            $StoreId = $this->_storeManager->getStore()->getId();
            $id 		  = $this->getRequest()->getParam('id');
            $customer 		= $this->_customer->load($id);
           	
            $needs_approval = $customer->getNeedsApproval();
            $name 			= $customer->getName();
            $email 			= $customer->getEmail();
			
            if($needs_approval == 122){
                $customerData = $customer->getDataModel();
               
                $customerData->setCustomAttribute('needs_approval', 123);
                $customer->updateData($customerData);

                $customerResource = $this->customerResourceFactory->create();
                $customerResource->saveAttribute($customer, 'needs_approval');
				
                $this->sendNewAccountEmailproxy($name, $email); //
                $storeidapi         = $this->_storeManager->getStore()->getStoreId();
                $netsuiteApiEnabled = $this->scopeConfig->getValue('webservice/netsuiteregsettings/netsuiteregenabled', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

                $logs['netsuiteApiEnabled'] = $netsuiteApiEnabled;
                $logs['storeidapi']     = $storeidapi;
                // $this->createVarlogs('approvecustomerregistrationAction.log',$logs);
                if($netsuiteApiEnabled == 1 ){
                    $this->_customerPostData->sendCustomer($id, $StoreId);
                }
                $this->messageManager->addSuccess('Customer was successfully approved');
            }else{
                $this->messageManager->addWarning('Customer was already approved');
            }
        
        }catch(\Exception $e){
            $this->messageManager->addError($e->getMessage());
        }
        $this->_redirect('customer/index');
    }
    public function sendNewAccountEmailproxy($name, $email){
        $storeId = $this->_storeManager->getStore()->getStoreId();
        $password   = $this->scopeConfig->getValue('customerapproval/customerapprovalsettings/defaultpassword');
        $baseurl = $this->_storeManager->getStore()->getBaseUrl();
        $template_id = 111; //Unilab - New Account (Approved)

        $templateOptions = [
            'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
            'store' => $this->_storeManager->getStore()->getId()
        ];
        
        $templateVars = [
            'email' => $email,
            'name' => $name,
            'password'    => $password,
            'baseurl'    => $baseurl
        ];
        
        $sender_name = 'Clickhealth';
        $from = ['email' => $this->scopeConfig->getValue('trans_email/ident_general/email'), 'name' => $sender_name];
        
        $this->inlineTranslation->suspend();

        $transport = $this->transportBuilder->setTemplateIdentifier($template_id)
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($email)
                ->getTransport();

        $transport->sendMessage();

        $this->inlineTranslation->resume();
        
    }
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
  
}
