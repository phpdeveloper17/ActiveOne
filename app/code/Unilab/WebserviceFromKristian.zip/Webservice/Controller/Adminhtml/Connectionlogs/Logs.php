<?php
/**
 * Webservice Token Controller.
 * @category  Unilab
 * @package   Unilab_Webservice
 * @author    Ron Mark Peroso Rudas   
 */
namespace Unilab\Webservice\Controller\Adminhtml\Connectionlogs;

class Logs extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $resultPageFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Unilab_Webservice::Webservice_Connectionlogs');
        $resultPage->getConfig()->getTitle()->prepend(__('Manage Connection Logs'));
        return $resultPage;
    }

    /**
     * Check Order Import Permission.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Unilab_Webservice::Webservice_Connectionlogs');
    }
}
