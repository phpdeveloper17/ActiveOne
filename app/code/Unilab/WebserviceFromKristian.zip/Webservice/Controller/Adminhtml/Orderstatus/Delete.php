<?php
namespace Unilab\Webservice\Controller\Adminhtml\Orderstatus;
use Magento\Backend\App\Action;

class Delete extends \Magento\Backend\App\Action
{

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Unilab\Webservice\Model\OrderStatusFactory $OrderStatusFactory
    ) {
        parent::__construct($context);
        $this->OrderStatusFactory = $OrderStatusFactory;
        
    }
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');

        if (!($orderstatus = $this->OrderStatusFactory->create()->load($id))) {
            $this->messageManager->addError(__('Unable to proceed. Please, try again.'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/orderstatus/status', array('_current' => true));
        }
        try{
            $orderstatus->delete();
            $this->messageManager->addSuccess(__('Your order status has been deleted !'));
        } catch (Exception $e) {
            $this->messageManager->addError(__('Error while trying to delete order status: '));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/orderstatus/status', array('_current' => true));
        }

        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/orderstatus/status', array('_current' => true));
    }
}