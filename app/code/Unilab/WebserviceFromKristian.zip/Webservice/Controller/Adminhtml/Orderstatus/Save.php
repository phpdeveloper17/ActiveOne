<?php
/**
 * @category  Unilab
 * @package   Unilab_City
 * @author    Ron Mark Peroso Rudas   
 */
namespace Unilab\Webservice\Controller\Adminhtml\Orderstatus;

class Save extends \Magento\Backend\App\Action
{
    
    var $tokenFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Unilab\Webservice\Model\OrderStatusFactory $OrderStatusFactory
    ) {
        parent::__construct($context);
        $this->OrderStatusFactory = $OrderStatusFactory;
        
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();

        if (!$data) {
            $this->_redirect('manage_webservice/orderstatus/add');
            return;
        }
        try {
            $date       = date("Y/m/d H:i:s A");		
            $orderStatusData  = $this->OrderStatusFactory->create();

            $orderStatusData->setData($data);


            if (isset($data['id'])) {
                $orderStatusData->setId($data['id']);
                $orderStatusData->setDateUpdated($date);

            }else{
                // $salt	    = md5($date);
                // $token 	    = base64_encode($salt .':'.$data['host_name']);

                $orderStatusData->setDateUpdated($date);
                $orderStatusData->setDateCreated($date);
                // $tokenData->setToken($token);

            }

            $orderStatusData->save();
            $this->messageManager->addSuccess(__('Order Status has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('manage_webservice/orderstatus/status');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Unilab_Webservice:Order Status Save');
    }
}
