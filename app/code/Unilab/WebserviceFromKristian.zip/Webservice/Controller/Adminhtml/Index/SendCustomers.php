<?php
namespace Unilab\Webservice\Controller\Adminhtml\Index;

class SendCustomers extends \Magento\Backend\App\Action
{
    protected $customerPostData;
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Unilab\Webservice\Model\Postdata\CustomerFactory $customerFactory
    ) {
        parent::__construct($context);
        $this->customerPostData=$customerFactory;
    }

    public function execute()
    {
        try{
            $this->_customerPostData = $this->customerPostData->create();
            $response = $this->_customerPostData->autosendCustomers();
            
            $msg = $response['message'];
            $this->messageManager->addSuccess($msg);
            $this->createVarlogs('indexSendCustomers.log', $response);
        }catch(\Exception $e){
            $this->createVarlogs('indexSendCustomers.log', $e->getMessage());
        }
        // $this->_redirect('adminhtml/customer/index');
    }
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
  
}
