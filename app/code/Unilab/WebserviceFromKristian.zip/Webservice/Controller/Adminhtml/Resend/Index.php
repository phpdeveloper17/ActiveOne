<?php
namespace Unilab\Webservice\Controller\Adminhtml\Resend;

class Index extends \Magento\Backend\App\Action
{
    protected $salesorder;
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Unilab\Webservice\Model\Postdata\SalesorderFactory $salesorderFactory
    ) {
        parent::__construct($context);
        $this->salesorder=$salesorderFactory;
    }

    public function execute()
    {
        try{
            $this->_salesorder = $this->salesorder->create();
            $response = $this->_salesorder->sendorder($_POST['increment_id']);
            if($response['success'] == true){
                $this->messageManager->addSuccess('Your Order was Successfully Sent');
            }else{
                if(empty($response['message'])){
                    $this->messageManager->addError("Error while sending your Order");			
                }else{
                    $this->messageManager->addError($response['message']);	
                }
            }
            $this->createVarlogs('resendIndex.log', $response);
        }catch(\Exception $e){
            $this->createVarlogs('resendIndex.log', $e->getMessage());
        }
        $this->_redirect('admin/sales/order/view', array('order_id'=>$_POST['order_id'],'key'=>$this->getRequest()->getParam('key')));
    }
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
  
}
