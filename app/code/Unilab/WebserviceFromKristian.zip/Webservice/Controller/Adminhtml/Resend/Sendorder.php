<?php
namespace Unilab\Webservice\Controller\Adminhtml\Resend;

class Sendorder extends \Magento\Backend\App\Action
{
    protected $orderPostdata;
    protected $_storeManager;
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Unilab\Webservice\Model\Netsuite\Postdata\OrderFactory $orderFactory
    ) {
        parent::__construct($context);
        $this->orderPostdata=$orderFactory;
        $this->_storeManager=$storeManager;
    }

    public function execute()
    {
        try{
            $StoreId = $this->_storeManager->getStore()->getStoreId();
            $order_id	= $this->getRequest()->getParam('order_id');

            $this->_orderPostdata = $this->orderPostdata->create();

            $response = $this->_orderPostdata->createOrder($order_id,$StoreId);
            if($response['success']  == 1)
			{
				$msg = "Order was successfully sent";
			}else{
				$msg = $response['message'] ;
            }
            $this->messageManager->addSuccess($msg);
            $this->createVarlogs('resendOrder.log', $response);
        }catch(\Exception $e){
            $this->createVarlogs('resendOrder.log', $e->getMessage());
        }
       $this->_redirect('sales/order/index');
    }
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
  
}
