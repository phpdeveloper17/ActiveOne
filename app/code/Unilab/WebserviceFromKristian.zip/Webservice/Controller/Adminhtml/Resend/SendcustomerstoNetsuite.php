<?php
namespace Unilab\Webservice\Controller\Adminhtml\Resend;

class SendcustomerstoNetsuite extends \Magento\Backend\App\Action
{
    protected $customerPostdata;
    protected $_storeManager;
    protected $_resource;
    
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\ResourceConnection $resource,
        \Unilab\Webservice\Model\Netsuite\Postdata\CustomerFactory $customerFactory
    ) {
        parent::__construct($context);
        $this->customerPostdata=$customerFactory;
        $this->_storeManager=$storeManager;
        $this->_resource 		= $resource;
    }

    public function execute()
    {
        try{
            $this->_customerPostdata = $this->customerPostdata->create();

            $StoreId = $this->_storeManager->getStore()->getStoreId();
            $id 		  = $this->getRequest()->getParam('id');
            $read = $this->_resource->getConnection('core_write');

            $addressCount = $read->fetchAll("SELECT count(*) FROM customer_address_entity WHERE parent_id = $id"); 

            if($addressCount > 0)
            {
                $response = $this->_customerPostdata->sendCustomer($id,$StoreId);
            }else{
                $response = $this->_customerPostdata->sendCustomerWithoutAddress($id,$StoreId);
            }
            if($response['success']  == 1)
			{
				$msg = "Customer was successfully sent";
			}else{
				$msg = $response['message'] ;
            }
            $this->messageManager->addSuccess($msg);
            $this->createVarlogs('resendSendcustomerstoNetsuite.log', $response);
        }catch(\Exception $e){
            $this->createVarlogs('resendSendcustomerstoNetsuite.log', $e->getMessage());
        }
        $this->_redirect('admin/sales/order/index');
    }
    protected function createVarlogs($filename, $logs){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($logs);
    }
  
}
