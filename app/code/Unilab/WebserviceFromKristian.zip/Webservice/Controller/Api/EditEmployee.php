<?php
namespace Unilab\Webservice\Controller\Api;
use Magento\Framework\App\RequestInterface;

class EditEmployee extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	protected $postDataeEmployee;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Unilab\Webservice\Model\Netsuite\Postdata\Employee $postDataEmployee
		)
	{
		$this->postDataEmployee = $postDataEmployee;
		return parent::__construct($context);
	}

	public function execute()
	{
		$employeeId = 52;
		$storeId = 1;
		$res = $this->postDataEmployee->updateEmployee($employeeId, $storeId);
		echo "<pre>";
			print_r($res);
		echo "</pre>";
	}

}
