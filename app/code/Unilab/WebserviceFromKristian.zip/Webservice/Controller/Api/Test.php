<?php
namespace Unilab\Webservice\Controller\Api;
use Magento\Framework\App\RequestInterface;

class Test extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	protected $postDataTestmodel;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Unilab\Webservice\Model\Netsuite\Postdata\Testmodel $postDataTestmodel
		)
	{
		$this->postDataTestmodel = $postDataTestmodel;
		return parent::__construct($context);
	}

	public function execute()
	{
		echo $this->postDataTestmodel->testSample();	
	}

}
