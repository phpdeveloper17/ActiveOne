<?php
namespace Unilab\Webservice\Controller\Api;
use Magento\Framework\App\RequestInterface;

class CreateSalesOrder extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	protected $postDataOrder;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Unilab\Webservice\Model\Netsuite\Postdata\Order $postDataOrder
		)
	{
		$this->postDataOrder = $postDataOrder;
		return parent::__construct($context);
	}

	public function execute()
	{
		$orderId = 390;
		$storeId = 1;
		$res = $this->postDataOrder->createOrder($orderId, $storeId);
		echo "<pre>";
			print_r($res);
		echo "</pre>";
	}

}
