<?php
namespace Unilab\Webservice\Controller\Api;

class Netsuite extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	protected $_postFactory;

	protected $employeeFactory;

	protected $customerGroupFactory;

	protected $pricelistFactory;

	protected $benefitFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\HTTP\Client\Curl $curl,
		\Magento\Framework\App\RequestInterface $request,
		\Magento\Framework\Json\Helper\Data $jsonHelper,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Unilab\Webservice\Helper\Events $eventsHelper,
		\Unilab\Webservice\Model\TokenFactory $TokenFactory,
		\Unilab\Webservice\Model\ApiFactory $ApiFactory,
		\Unilab\Webservice\Model\Netsuite\OrderStatusFactory $OrderstatusFactory,
		\Unilab\Webservice\Model\Netsuite\ProductFactory $ProductFactory,
		\Unilab\Webservice\Model\Netsuite\CategoryFactory $CategoryFactory,
		\Unilab\Webservice\Model\Netsuite\MaintenanceFactory $MaintenanceFactory,
		\Unilab\Webservice\Model\Netsuite\EmployeeFactory $employeeFactory,
		\Unilab\Webservice\Model\Netsuite\CustomerGroupFactory $customerGroupFactory,
		\Unilab\Webservice\Model\Netsuite\PricelistFactory $pricelistFactory,
		\Unilab\Webservice\Model\Netsuite\BenefitsFactory $benefitFactory
		)
	{
		$this->_curl 					= $curl;
		$this->_pageFactory 			= $pageFactory;
		$this->request 					= $request;
		$this->jsonHelper 				= $jsonHelper;
		$this->resultJsonFactory    	= $resultJsonFactory;
		$this->_ApiFactory				= $ApiFactory;
		$this->eventsHelper				= $eventsHelper;
		$this->orderStatus				= $OrderstatusFactory;
		$this->product					= $ProductFactory;
		$this->category					= $CategoryFactory;
		$this->maintenance				= $MaintenanceFactory;
		$this->employeeFactory          = $employeeFactory;
		$this->customerGroupFactory     = $customerGroupFactory;
		$this->pricelistFactory         = $pricelistFactory;
		$this->benefitFactory  			= $benefitFactory;

		return parent::__construct($context);
	}

	public function execute()
	{
	
		$this->_result  				= $this->resultJsonFactory->create();
		$this->_api 					= $this->_ApiFactory->create();
		$this->_orderStatus 			= $this->orderStatus->create();
		$this->_product 				= $this->product->create();
		$this->_category 				= $this->category->create();
		$this->_maintenance 			= $this->maintenance->create();
		$this->_employee                = $this->employeeFactory->create();
		$this->_customerGroup   		= $this->customerGroupFactory->create();
		$this->_pricelist               = $this->pricelistFactory->create();
		$this->_benefit 				= $this->benefitFactory->create();
		
	//	$this->_api->testToken();
		$post = $this->request->getContent();
						
		$_POST = $this->jsonHelper->jsonDecode($post);
		
		if(isset($_POST['token'])) {

			$this->_api->validateToken();
			
			if(isset($_POST['cmdEvent'])) {
				
				try{
					//$post			= $this->request->getContent();
					
					//$_POST 			= $this->jsonHelper->jsonDecode($post);
		
				
					if($_POST['cmdEvent'] == $this->eventsHelper::PROCESS_ORDER){
						$response = $this->_orderStatus->updateToProcessing($_POST);	
					}elseif($_POST['cmdEvent'] == $this->eventsHelper::COMPLETE_ORDER){
						$response = $this->_orderStatus->updateToComplete($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::CANCEL_ORDER){
						$response = $this->_orderStatus->updateToCancel($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::CREATE_EMPLOYEE){
						$response = $this->_employee->createEmployee($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_EMPLOYEE){
						$response = $this->_employee->updateEmployee($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::CREATE_EMPLOYEE_BENEFIT){
						$response = $this->_benefit->create($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_EMPLOYEE_BENEFIT){
						$response = $this->_benefit->update($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::CREATE_CUSTOMER){
						$response = $this->_customerGroup->create($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_CUSTOMER){
						$response = $this->_customerGroup->update($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::CREATE_CUSTOMER_ADDRESS){
						$response = $this->_employee->createAddress($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_CUSTOMER_ADDRESS){
						$response = $this->_employee->updateAddress($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::CREATE_PRICELIST){
						$response = $this->_pricelist->create($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_PRICELIST){
						$response = $this->_pricelist->update($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::CREATE_PRODUCT){
						$response = $this->_product->create($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_PRODUCT){
						$response = $this->_product->update($_POST);
					}
					/**Test Jordan */
					elseif($_POST['cmdEvent'] == $this->eventsHelper::CREATE_PRODUCT_PRICE_LIST){
						$response = $this->_pricelist->createProductPriceList($_POST);
					}/**Test Jordan */
					elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_PRODUCT_PRICE_LIST){
						$response = $this->_pricelist->updateProductPriceList($_POST);
					}
		
					/** TEST EVENTS */
					elseif($_POST['cmdEvent'] == $this->eventsHelper::TEST_BENEFITS){
						$response = $this->_benefit->testBenefits($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::TEST_EMPLOYEE){
						$response = $this->_benefit->testEmployee($_POST);
					}
					elseif($_POST['cmdEvent'] == $this->eventsHelper::TEST_PRODUCT){
						$response = $this->_product->testProduct($_POST);
					}
					else{
						$response['ErrHndler'] 	= "Function ". $_POST['cmdEvent'] ." does not exist!";
						$response['success'] 	= 0;	
					}
					
				}catch(\Exeption $e){
					
					$response['ErrHndler'] 	= $e->getMessage();
					$response['success'] 	= 0;			
				} 

			} else {
				
				$response['code'] 		= 0;
				$response['ErrHndler'] 	= "Missing 'cmdEvent' parameter";
			}

		}	
		else {
			
			$response['ErrHndler']	= "Missing token parameter";
			$response['code'] 		= 0;
		}

		

		// $this->createlogs($response);	
		return $this->_result->setData($this->jsonHelper->jsonEncode($response));	
	}

}