<?php
namespace Unilab\Webservice\Controller\Api;
use Magento\Framework\App\RequestInterface;

class Test extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	protected $_postFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Unilab\Webservice\Model\TokenFactory $TestFactory,
		RequestInterface $request,
		\Magento\Framework\Json\Helper\Data $jsonHelper
		


		)
	{
		header("Access-Control-Allow-Origin: *");
		header("Access-Control-Allow-Headers: origin, x-requested-with, content-type");
		header("Access-Control-Allow-Methods: PUT, GET, POST");
		//"PUT, GET, POST, DELETE, OPTIONS"	

		$this->_pageFactory = $pageFactory;
		$this->_testFactory = $TestFactory;
		$this->request = $request;
		$this->jsonHelper = $jsonHelper;

		return parent::__construct($context);
	}

	public function execute()
	{
		$post= $this->request->getContent();
		$p =$this->jsonHelper->jsonDecode($post);
    //    $post;
        print_r($p['data']);
        // print_r($data);
        die();
		// $_testFactory = $this->_testFactory->create()->getCollection();
		// /** Apply filters here */
		// //  $test = $_testFactory->addFieldToFilter('token');
		// $test = $_testFactory->addFieldToFilter('token', 'NTI2YmFiNGQ5ODMxMDdjOThjYzBiYjY2M2UxNWE1NGM6bG9jYWxob3N0');
		// // Don't have to do this
		// // $productCollection->load();
		// echo "<pre>";
		// $_testFactory->load();

		// print_r($_testFactory->getSize());die();

		// foreach ($_testFactory as $test){
		// 	// print_r($test->getData());die();
		// 	 echo 'Token  =  '.$test->getToken().'<br>';
		// }  
		
	}
	
}