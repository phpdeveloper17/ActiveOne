<?php
namespace Unilab\Webservice\Controller\Api;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	protected $_postFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\HTTP\Client\Curl $curl,
		\Unilab\Webservice\Model\TokenFactory $TokenFactory,
		\Unilab\Webservice\Model\ApiFactory $ApiFactory,
		\Unilab\Webservice\Model\Order\ChangestatusFactory $ChangestatusFactory,
		\Magento\Framework\App\RequestInterface $request,
		\Magento\Framework\Json\Helper\Data $jsonHelper,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Unilab\Webservice\Model\Product\ProductFactory $ProductFactory,
		\Unilab\Webservice\Helper\Events $eventsHelper,
		\Unilab\Webservice\Model\Company\CompanyFactory $CompanyFactory,
		\Unilab\Webservice\Model\Company\Address\CompAddressFactory $CompAddressFactory,
		\Unilab\Webservice\Model\Price\PricelevelFactory $PricelevelFactory,
		\Unilab\Webservice\Model\Price\ProductPricelistFactory $ProductPricelistFactory,
		\Unilab\Webservice\Model\Order\SendToSapFactory $SendToSapFactory,
		\Unilab\Webservice\Model\Price\PricelistFactory $PricelistFactory
		)
	{
		$this->_curl 					= $curl;
		$this->_pageFactory 			= $pageFactory;
		$this->request 					= $request;
		$this->jsonHelper 				= $jsonHelper;
		$this->resultJsonFactory    	= $resultJsonFactory;
		$this->_ApiFactory				= $ApiFactory;
		$this->_ChangestatusFactory		= $ChangestatusFactory;
		$this->_productFactory			= $ProductFactory;
		$this->eventsHelper				= $eventsHelper;
		$this->companyFactory			= $CompanyFactory;
		$this->compAddressFactory		= $CompAddressFactory;
		$this->pricelevelFactory		= $PricelevelFactory;
		$this->productPricelistFactory	= $ProductPricelistFactory;
		$this->sendToSapFactory			= $SendToSapFactory;
		$this->pricelistFactory			= $PricelistFactory;

		return parent::__construct($context);
	}

	public function execute()
	{
		// echo "<pre>";
		// print_r($this->eventsHelper::ADD_NEW_COMPANY);
		// print_r($_POST);
		// echo "</pre>";
		// exit();
		$this->_result  				= $this->resultJsonFactory->create();
		$this->_api 					= $this->_ApiFactory->create();
		$this->_changestatus 			= $this->_ChangestatusFactory->create();
		$this->_productfactory		 	= $this->_productFactory->create();
		$this->_companyFactory		 	= $this->companyFactory->create();
		$this->_compAddressFactory		= $this->compAddressFactory->create();
		$this->_pricelevelFactory		= $this->pricelevelFactory->create();
		$this->_productPricelistFactory	= $this->productPricelistFactory->create();
		$this->_sendToSapFactory		= $this->sendToSapFactory->create();
		$this->_pricelistFactory		= $this->pricelistFactory->create();

		$this->_api->validateToken();
		
		try{
			$post			= $this->request->getContent();
			$_POST 			= $this->jsonHelper->jsonDecode($post);

			if($_POST['cmdEvent'] == $this->eventsHelper::ORDER_CHANGE_STATUS){
				$response = $this->_changestatus->processOrder($_POST);	
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_PRODUCT_PRICE){
				$response = $this->_productfactory->Updateproductsprice($_POST);
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::ADD_NEW_PRODUCT){
				$response = $this->_productfactory->Addnewproduct();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::DELETE_PRODUCT){
				$response = $this->_productfactory->deleteproducts();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::SHOW_PRODUCT){
				$response =  $this->_productfactory->showdata();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_PRODUCT){
				$response =  $this->_productfactory->Updateproducts();	 
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::INACTIVE_PRODUCT){
				$response =  $this->_productfactory->Inactive();	
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::ADD_NEW_COMPANY){ //DONE
				$response = $this->_companyFactory->Addcompany();		
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::DELETE_COMPANY){ //DONE
				$response = $this->_companyFactory->Deletecompany();	
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_COMPANY){ //DONE
				$response = $this->_companyFactory->Updatecompany();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::SHOW_COMPANY){ //DONE
				$response = $this->_companyFactory->showdata();		
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::ADD_NEW_COMPANY_ADDRESS){ // DONE
				$response = $this->_compAddressFactory->Addcompanyaddress();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_COMPANY_ADDRESS){ //DONE
				$response = $this->_compAddressFactory->Updatecompanyaddress();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::DELETE_COMPANY_ADDRESS){	//DONE
				$response = $this->_compAddressFactory->Deletecompanyaddress();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::SHOW_COMPANY_ADDRESS){	//DONE
				$response = $this->_compAddressFactory->showdata();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::ADD_NEW_PRICE_LEVEL){ //DONE		
				$response = $this->_pricelevelFactory->create();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_PRICE_LEVEL){	//DONE
				$response =  $this->_pricelevelFactory->update();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::DELETE_PRICE_LEVEL){	//DONE
				$response =  $this->_pricelevelFactory->delete();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::SHOW_PRICE_LEVEL){ //DONE
				$response =  $this->_pricelevelFactory->showdata();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::ADD_NEW_PRODUCT_PRICE_LIST){ //DONE
				$response = $this->_productPricelistFactory->create();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_PRODUCT_PRICE_LIST){ //DONE
				$response = $this->_productPricelistFactory->update();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::DELETE_PRODUCT_PRICE_LIST){ //DONE
				$response = $this->_productPricelistFactory->delete();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::SHOW_PRODUCT_PRICE_LIST){ //DONE
				$response = $this->_productPricelistFactory->showdata();	
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::ORDER_SEND_TOSAP){ //WTF
				$response = $this->_sendToSapFactory->send();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::ADD_NEW_PRICE_LIST){	//DONE
				$response = $this->_pricelistFactory->create();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::DELETE_PRICE_LIST){ //DONE
				$response = $this->_pricelistFactory->delete();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::UPDATE_PRICE_LIST){ //DONE
				$response = $this->_pricelistFactory->update();
			}elseif($_POST['cmdEvent'] == $this->eventsHelper::SHOW_PRICE_LIST){ //DONE
				$response = $this->_pricelistFactory->showdata();
			}else{
				$response['ErrHndler'] 	= "Function ". $_POST['cmdEvent'] ." Not Exist!";
				$response['success'] 	= false;	
			}
			
		}catch(\Exeption $e){
			
			$response['ErrHndler'] 	= $e->getMessage();
			$response['success'] 	= false;			
		}
		

		// $this->createlogs($response);	
		return $this->_result->setData($this->jsonHelper->jsonEncode($response));	
	}

}