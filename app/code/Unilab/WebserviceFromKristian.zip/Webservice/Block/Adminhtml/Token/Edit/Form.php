<?php
/**
 * @category  Unilab
 * @package   Unilab_Webservice
 * @author    Ron Mark Peroso Rudas   
 */
namespace Unilab\Webservice\Block\Adminhtml\Token\Edit;
 
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_storename;
    /**
     * @param \Magento\Backend\Block\Template\Context $context,
     * @param \Magento\Framework\Registry $registry,
     * @param \Magento\Framework\Data\FormFactory $formFactory,
     * @param \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
     * @param \Unilab\Webservice\Model\Status $options,
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory, 
        \Unilab\Webservice\Model\Status $options,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        array $data = []
    ) {
        $this->_options = $options;
        $this->resourceConnection = $resourceConnection;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    public function getStoreName()
    {
        $connectdb = $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

        $readresult = $connectdb->query("SELECT * FROM store");
        $storename = array('Please select store');
        while ($items = $readresult->fetch() ) {
                $storename[] = array(
                                'value'     => $items['store_id'],
                                'label'      => __($items['name']),
                            );
        }   
        
        return $storename;
    }
    protected function _prepareForm()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    
        $dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        $model = $this->_coreRegistry->registry('token_data');

        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form',
                            'enctype' => 'multipart/form-data',
                            'action' => $this->getData('action'),
                            'method' => 'post'
                        ]
            ]
        );

        $form->setHtmlIdPrefix('token_');
        if ($model->getId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __(''), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __(''), 'class' => 'fieldset-wide']
            );
        }
        $fieldset->addField(
            'store', 'select', array(
                'label'              => __('Store Name'),
                'name'               => 'store',
                'class'             => 'required-entry',
                'required'          => false,
                'values'            => $this->getStoreName(),
                'note'               => '',
                'style'              => '',
            )
        );
        $fieldset->addField(
            'host_name', 'text', array(
                'label'              => __('Host Name'),
                'name'               => 'host_name',
                'class'             => 'required-entry',
                'required'          => true,
                'note'               => 'Ex. unilab.com.ph Note: Do not include http:// and www.',
                'style'              => '',
            )
        );
        $fieldset->addField(
            'return_url', 'text', array(
                'label'              => __('Return URL'),
                'name'               => 'return_url',
                'class'             => 'required-entry',
                'required'          => true,
                'note'               => 'Ex. http://www.unilab.com.ph',
                'style'              => '',
            )
        );

        $fieldset->addField(
            'is_active',
            'select',
            [
                'name' => __('is_active'),
                'label' => __('Status'),
                'id' => 'is_active',
                'title' => __('Status'),
                'values' => $this->_options->getOptionArray(),
                'class' => 'status',
                'required' => true,
            ]
        );
        
        $fieldset->addField('token', 'textarea', array(
            'label'     => __('Token'),
            'required'  => false,
			'readonly'	=> true,
			'note'		=> 'Token is auto generated',
            'name'      => 'token'
        ));	   
 

        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
