<?php
    /**
     * Unilab_Grid Add Row Form Block.
     *
     * @category    Unilab
     *
     * @author      Unilab Software Private Limited
     */
namespace Unilab\Webservice\Block\Adminhtml\Token;

class Token extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Core registry.
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry           $registry
     * @param array                                 $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    protected function _construct()
    {
        $this->_objectId = 'row_id';
        $this->_blockGroup = 'Unilab_Webservice';
        $this->_controller = 'adminhtml_token';
        parent::_construct();
        if ($this->_isAllowedAction('Unilab_Webservice::add_token')) {
            $this->buttonList->update('back', 'onclick', "setLocation('" . $this->getUrl('*/token/token') . "')");

            $this->buttonList->update('save', 'label', __('Save'));

            $this->buttonList->add(
                'saveandcontinue',
                [
                    'label' => __('Save and Continue Edit'),
                    'class' => 'save',
                    'data_attribute' => [
                        'mage-init' => [
                            'button' => ['event' => 'saveAndContinueEdit', 'target' => '#edit_form'],
                        ],
                    ]
                ],
                -100
            );

        } else {
            $this->buttonList->remove('save');
        }
        $this->buttonList->remove('reset');
    }


    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    /**
     * Get form action URL.
     *
     * @return string
     */
    public function getFormActionUrl()
    {
        if ($this->hasFormActionUrl()) {
            return $this->getData('form_action_url');
        }

        return $this->getUrl('*/token/save');
    }

    protected function _getSaveAndContinueUrl()
    {
        return $this->getUrl('*/token/save', ['_current' => true, 'back' => 'edittoken', 'active_tab' => '']);
    }
}
