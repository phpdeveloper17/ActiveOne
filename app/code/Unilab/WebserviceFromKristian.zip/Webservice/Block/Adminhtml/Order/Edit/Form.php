<?php
/**
 * @category  Unilab
 * @package   Unilab_Webservice
 * @author    Ron Mark Peroso Rudas   
 */
namespace Unilab\Webservice\Block\Adminhtml\Order\Edit;
 
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @param \Magento\Backend\Block\Template\Context $context,
     * @param \Magento\Framework\Registry $registry,
     * @param \Magento\Framework\Data\FormFactory $formFactory,
     * @param \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
     * @param \Unilab\Webservice\Model\Status $options,
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory, 
        \Unilab\Webservice\Model\Status $options,
        \Magento\Sales\Model\ResourceModel\Order\Status\CollectionFactory $statusCollectionFactory,
        array $data = []
    ) {
        $this->_options = $options;
        $this->statusCollectionFactory = $statusCollectionFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {     
        $status 	    = array(); 
        $status_lists = array();

        $order_status_collection = $this->statusCollectionFactory->create();

        foreach($order_status_collection->getData() as $status){ 

            $status_lists[$status['status']] = array('title'	=> $status['label'],
                                                          'value'	=> $status['status'],
                                                          'label'	=> $status['label']);
          } 
        

        $dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        $model = $this->_coreRegistry->registry('orderstatus_data');

        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form',
                            'enctype' => 'multipart/form-data',
                            'action' => $this->getData('action'),
                            'method' => 'post'
                        ]
            ]
        );

        $form->setHtmlIdPrefix('order_status_');
        if ($model->getId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __(''), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __(''), 'class' => 'fieldset-wide']
            );
        }


        $fieldset->addField(
            'status_name', 'select', array(
                'label'              => 'Status Name',
                'name'               => 'status_name',
                'class'             => 'required-entry',
                'required'          => true,
                'note'               => '',
                'style'              => '',
                'values'=> $status_lists
            )
        );
        $fieldset->addField(
            'status_code', 'text', array(
                'label'              => __('Status Code'),
                'name'               => 'status_code',
                'class'             => 'required-entry',
                'required'          => true,
                'note'               => '',
                'style'              => '',
            )
        );

        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
