<?php
    /**
     * Unilab_Grid Add Row Form Block.
     *
     * @category    Unilab
     *
     * @author      Unilab Software Private Limited
     */
namespace Unilab\Webservice\Block\Adminhtml\Order;

class Status extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Core registry.
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    protected $id = null;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry           $registry
     * @param array                                 $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    protected function _construct()
    {
        $id = $this->getRequest()->getParam('id');

        $this->_objectId = 'row_id';
        $this->_blockGroup = 'Unilab_Webservice';
        $this->_controller = 'adminhtml_order';
        parent::_construct();
        if ($this->_isAllowedAction('Unilab_Webservice::add_order_status')) {
            $this->buttonList->update('back', 'onclick', "setLocation('" . $this->getUrl('*/orderstatus/status') . "')");
            $this->buttonList->update('save', 'label', __('Save Order Status'));
            if($id){
                $this->buttonList->add(
                    'delete',
                    [
                        'label' => __('Delete'),
                        'class' => 'delete',
                        'on_click' => 'deleteConfirm(\''
                            . __('Are you sure you want to delete this Order Status?')
                            . '\', \'' . $this->getDeleteUrl() . '\')',
                        'sort_order' => 20,
                    ],
                    -100
                );
            }


            

        } else {
            $this->buttonList->remove('save');
        }
        $this->buttonList->remove('reset');
    }


    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    /**
     * Get form action URL.
     *
     * @return string
     */
    public function getFormActionUrl()
    {
        if ($this->hasFormActionUrl()) {
            return $this->getData('form_action_url');
        }

        return $this->getUrl('*/orderstatus/save');
    }

    protected function _getSaveAndContinueUrl()
    {
        return $this->getUrl('*/orderstatus/save', ['_current' => true, 'back' => 'editorderstatus', 'active_tab' => '']);
    }


    /**
     * @return string
     */
    public function getDeleteUrl()
    {
        $id = $this->getRequest()->getParam('id');

        return $this->getUrl('*/orderstatus/delete', ['id' =>$id ]);
    }
}
