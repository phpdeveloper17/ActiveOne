<?php
namespace Unilab\DragonPay\Logger;

class Logger extends \Monolog\Logger
{
}