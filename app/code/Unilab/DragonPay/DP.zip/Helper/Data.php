<?php
/**
 * DragonPay View XML.
 * @category  Unilab
 * @package   Unilab_DragonPay
 * @author    Kristian Claridad
 */
namespace Unilab\DragonPay\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
}
