<?php
namespace Unilab\DragonPay\Model;
class Session
{
    public function __construct()
    {
        $this->init('dragonpay');
    }
}
